# G11 independent move/state conformance artifact

**Programme:** G11 — Independent Move-Generation and State-Conformance Suite  
**Freeze status:** strong local semantic conformance, but roadmap gate **HOLD** because the exact frozen G10 bundle/vector payload was not retrievable from File Library search in this session.

## Engines

- `engine_a.py` — flat 64-square array; source-centric attack/ray scanning.
- `engine_b.py` — sparse `(file, rank)` map; target-centric attack lookup and ray scanning.

Neither engine imports the other. They share only the neutral G10-derived state-field names exercised by the harness. This is implementation-structural independence, not a claim of separate organizational authorship.

## Harness

`g11_conformance.py` covers:

- ordinary legal moves, checks and evasions;
- castling rights, legal castling, castling through/into check;
- effective en-passant including pinned-illegal canonical-null cases;
- promotions and underpromotions;
- full-state history updates, repetition barriers and halfmove clocks;
- threefold/50-move claims now and by intended move;
- fivefold/75-move automatic draws and checkmate precedence at halfmove 150;
- sound dead-position positive hooks (K v K, K+B v K, K+N v K) while returning `UNKNOWN` elsewhere rather than substituting insufficient-material heuristics;
- local malformed/history-inconsistent state rejection;
- G11-local deterministic serialization and independent round-trip parsing;
- exhaustive and fuzz/property differential tests.

`g11_run_phase.py` runs one phase in a fresh process. This is the preferred reproduction mode in resource-constrained environments.

## Frozen quantitative result

See `G11_Conformance_Ledger.json`. The accepted completed tests contain zero known A/B mismatches, including:

- 98,623 exhaustively checked locally valid small-domain states;
- 889,808 legal edges across those exhaustive domains;
- 256,000 attack-square/side differential queries;
- 5,000 accepted mixed-piece fuzz states and 2,000 sampled transitions;
- 2,000 adversarial EP constructions (1,569 effective, 431 canonical-null); 1,468 locally admissible resulting states compared;
- 1,536 reachable states and 1,536 transitions from deterministic random games, with 90 terminal and 80 undo spot checks;
- 5,000 malformed-state mutations;
- exact agreement with the fixed perft anchors encoded in the ledger for the standard start and standard perft positions 3 and 5.

Two over-wide stress runs are frozen as `HOLD_NO_RESULT`; no partial output from them is accepted.

## Critical limitation

The G10 handoff states that the frozen source bundle included `G10_Conformance_Vectors_v1.json` and an exact canonical byte profile, but File Library retrieval returned only the G10 handoff, not those standalone payloads. Therefore:

1. this artifact **does not claim** byte-for-byte identity with the frozen G10 canonical serializer;
2. `G11LC1` is only a local deterministic cross-engine profile;
3. the exact frozen G10 vector corpus has not been replayed;
4. the roadmap G11 advance condition is therefore not fully met, regardless of the zero-mismatch local evidence.

The successor must recover the G10 bundle and replay it before authorizing the original G12 full-rule small-arena solve.
