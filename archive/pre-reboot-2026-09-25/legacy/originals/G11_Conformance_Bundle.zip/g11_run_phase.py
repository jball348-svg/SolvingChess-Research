#!/usr/bin/env python3
import argparse, json, os
import g11_conformance as g

PHASES = {
    'curated': g.curated_tests,
    'perft': g.perft_tests,
    'exhaustive_kings': g.exhaustive_kings,
    'exhaustive_three_piece_slices': g.exhaustive_three_piece_slices,
    'attack_map_fuzz': g.attack_map_fuzz,
    'mixed_board_fuzz': g.mixed_board_fuzz,
    'ep_adversarial_fuzz': g.ep_adversarial_fuzz,
    'reachable_fuzz': g.reachable_fuzz,
    'mutation_fuzz': g.mutation_fuzz,
}

ap=argparse.ArgumentParser()
ap.add_argument('phase', choices=PHASES)
ap.add_argument('--out', required=True)
args=ap.parse_args()
ledger={'programme':'G11','phase':args.phase,'engines':[g.A.name,g.B.name]}
PHASES[args.phase](ledger)
os.makedirs(os.path.dirname(os.path.abspath(args.out)),exist_ok=True)
with open(args.out,'w') as f: json.dump(ledger,f,sort_keys=True,indent=2)
print(args.out)
