from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import json, struct, copy

FILES='abcdefgh'
PROMOS='qrbn'


def to_xy(s): return (FILES.index(s[0]), int(s[1])-1)
def to_sq(xy): return FILES[xy[0]]+str(xy[1]+1)
def side_of(p): return 'w' if p.isupper() else 'b'
def other(s): return 'b' if s=='w' else 'w'

def board_to_map(board64):
    d={}
    for n,p in enumerate(board64):
        if p!='.': d[(n%8,n//8)]=p
    return d

def map_to_board(d):
    a=['.']*64
    for (x,y),p in d.items(): a[y*8+x]=p
    return ''.join(a)

@dataclass(frozen=True)
class UndoB:
    snapshot: dict
    move: str

class EngineB:
    """Independent implementation B: sparse coordinate map, target-centric attack lookup."""
    name='Bmap-target-rays'

    def rep_key(self,st):
        # Written independently to the same semantic local profile.
        arr=[st['board64'],st['turn'],st.get('castling_rights',''),st.get('ep_effective') if st.get('ep_effective') else '-']
        return json.dumps(arr,separators=(',',':'))

    def serialize_local(self,st):
        buf=bytearray(b'G11LC1B')
        def put(value):
            raw=str(value).encode(); buf.extend(len(raw).to_bytes(4,'big')); buf.extend(raw)
        put(st['board64']); put(st['turn']); put(st.get('castling_rights','')); put(st.get('ep_effective') or '-'); put(int(st.get('halfmove_clock',0)))
        pairs=list(st.get('rep_counts',{}).items()); pairs.sort(key=lambda z:z[0].encode())
        buf.extend(len(pairs).to_bytes(4,'big'))
        for key,cnt in pairs:
            kb=key.encode(); buf.extend(len(kb).to_bytes(4,'big')); buf.extend(kb); buf.extend(bytes([int(cnt)]))
        put(st.get('provenance','ARENA_ADMISSIBLE'))
        return bytes(buf)
    def deserialize_local(self,data:bytes)->dict:
        if not data.startswith(b'G11LC1B'):
            raise ValueError('bad local serialization magic')
        i=7
        def get():
            nonlocal i
            if i+4>len(data): raise ValueError('truncated')
            n=int.from_bytes(data[i:i+4],'big'); i+=4
            if i+n>len(data): raise ValueError('truncated field')
            raw=data[i:i+n]; i+=n
            return raw.decode('utf-8')
        board=get(); turn=get(); rights=get(); ep=get(); hm=int(get())
        if i+4>len(data): raise ValueError('truncated reps')
        nitems=int.from_bytes(data[i:i+4],'big'); i+=4
        reps={}
        for _ in range(nitems):
            if i+4>len(data): raise ValueError('truncated rep key')
            n=int.from_bytes(data[i:i+4],'big'); i+=4
            if i+n+1>len(data): raise ValueError('truncated rep entry')
            key=data[i:i+n].decode('utf-8'); i+=n; cnt=data[i]; i+=1; reps[key]=cnt
        provenance=get()
        if i!=len(data): raise ValueError('trailing bytes')
        return {'board64':board,'turn':turn,'castling_rights':rights,'ep_effective':None if ep=='-' else ep,'halfmove_clock':hm,'rep_counts':reps,'provenance':provenance}

    def normalize_local_serialization(self,st): return b'G11LC1'+self.serialize_local(st)[7:]

    def _inside(self,x,y): return 0<=x<8 and 0<=y<8

    def attacked_map(self,pos:Dict[Tuple[int,int],str], target:Tuple[int,int], attacker:str)->bool:
        """Target-centric: inspect origins/rays outward from target, unlike A's source scan."""
        x,y=target
        # pawn origins that could attack target
        oy=y-1 if attacker=='w' else y+1
        pawn='P' if attacker=='w' else 'p'
        for ox in (x-1,x+1):
            if self._inside(ox,oy) and pos.get((ox,oy))==pawn: return True
        knight='N' if attacker=='w' else 'n'
        for dx,dy in ((1,2),(2,1),(2,-1),(1,-2),(-1,-2),(-2,-1),(-2,1),(-1,2)):
            q=(x+dx,y+dy)
            if self._inside(*q) and pos.get(q)==knight: return True
        king='K' if attacker=='w' else 'k'
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                if dx or dy:
                    q=(x+dx,y+dy)
                    if self._inside(*q) and pos.get(q)==king: return True
        for dx,dy,allowed in ((1,0,'RQ'),(-1,0,'RQ'),(0,1,'RQ'),(0,-1,'RQ'),(1,1,'BQ'),(1,-1,'BQ'),(-1,1,'BQ'),(-1,-1,'BQ')):
            nx,ny=x+dx,y+dy
            while self._inside(nx,ny):
                p=pos.get((nx,ny))
                if p:
                    if side_of(p)==attacker and p.upper() in allowed: return True
                    break
                nx+=dx; ny+=dy
        return False

    def in_check_map(self,pos,side):
        king='K' if side=='w' else 'k'
        loc=[q for q,p in pos.items() if p==king]
        return True if len(loc)!=1 else self.attacked_map(pos,loc[0],other(side))
    def in_check(self,st): return self.in_check_map(board_to_map(st['board64']),st['turn'])

    def _basic_valid(self,st):
        b=st.get('board64','')
        return len(b)==64 and b.count('K')==1 and b.count('k')==1 and st.get('turn') in ('w','b')

    def validate(self,st):
        b=st.get('board64',''); faults=[]
        if len(b)!=64 or any(c not in '.PNBRQKpnbrqk' for c in b): return 'MALFORMED',['board64']
        if b.count('K')!=1 or b.count('k')!=1: faults.append('king_count')
        if st.get('turn') not in ('w','b'): faults.append('turn')
        if any(b[i] in 'Pp' for i in range(8)) or any(b[i] in 'Pp' for i in range(56,64)): faults.append('pawn_backrank')
        if b.count('P')>8 or b.count('p')>8: faults.append('pawn_count')
        if sum(1 for c in b if c!='.' and c.isupper())>16 or sum(1 for c in b if c!='.' and c.islower())>16: faults.append('piece_count')
        if b.count('K')==b.count('k')==1:
            K=(b.index('K')%8,b.index('K')//8); k=(b.index('k')%8,b.index('k')//8)
            if max(abs(K[0]-k[0]),abs(K[1]-k[1]))<=1: faults.append('adjacent_kings')
            elif st.get('turn') in ('w','b'):
                pos=board_to_map(b); nonmoving=k if st['turn']=='w' else K
                if self.attacked_map(pos,nonmoving,st['turn']): faults.append('nonmoving_king_in_check')
        for P,Q,R,Bb,N in (('P','Q','R','B','N'),('p','q','r','b','n')):
            extras=max(0,b.count(Q)-1)+max(0,b.count(R)-2)+max(0,b.count(Bb)-2)+max(0,b.count(N)-2)
            if b.count(P)+extras>8: faults.append('promotion_material_infeasible')
        cr=st.get('castling_rights','')
        if cr!=''.join(c for c in 'KQkq' if c in cr) or len(cr)!=len(set(cr)): faults.append('castling_format')
        homes={'K':('K',4,'R',7),'Q':('K',4,'R',0),'k':('k',60,'r',63),'q':('k',60,'r',56)}
        for flag,(kp,ki,rp,ri) in homes.items():
            if flag in cr and (b[ki]!=kp or b[ri]!=rp): faults.append('castling_inconsistent_'+flag)
        ep=st.get('ep_effective')
        if ep:
            if len(ep)!=2 or ep[0] not in FILES or ep[1] not in '36': faults.append('ep_rank' if len(ep)==2 else 'ep_format')
            else:
                ex,ey=to_xy(ep); pos=board_to_map(b)
                if st.get('turn')=='w':
                    if ep[1]!='6' or (ex,ey) in pos or pos.get((ex,ey-1))!='p' or (ex,ey+1) in pos: faults.append('ep_history_structure')
                elif st.get('turn')=='b':
                    if ep[1]!='3' or (ex,ey) in pos or pos.get((ex,ey+1))!='P' or (ex,ey-1) in pos: faults.append('ep_history_structure')
        hm=st.get('halfmove_clock',0)
        if type(hm) is not int or not (0<=hm<=149): faults.append('halfmove_active_range')
        reps=st.get('rep_counts',{})
        if type(reps) is not dict or any(type(v) is not int or v<1 or v>4 for v in reps.values()): faults.append('rep_counts')
        if not faults and self.rep_key(st) not in reps: faults.append('current_rep_missing')
        if faults: return 'MALFORMED',sorted(set(faults))
        if ep and not self.has_legal_ep(st): return 'HISTORY_INCONSISTENT',['ineffective_ep']
        return st.get('provenance','ARENA_ADMISSIBLE_UNPROVEN_REACHABLE'),[]

    def _raw_moves(self,st):
        pos=board_to_map(st['board64']); side=st['turn']; ep=st.get('ep_effective'); ans=[]
        own=[(q,p) for q,p in pos.items() if side_of(p)==side]
        for (x,y),p in own:
            P=p.upper(); src=to_sq((x,y))
            if P=='P':
                step=1 if side=='w' else -1; initial=1 if side=='w' else 6; last=7 if side=='w' else 0
                one=(x,y+step)
                if self._inside(*one) and one not in pos:
                    if one[1]==last:
                        for z in PROMOS: ans.append(src+to_sq(one)+z)
                    else:
                        ans.append(src+to_sq(one))
                        two=(x,y+2*step)
                        if y==initial and two not in pos: ans.append(src+to_sq(two))
                for dx in (-1,1):
                    dst=(x+dx,y+step)
                    if not self._inside(*dst): continue
                    victim=pos.get(dst)
                    if victim and victim.upper()!='K' and side_of(victim)!=side:
                        if dst[1]==last:
                            for z in PROMOS: ans.append(src+to_sq(dst)+z)
                        else: ans.append(src+to_sq(dst))
                    elif ep and to_sq(dst)==ep: ans.append(src+to_sq(dst))
            elif P=='N':
                for dx,dy in ((2,1),(1,2),(-1,2),(-2,1),(-2,-1),(-1,-2),(1,-2),(2,-1)):
                    dst=(x+dx,y+dy)
                    if self._inside(*dst) and (dst not in pos or (pos[dst].upper()!='K' and side_of(pos[dst])!=side)): ans.append(src+to_sq(dst))
            elif P=='K':
                for dx in (-1,0,1):
                    for dy in (-1,0,1):
                        if not (dx or dy): continue
                        dst=(x+dx,y+dy)
                        if self._inside(*dst) and (dst not in pos or (pos[dst].upper()!='K' and side_of(pos[dst])!=side)): ans.append(src+to_sq(dst))
                cr=st.get('castling_rights','')
                if side=='w' and (x,y)==(4,0):
                    if 'K' in cr and pos.get((7,0))=='R' and all(q not in pos for q in ((5,0),(6,0))) and all(not self.attacked_map(pos,q,'b') for q in ((4,0),(5,0),(6,0))): ans.append('e1g1')
                    if 'Q' in cr and pos.get((0,0))=='R' and all(q not in pos for q in ((1,0),(2,0),(3,0))) and all(not self.attacked_map(pos,q,'b') for q in ((4,0),(3,0),(2,0))): ans.append('e1c1')
                if side=='b' and (x,y)==(4,7):
                    if 'k' in cr and pos.get((7,7))=='r' and all(q not in pos for q in ((5,7),(6,7))) and all(not self.attacked_map(pos,q,'w') for q in ((4,7),(5,7),(6,7))): ans.append('e8g8')
                    if 'q' in cr and pos.get((0,7))=='r' and all(q not in pos for q in ((1,7),(2,7),(3,7))) and all(not self.attacked_map(pos,q,'w') for q in ((4,7),(3,7),(2,7))): ans.append('e8c8')
            else:
                directions=[]
                if P in ('B','Q'): directions += [(1,1),(1,-1),(-1,1),(-1,-1)]
                if P in ('R','Q'): directions += [(1,0),(-1,0),(0,1),(0,-1)]
                for dx,dy in directions:
                    nx,ny=x+dx,y+dy
                    while self._inside(nx,ny):
                        dst=(nx,ny)
                        if dst not in pos: ans.append(src+to_sq(dst))
                        else:
                            if pos[dst].upper()!='K' and side_of(pos[dst])!=side: ans.append(src+to_sq(dst))
                            break
                        nx+=dx; ny+=dy
        return ans

    def _board_after(self,st,mv):
        pos=board_to_map(st['board64']); src=to_xy(mv[:2]); dst=to_xy(mv[2:4]); p=pos[src]
        victim=pos.get(dst); pawn=p.upper()=='P'; capture=victim is not None; ep_capture=False
        del pos[src]
        if pawn and src[0]!=dst[0] and victim is None and st.get('ep_effective')==mv[2:4]:
            cq=(dst[0], dst[1]-1 if p=='P' else dst[1]+1)
            if pos.get(cq, '').upper()=='P' and side_of(pos[cq])!=side_of(p):
                del pos[cq]; capture=True; ep_capture=True
        placed=p
        if len(mv)==5 and pawn: placed=mv[4].upper() if p.isupper() else mv[4]
        pos[dst]=placed
        if p=='K' and src==(4,0) and dst==(6,0): pos[(5,0)]=pos.pop((7,0))
        elif p=='K' and src==(4,0) and dst==(2,0): pos[(3,0)]=pos.pop((0,0))
        elif p=='k' and src==(4,7) and dst==(6,7): pos[(5,7)]=pos.pop((7,7))
        elif p=='k' and src==(4,7) and dst==(2,7): pos[(3,7)]=pos.pop((0,7))
        return pos,pawn,capture,ep_capture,victim

    def legal_moves(self,st):
        if not self._basic_valid(st): return []
        side=st['turn']; good=[]
        for mv in self._raw_moves(st):
            try: pos,*_=self._board_after(st,mv)
            except Exception: continue
            if not self.in_check_map(pos,side): good.append(mv)
        return sorted(set(good))

    def has_legal_ep(self,st):
        ep=st.get('ep_effective')
        if not ep or not self._basic_valid(st): return False
        target=to_xy(ep); side=st['turn']; step=1 if side=='w' else -1; origin_y=target[1]-step; pawn='P' if side=='w' else 'p'; pos=board_to_map(st['board64'])
        for ox in (target[0]-1,target[0]+1):
            src=(ox,origin_y)
            if self._inside(*src) and pos.get(src)==pawn:
                mv=to_sq(src)+ep
                try: child,*_=self._board_after(st,mv)
                except Exception: continue
                if not self.in_check_map(child,side): return True
        return False

    def canonicalize_ep(self,child,nominal):
        if nominal is None: return None
        t=dict(child); t['ep_effective']=nominal
        return nominal if self.has_legal_ep(t) else None

    def _rights_next(self,st,mv):
        pos=board_to_map(st['board64']); src=to_xy(mv[:2]); dst=to_xy(mv[2:4]); p=pos[src]; victim=pos.get(dst); keep=set(st.get('castling_rights',''))
        if p=='K': keep.difference_update(('K','Q'))
        elif p=='k': keep.difference_update(('k','q'))
        if p=='R' and src==(7,0): keep.discard('K')
        if p=='R' and src==(0,0): keep.discard('Q')
        if p=='r' and src==(7,7): keep.discard('k')
        if p=='r' and src==(0,7): keep.discard('q')
        if victim=='R' and dst==(7,0): keep.discard('K')
        if victim=='R' and dst==(0,0): keep.discard('Q')
        if victim=='r' and dst==(7,7): keep.discard('k')
        if victim=='r' and dst==(0,7): keep.discard('q')
        return ''.join(c for c in 'KQkq' if c in keep)

    def transition(self,st,mv,classify_terminal=True):
        if mv not in self.legal_moves(st): raise ValueError('illegal move '+mv)
        pos,pawn,capture,epcap,victim=self._board_after(st,mv)
        rights=self._rights_next(st,mv); changed=rights!=st.get('castling_rights','')
        half=0 if pawn or capture else st.get('halfmove_clock',0)+1
        src=to_xy(mv[:2]); dst=to_xy(mv[2:4]); nominal=None
        if pawn and abs(src[1]-dst[1])==2: nominal=to_sq((src[0],(src[1]+dst[1])//2))
        child={'board64':map_to_board(pos),'turn':other(st['turn']),'castling_rights':rights,'ep_effective':None,'halfmove_clock':half,'rep_counts':{},'provenance':st.get('provenance','ARENA_ADMISSIBLE')}
        child['ep_effective']=self.canonicalize_ep(child,nominal)
        key=self.rep_key(child)
        if pawn or capture or changed: child['rep_counts']={key:1}
        else:
            child['rep_counts']=copy.deepcopy(st.get('rep_counts',{})); child['rep_counts'][key]=child['rep_counts'].get(key,0)+1
        if classify_terminal: child['terminal']=self.terminal_after_move(child)
        return child

    def transition_with_undo(self,st,mv): return self.transition(st,mv), UndoB(copy.deepcopy(st),mv)
    def undo(self,child,rec): return copy.deepcopy(rec.snapshot)

    def claim_actions(self,st):
        claims=[]; here=self.rep_key(st)
        if st.get('rep_counts',{}).get(here,0)>=3: claims.append('CLAIM_3_NOW')
        if st.get('halfmove_clock',0)>=100: claims.append('CLAIM_50_NOW')
        for mv in self.legal_moves(st):
            pos=board_to_map(st['board64']); src=to_xy(mv[:2]); dst=to_xy(mv[2:4]); p=pos[src]; victim=pos.get(dst)
            iscap=victim is not None or (p.upper()=='P' and src[0]!=dst[0] and victim is None and st.get('ep_effective')==mv[2:4])
            nxt=self.transition(st,mv,classify_terminal=False); nk=self.rep_key(nxt)
            barrier=p.upper()=='P' or iscap or nxt['castling_rights']!=st.get('castling_rights','')
            if not barrier and st.get('rep_counts',{}).get(nk,0)>=2: claims.append('CLAIM_3_BY_MOVE:'+mv)
            if p.upper()!='P' and not iscap and st.get('halfmove_clock',0)+1>=100: claims.append('CLAIM_50_BY_MOVE:'+mv)
        return sorted(set(claims))

    def dead_hook(self,st):
        others=[]
        for p in st['board64']:
            if p!='.' and p.upper()!='K': others.append(p.upper())
        if len(others)==0: return 'DEAD'
        if len(others)==1 and others[0] in ('B','N'): return 'DEAD'
        return 'UNKNOWN'

    def terminal_after_move(self,st):
        lm=self.legal_moves(st)
        if not lm: return 'CHECKMATE' if self.in_check(st) else 'STALEMATE'
        dead=self.dead_hook(st)
        if dead=='DEAD': return 'DEAD_POSITION'
        if st.get('rep_counts',{}).get(self.rep_key(st),0)>=5: return 'FIVEFOLD_REPETITION'
        if st.get('halfmove_clock',0)>=150: return 'SEVENTYFIVE_MOVE'
        return 'ACTIVE' if dead!='UNKNOWN' else 'ACTIVE_DEADNESS_UNRESOLVED'
