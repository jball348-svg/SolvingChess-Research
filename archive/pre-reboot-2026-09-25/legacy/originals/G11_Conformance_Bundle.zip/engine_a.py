from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any
import json, struct

FILES='abcdefgh'
PROMOS='qrbn'
KNIGHT=[(1,2),(2,1),(2,-1),(1,-2),(-1,-2),(-2,-1),(-2,1),(-1,2)]
KING=[(1,1),(1,0),(1,-1),(0,1),(0,-1),(-1,1),(-1,0),(-1,-1)]
BISH=[(1,1),(1,-1),(-1,1),(-1,-1)]
ROOK=[(1,0),(-1,0),(0,1),(0,-1)]


def sq_name(i:int)->str:
    return FILES[i%8]+str(i//8+1)
def sq_idx(s:str)->int:
    return (ord(s[0])-97)+8*(int(s[1])-1)
def color(p:str)->str:
    return 'w' if p.isupper() else 'b'
def enemy(t:str)->str:
    return 'b' if t=='w' else 'w'

def make_state(board64:str, turn='w', castling='', ep=None, halfmove=0, rep_counts=None, provenance='ARENA_ADMISSIBLE')->dict:
    st={'board64':board64,'turn':turn,'castling_rights':''.join(c for c in 'KQkq' if c in castling),
        'ep_effective':ep,'halfmove_clock':int(halfmove),'rep_counts':dict(rep_counts or {}),'provenance':provenance}
    if not st['rep_counts']:
        k=EngineA.rep_key_static(st)
        st['rep_counts']={k:1}
    return st

@dataclass(frozen=True)
class UndoA:
    parent: dict
    move: str

class EngineA:
    """Reference implementation A: flat 0..63 board, source-centric attack scan."""
    name='A64-source-rays'

    @staticmethod
    def rep_key_static(st:dict)->str:
        return json.dumps([st['board64'], st['turn'], st.get('castling_rights',''), st.get('ep_effective') or '-'], separators=(',',':'))
    def rep_key(self,st): return self.rep_key_static(st)

    def serialize_local(self,st:dict)->bytes:
        # G11 local profile only; not asserted byte-identical to unavailable G10 bundle.
        out=bytearray(b'G11LC1A')
        def fld(x):
            b=str(x).encode('utf-8'); out.extend(struct.pack('>I',len(b))); out.extend(b)
        fld(st['board64']); fld(st['turn']); fld(st.get('castling_rights','')); fld(st.get('ep_effective') or '-'); fld(int(st.get('halfmove_clock',0)))
        items=sorted(st.get('rep_counts',{}).items(), key=lambda kv: kv[0].encode())
        out.extend(struct.pack('>I',len(items)))
        for k,v in items:
            b=k.encode(); out.extend(struct.pack('>I',len(b))); out.extend(b); out.append(int(v))
        fld(st.get('provenance','ARENA_ADMISSIBLE'))
        return bytes(out)

    def deserialize_local(self,data:bytes)->dict:
        if not data.startswith(b'G11LC1A'):
            raise ValueError('bad local serialization magic')
        i=7
        def get():
            nonlocal i
            if i+4>len(data): raise ValueError('truncated')
            n=int.from_bytes(data[i:i+4],'big'); i+=4
            if i+n>len(data): raise ValueError('truncated field')
            raw=data[i:i+n]; i+=n
            return raw.decode('utf-8')
        board=get(); turn=get(); rights=get(); ep=get(); hm=int(get())
        if i+4>len(data): raise ValueError('truncated reps')
        nitems=int.from_bytes(data[i:i+4],'big'); i+=4
        reps={}
        for _ in range(nitems):
            if i+4>len(data): raise ValueError('truncated rep key')
            n=int.from_bytes(data[i:i+4],'big'); i+=4
            if i+n+1>len(data): raise ValueError('truncated rep entry')
            key=data[i:i+n].decode('utf-8'); i+=n; cnt=data[i]; i+=1; reps[key]=cnt
        provenance=get()
        if i!=len(data): raise ValueError('trailing bytes')
        return {'board64':board,'turn':turn,'castling_rights':rights,'ep_effective':None if ep=='-' else ep,'halfmove_clock':hm,'rep_counts':reps,'provenance':provenance}

    def normalize_local_serialization(self,st:dict)->bytes:
        # common payload version used for cross-engine byte comparison (engine marker removed)
        x=self.serialize_local(st)
        return b'G11LC1'+x[7:]

    def validate(self,st:dict)->Tuple[str,List[str]]:
        b=st.get('board64',''); issues=[]
        if len(b)!=64 or any(c not in '.PNBRQKpnbrqk' for c in b): return 'MALFORMED',['board64']
        if b.count('K')!=1 or b.count('k')!=1: issues.append('king_count')
        if st.get('turn') not in ('w','b'): issues.append('turn')
        # Pawns may not be on first/eighth ranks in a legal active standard position.
        if any(b[i] in 'Pp' for i in list(range(8))+list(range(56,64))): issues.append('pawn_backrank')
        if b.count('P')>8 or b.count('p')>8: issues.append('pawn_count')
        if sum(c.isupper() for c in b if c!='.')>16 or sum(c.islower() for c in b if c!='.')>16: issues.append('piece_count')
        if b.count('K')==1 and b.count('k')==1:
            a=b.index('K'); z=b.index('k')
            if max(abs(a%8-z%8),abs(a//8-z//8))<=1: issues.append('adjacent_kings')
            elif st.get('turn') in ('w','b'):
                nonmoving_king = z if st['turn']=='w' else a
                if self._attacked(list(b), nonmoving_king, st['turn']): issues.append('nonmoving_king_in_check')
        for sidechars in (('P','Q','R','B','N'),('p','q','r','b','n')):
            P,Q,R,Bb,N=sidechars
            extras=max(0,b.count(Q)-1)+max(0,b.count(R)-2)+max(0,b.count(Bb)-2)+max(0,b.count(N)-2)
            if b.count(P)+extras>8: issues.append('promotion_material_infeasible')
        rights=st.get('castling_rights','')
        if ''.join(c for c in 'KQkq' if c in rights)!=rights or len(set(rights))!=len(rights): issues.append('castling_format')
        req={'K':(4,'K',7,'R'),'Q':(4,'K',0,'R'),'k':(60,'k',63,'r'),'q':(60,'k',56,'r')}
        for r,(ki,kp,ri,rp) in req.items():
            if r in rights and (b[ki]!=kp or b[ri]!=rp): issues.append('castling_inconsistent_'+r)
        ep=st.get('ep_effective')
        if ep is not None:
            try: ei=sq_idx(ep)
            except Exception: issues.append('ep_format'); ei=-1
            if ei>=0:
                if ep[1] not in '36': issues.append('ep_rank')
                elif st.get('turn')=='w':
                    if ep[1]!='6' or b[ei]!='.' or ei-8<0 or b[ei-8]!='p' or ei+8>=64 or b[ei+8]!='.': issues.append('ep_history_structure')
                elif st.get('turn')=='b':
                    if ep[1]!='3' or b[ei]!='.' or ei+8>=64 or b[ei+8]!='P' or ei-8<0 or b[ei-8]!='.': issues.append('ep_history_structure')
        hm=st.get('halfmove_clock',0)
        if not isinstance(hm,int) or hm<0 or hm>149: issues.append('halfmove_active_range')
        rc=st.get('rep_counts',{})
        if not isinstance(rc,dict) or any((not isinstance(v,int) or v<1 or v>4) for v in rc.values()): issues.append('rep_counts')
        if not issues and self.rep_key(st) not in rc: issues.append('current_rep_missing')
        if issues: return 'MALFORMED',sorted(set(issues))
        # effective EP must actually be capturable legally. If not, this is noncanonical/history inconsistent.
        if ep is not None and not self.has_legal_ep(st):
            return 'HISTORY_INCONSISTENT',['ineffective_ep']
        # Local admissibility does not imply historical start reachability.
        return st.get('provenance','ARENA_ADMISSIBLE_UNPROVEN_REACHABLE'),[]

    def _attacked(self,b:List[str],target:int,by:str)->bool:
        tf,tr=target%8,target//8
        # Source-centric scan: walk every attacker and see whether it hits target.
        for s,p in enumerate(b):
            if p=='.' or color(p)!=by: continue
            f,r=s%8,s//8; kind=p.upper()
            if kind=='P':
                dr=1 if by=='w' else -1
                if (tr-r)==dr and abs(tf-f)==1: return True
            elif kind=='N':
                if (tf-f,tr-r) in KNIGHT: return True
            elif kind=='K':
                if max(abs(tf-f),abs(tr-r))==1: return True
            elif kind in ('B','R','Q'):
                df=tf-f; dr=tr-r
                if kind in ('B','Q') and abs(df)==abs(dr) and df!=0:
                    sf=1 if df>0 else -1; sr=1 if dr>0 else -1
                elif kind in ('R','Q') and ((df==0)^(dr==0)):
                    sf=0 if df==0 else (1 if df>0 else -1); sr=0 if dr==0 else (1 if dr>0 else -1)
                else: continue
                x,y=f+sf,r+sr; clear=True
                while (x,y)!=(tf,tr):
                    if b[y*8+x]!='.': clear=False; break
                    x+=sf; y+=sr
                if clear: return True
        return False

    def in_check_board(self,b:List[str],turn:str)->bool:
        k='K' if turn=='w' else 'k'
        try: ks=b.index(k)
        except ValueError: return True
        return self._attacked(b,ks,enemy(turn))
    def in_check(self,st): return self.in_check_board(list(st['board64']),st['turn'])

    def _pseudo(self,st:dict)->List[str]:
        b=list(st['board64']); side=st['turn']; ep=st.get('ep_effective'); moves=[]
        for s,p in enumerate(b):
            if p=='.' or color(p)!=side: continue
            f,r=s%8,s//8; kind=p.upper()
            if kind=='P':
                dr=1 if side=='w' else -1; start=1 if side=='w' else 6; promo=7 if side=='w' else 0
                nr=r+dr
                if 0<=nr<8:
                    d=nr*8+f
                    if b[d]=='.':
                        if nr==promo:
                            moves += [sq_name(s)+sq_name(d)+q for q in PROMOS]
                        else:
                            moves.append(sq_name(s)+sq_name(d))
                            if r==start:
                                d2=(r+2*dr)*8+f
                                if b[d2]=='.': moves.append(sq_name(s)+sq_name(d2))
                    for df in (-1,1):
                        nf=f+df
                        if 0<=nf<8:
                            d=nr*8+nf
                            if b[d]!='.' and b[d].upper()!='K' and color(b[d])!=side:
                                if nr==promo: moves += [sq_name(s)+sq_name(d)+q for q in PROMOS]
                                else: moves.append(sq_name(s)+sq_name(d))
                            elif ep and sq_name(d)==ep:
                                moves.append(sq_name(s)+sq_name(d))
            elif kind=='N':
                for df,dr in KNIGHT:
                    nf,nr=f+df,r+dr
                    if 0<=nf<8 and 0<=nr<8:
                        d=nr*8+nf
                        if b[d]=='.' or (b[d].upper()!='K' and color(b[d])!=side): moves.append(sq_name(s)+sq_name(d))
            elif kind=='K':
                for df,dr in KING:
                    nf,nr=f+df,r+dr
                    if 0<=nf<8 and 0<=nr<8:
                        d=nr*8+nf
                        if b[d]=='.' or (b[d].upper()!='K' and color(b[d])!=side): moves.append(sq_name(s)+sq_name(d))
                # Castling legality is fully checked here, including attacked transit/destination.
                if side=='w' and s==4:
                    if 'K' in st.get('castling_rights','') and b[5]==b[6]=='.' and b[7]=='R' and not self._attacked(b,4,'b') and not self._attacked(b,5,'b') and not self._attacked(b,6,'b'): moves.append('e1g1')
                    if 'Q' in st.get('castling_rights','') and b[1]==b[2]==b[3]=='.' and b[0]=='R' and not self._attacked(b,4,'b') and not self._attacked(b,3,'b') and not self._attacked(b,2,'b'): moves.append('e1c1')
                if side=='b' and s==60:
                    if 'k' in st.get('castling_rights','') and b[61]==b[62]=='.' and b[63]=='r' and not self._attacked(b,60,'w') and not self._attacked(b,61,'w') and not self._attacked(b,62,'w'): moves.append('e8g8')
                    if 'q' in st.get('castling_rights','') and b[57]==b[58]==b[59]=='.' and b[56]=='r' and not self._attacked(b,60,'w') and not self._attacked(b,59,'w') and not self._attacked(b,58,'w'): moves.append('e8c8')
            else:
                dirs=(BISH if kind=='B' else ROOK if kind=='R' else BISH+ROOK)
                for df,dr in dirs:
                    nf,nr=f+df,r+dr
                    while 0<=nf<8 and 0<=nr<8:
                        d=nr*8+nf
                        if b[d]=='.': moves.append(sq_name(s)+sq_name(d))
                        else:
                            if b[d].upper()!='K' and color(b[d])!=side: moves.append(sq_name(s)+sq_name(d))
                            break
                        nf+=df; nr+=dr
        return moves

    def _apply_board(self,st:dict,mv:str)->Tuple[List[str],bool,bool,bool]:
        b=list(st['board64']); a=sq_idx(mv[:2]); d=sq_idx(mv[2:4]); p=b[a]; target=b[d]
        is_pawn=p.upper()=='P'; capture=(target!='.'); epcap=False
        # en passant capture
        if is_pawn and a%8!=d%8 and target=='.' and st.get('ep_effective')==mv[2:4]:
            cap=d-8 if p=='P' else d+8
            if 0<=cap<64 and b[cap].upper()=='P' and color(b[cap])!=color(p):
                b[cap]='.'; capture=True; epcap=True
        b[a]='.'
        placed=p
        if len(mv)==5 and is_pawn: placed=mv[4].upper() if p.isupper() else mv[4].lower()
        b[d]=placed
        # castling rook
        if p=='K' and a==4 and d==6: b[7]='.'; b[5]='R'
        elif p=='K' and a==4 and d==2: b[0]='.'; b[3]='R'
        elif p=='k' and a==60 and d==62: b[63]='.'; b[61]='r'
        elif p=='k' and a==60 and d==58: b[56]='.'; b[59]='r'
        return b,is_pawn,capture,epcap

    def legal_moves(self,st:dict)->List[str]:
        # malformed states produce no legal moves in the conformance harness.
        status,_=self.validate_shallow(st)
        if status=='MALFORMED': return []
        side=st['turn']; out=[]
        for mv in self._pseudo(st):
            b,*_=self._apply_board(st,mv)
            if not self.in_check_board(b,side): out.append(mv)
        return sorted(set(out))

    def validate_shallow(self,st):
        b=st.get('board64','')
        if len(b)!=64 or b.count('K')!=1 or b.count('k')!=1: return 'MALFORMED',[]
        return 'OK',[]

    def has_legal_ep(self,st:dict)->bool:
        ep=st.get('ep_effective')
        if not ep: return False
        # avoid validate recursion: scan only pawn candidates then king-safety simulate.
        b=list(st['board64']); side=st['turn']; d=sq_idx(ep); df,dr=d%8,d//8
        sr=dr-1 if side=='w' else dr+1
        pawn='P' if side=='w' else 'p'
        for sf in (df-1,df+1):
            if 0<=sf<8 and 0<=sr<8:
                a=sr*8+sf
                if b[a]==pawn:
                    mv=sq_name(a)+ep
                    nb,*_=self._apply_board(st,mv)
                    if not self.in_check_board(nb,side): return True
        return False

    def canonicalize_ep(self,st:dict, nominal_ep:Optional[str])->Optional[str]:
        if nominal_ep is None: return None
        tmp=dict(st); tmp['ep_effective']=nominal_ep
        return nominal_ep if self.has_legal_ep(tmp) else None

    def _updated_rights(self,st,mv,before:List[str],after:List[str])->str:
        rights=set(st.get('castling_rights','')); a=sq_idx(mv[:2]); d=sq_idx(mv[2:4]); p=before[a]; cap=before[d]
        if p=='K': rights-=set('KQ')
        if p=='k': rights-=set('kq')
        if p=='R' and a==7: rights.discard('K')
        if p=='R' and a==0: rights.discard('Q')
        if p=='r' and a==63: rights.discard('k')
        if p=='r' and a==56: rights.discard('q')
        # rights loss on capture of home rook (even if captured via ordinary move)
        if d==7 and cap=='R': rights.discard('K')
        if d==0 and cap=='R': rights.discard('Q')
        if d==63 and cap=='r': rights.discard('k')
        if d==56 and cap=='r': rights.discard('q')
        return ''.join(c for c in 'KQkq' if c in rights)

    def transition(self,st:dict,mv:str, classify_terminal=True)->dict:
        if mv not in self.legal_moves(st): raise ValueError('illegal move '+mv)
        before=list(st['board64']); after,is_pawn,capture,_=self._apply_board(st,mv)
        rights2=self._updated_rights(st,mv,before,after)
        rights_reduced=(rights2!=st.get('castling_rights',''))
        hm=0 if (is_pawn or capture) else st.get('halfmove_clock',0)+1
        turn2=enemy(st['turn'])
        nominal=None
        a=sq_idx(mv[:2]); d=sq_idx(mv[2:4])
        if is_pawn and abs(d//8-a//8)==2: nominal=sq_name((a+d)//2)
        child={'board64':''.join(after),'turn':turn2,'castling_rights':rights2,'ep_effective':None,'halfmove_clock':hm,'rep_counts':{},'provenance':st.get('provenance','ARENA_ADMISSIBLE')}
        child['ep_effective']=self.canonicalize_ep(child,nominal)
        k=self.rep_key(child)
        barrier=is_pawn or capture or rights_reduced
        if barrier: child['rep_counts']={k:1}
        else:
            child['rep_counts']=dict(st.get('rep_counts',{})); child['rep_counts'][k]=child['rep_counts'].get(k,0)+1
        if classify_terminal: child['terminal']=self.terminal_after_move(child)
        return child

    def transition_with_undo(self,st,mv):
        return self.transition(st,mv), UndoA(parent=json.loads(json.dumps(st)),move=mv)
    def undo(self,child,record:UndoA):
        return json.loads(json.dumps(record.parent))

    def claim_actions(self,st:dict)->List[str]:
        acts=[]; k=self.rep_key(st)
        if st.get('rep_counts',{}).get(k,0)>=3: acts.append('CLAIM_3_NOW')
        if st.get('halfmove_clock',0)>=100: acts.append('CLAIM_50_NOW')
        for mv in self.legal_moves(st):
            before=list(st['board64']); a=sq_idx(mv[:2]); d=sq_idx(mv[2:4]); p=before[a]; cap=before[d]!='.'
            epcap=(p.upper()=='P' and a%8!=d%8 and before[d]=='.' and st.get('ep_effective')==mv[2:4])
            iscap=cap or epcap
            ch=self.transition(st,mv,classify_terminal=False); ck=self.rep_key(ch)
            # "by move" claims occur before move execution, using resulting repetition position.
            # Barrier moves necessarily reset repetition and cannot be threefold by this move.
            if not (p.upper()=='P' or iscap or ch['castling_rights']!=st.get('castling_rights','')) and st.get('rep_counts',{}).get(ck,0)>=2:
                acts.append('CLAIM_3_BY_MOVE:'+mv)
            if p.upper()!='P' and not iscap and st.get('halfmove_clock',0)+1>=100:
                acts.append('CLAIM_50_BY_MOVE:'+mv)
        return sorted(set(acts))

    def dead_hook(self,st:dict)->str:
        # Sound exact positive controls only; UNKNOWN is never treated as ACTIVE.
        pieces=[p for p in st['board64'] if p!='.']
        nonk=[p.upper() for p in pieces if p.upper()!='K']
        if not nonk: return 'DEAD'
        if len(nonk)==1 and nonk[0] in ('B','N'): return 'DEAD'
        return 'UNKNOWN'

    def terminal_after_move(self,st:dict)->str:
        lm=self.legal_moves(st)
        if not lm:
            return 'CHECKMATE' if self.in_check(st) else 'STALEMATE'
        dh=self.dead_hook(st)
        if dh=='DEAD': return 'DEAD_POSITION'
        k=self.rep_key(st)
        if st.get('rep_counts',{}).get(k,0)>=5: return 'FIVEFOLD_REPETITION'
        if st.get('halfmove_clock',0)>=150: return 'SEVENTYFIVE_MOVE'
        return 'ACTIVE' if dh!='UNKNOWN' else 'ACTIVE_DEADNESS_UNRESOLVED'
