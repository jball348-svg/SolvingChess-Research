from __future__ import annotations
import json, random, time, hashlib, os, sys
from collections import Counter
from engine_a import EngineA
from engine_b import EngineB

A=EngineA(); B=EngineB()
FILES='abcdefgh'

def board64_from_fen(fen_board:str)->str:
    ranks=fen_board.split('/')
    if len(ranks)!=8: raise ValueError('bad fen')
    rows=[]
    for rank in ranks:
        row=''
        for c in rank:
            if c.isdigit(): row+='.'*int(c)
            else: row+=c
        if len(row)!=8: raise ValueError('bad rank')
        rows.append(row)
    # FEN ranks 8 -> 1; board64 is a1 -> h8
    return ''.join(reversed(rows))

def state_from_fen(fen:str, provenance='ARENA_ADMISSIBLE', canonicalize_ep=True):
    parts=fen.split(); board=board64_from_fen(parts[0]); turn=parts[1]; cast='' if parts[2]=='-' else parts[2]; nominal=None if parts[3]=='-' else parts[3]; hm=int(parts[4]) if len(parts)>4 else 0
    st={'board64':board,'turn':turn,'castling_rights':''.join(c for c in 'KQkq' if c in cast),'ep_effective':nominal,'halfmove_clock':hm,'rep_counts':{},'provenance':provenance}
    if canonicalize_ep and nominal:
        epa=A.canonicalize_ep(st,nominal); epb=B.canonicalize_ep(st,nominal)
        if epa!=epb: raise AssertionError(('ep canonical mismatch',fen,epa,epb))
        st['ep_effective']=epa
    k=A.rep_key(st); assert k==B.rep_key(st); st['rep_counts']={k:1}
    return st

def initial_state():
    return state_from_fen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', provenance='START_REACHABLE')

def sem(st):
    return {k:st[k] for k in ('board64','turn','castling_rights','ep_effective','halfmove_clock','rep_counts','provenance')}

def compare_state(st, where=''):
    ma=A.legal_moves(st); mb=B.legal_moves(st)
    if ma!=mb: raise AssertionError({'where':where,'A_only':sorted(set(ma)-set(mb)),'B_only':sorted(set(mb)-set(ma)),'A':ma,'B':mb,'state':st})
    if A.in_check(st)!=B.in_check(st): raise AssertionError(('check mismatch',where,st))
    if A.claim_actions(st)!=B.claim_actions(st): raise AssertionError(('claim mismatch',where,A.claim_actions(st),B.claim_actions(st)))
    if A.dead_hook(st)!=B.dead_hook(st): raise AssertionError(('dead hook mismatch',where))
    if A.normalize_local_serialization(st)!=B.normalize_local_serialization(st): raise AssertionError(('serializer mismatch',where))
    if sem(A.deserialize_local(A.serialize_local(st)))!=sem(st): raise AssertionError(('A serializer roundtrip',where))
    if sem(B.deserialize_local(B.serialize_local(st)))!=sem(st): raise AssertionError(('B serializer roundtrip',where))
    va=A.validate(st); vb=B.validate(st)
    if va!=vb: raise AssertionError(('validation mismatch',where,va,vb,st))
    return ma

def compare_state_fast(st, where=''):
    ma=A.legal_moves(st); mb=B.legal_moves(st)
    if ma!=mb: raise AssertionError({'where':where,'A_only':sorted(set(ma)-set(mb)),'B_only':sorted(set(mb)-set(ma)),'state':st})
    if A.in_check(st)!=B.in_check(st): raise AssertionError(('check mismatch',where,st))
    if A.normalize_local_serialization(st)!=B.normalize_local_serialization(st): raise AssertionError(('serializer mismatch',where))
    if sem(A.deserialize_local(A.serialize_local(st)))!=sem(st): raise AssertionError(('A serializer roundtrip',where))
    if sem(B.deserialize_local(B.serialize_local(st)))!=sem(st): raise AssertionError(('B serializer roundtrip',where))
    va=A.validate(st); vb=B.validate(st)
    if va!=vb: raise AssertionError(('validation mismatch',where,va,vb,st))
    return ma

def transition_compare_fast(st,mv,where=''):
    ca=A.transition(st,mv,classify_terminal=False); cb=B.transition(st,mv,classify_terminal=False)
    if sem(ca)!=sem(cb): raise AssertionError(('transition mismatch',where,mv,sem(ca),sem(cb)))
    return ca

def transition_compare(st,mv,where=''):
    ca=A.transition(st,mv); cb=B.transition(st,mv)
    if sem(ca)!=sem(cb) or ca.get('terminal')!=cb.get('terminal'):
        raise AssertionError(('transition mismatch',where,mv,sem(ca),sem(cb),ca.get('terminal'),cb.get('terminal')))
    # independent undo/witness round-trip
    ca2,ra=A.transition_with_undo(st,mv); cb2,rb=B.transition_with_undo(st,mv)
    if sem(A.undo(ca2,ra))!=sem(st) or sem(B.undo(cb2,rb))!=sem(st): raise AssertionError(('undo mismatch',where,mv))
    return ca

def perft(engine,st,depth):
    if depth==0: return 1
    moves=engine.legal_moves(st)
    if depth==1: return len(moves)
    total=0
    for mv in moves:
        child=engine.transition(st,mv,classify_terminal=False)
        total += perft(engine,child,depth-1)
    return total

def curated_tests(ledger):
    tests=[]
    def T(name,fen,check=None, ep_expect='skip'):
        nominal=fen.split()[3]
        st=state_from_fen(fen)
        moves=compare_state(st,name)
        if check: check(st,moves)
        tests.append({'name':name,'moves':len(moves),'in_check':A.in_check(st),'ep_effective':st['ep_effective']})
        return st,moves

    st,m=T('initial','rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError('initial')) if len(m)!=20 else None)
    T('castle_both_clear','r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if not {'e1g1','e1c1'}<=set(m) else None)
    T('castle_through_check','4kr2/8/8/8/8/8/8/4K2R w K - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if 'e1g1' in m else None)
    T('castle_into_check','4k1r1/8/8/8/8/8/8/4K2R w K - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if 'e1g1' in m else None)
    T('ep_legal','k7/8/8/3pP3/8/8/8/7K w - d6 0 2',lambda s,m: (_ for _ in ()).throw(AssertionError((s['ep_effective'],m))) if not(s['ep_effective']=='d6' and 'e5d6' in m) else None)
    T('ep_pinned_canonical_null','k3r3/8/8/3pP3/8/8/8/4K3 w - d6 0 2',lambda s,m: (_ for _ in ()).throw(AssertionError((s['ep_effective'],m))) if not(s['ep_effective'] is None and 'e5d6' not in m) else None)
    T('promotion_four','7k/P7/8/8/8/8/8/7K w - - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if not {'a7a8q','a7a8r','a7a8b','a7a8n'}<=set(m) else None)
    T('capture_promotions_eight','1r5k/P7/8/8/8/8/8/7K w - - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if len([x for x in m if x.startswith('a7')])!=8 else None)
    T('check_evasion','4r2k/8/8/8/8/8/8/4K3 w - - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if (not A.in_check(s) or 'e1e2' in m) else None)
    mate,_=T('checkmate','7k/6Q1/6K1/8/8/8/8/8 b - - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if not(A.in_check(s) and len(m)==0) else None)
    stale,_=T('stalemate','7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',lambda s,m: (_ for _ in ()).throw(AssertionError(m)) if not((not A.in_check(s)) and len(m)==0) else None)
    assert A.terminal_after_move(mate)==B.terminal_after_move(mate)=='CHECKMATE'
    assert A.terminal_after_move(stale)==B.terminal_after_move(stale)=='STALEMATE'
    # Deadness sound controls + unknown negative-control posture.
    dead_fens=[
        ('K_vs_K','8/8/8/8/8/8/4k3/7K w - - 0 1','DEAD'),
        ('KB_vs_K','8/8/8/8/8/8/4k3/2B4K w - - 0 1','DEAD'),
        ('KN_vs_K','8/8/8/8/8/8/4k3/2N4K w - - 0 1','DEAD'),
        ('KNN_vs_K_unknown','8/8/8/8/8/8/4k3/1NN4K w - - 0 1','UNKNOWN'),
    ]
    for name,fen,expected in dead_fens:
        s=state_from_fen(fen); compare_state(s,name); assert A.dead_hook(s)==B.dead_hook(s)==expected; tests.append({'name':name,'dead_hook':expected})

    # Castling rights transitions / rook capture barriers.
    s=state_from_fen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')
    c=transition_compare(s,'h1h2','rook_move_right_loss'); assert c['castling_rights']=='Qkq' and c['rep_counts']=={A.rep_key(c):1}; rights_move=c['castling_rights']
    s=state_from_fen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')
    c=transition_compare(s,'a1a8','rook_capture_double_right_loss'); assert c['castling_rights']=='Kk'; rights_capture=c['castling_rights']
    tests += [{'name':'rook_move_right_loss','rights':rights_move},{'name':'rook_capture_double_right_loss','rights':rights_capture}]

    # Claim NOW controls.
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 0 1')
    k=A.rep_key(s); s['rep_counts'][k]=3; assert 'CLAIM_3_NOW' in A.claim_actions(s)==B.claim_actions(s)
    s50=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 100 1'); assert 'CLAIM_50_NOW' in A.claim_actions(s50) and A.claim_actions(s50)==B.claim_actions(s50)
    # Claim by move: seed a legal quiet successor key with count 2.
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 0 1'); mv='g2g3'; probe=A.transition(s,mv,classify_terminal=False); pk=A.rep_key(probe); s['rep_counts'][pk]=2
    compare_state(s,'threefold_by_move_seeded'); assert 'CLAIM_3_BY_MOVE:'+mv in A.claim_actions(s)
    # 50 by move
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 99 1'); compare_state(s,'fifty_by_move'); assert any(x.startswith('CLAIM_50_BY_MOVE:') for x in A.claim_actions(s))
    tests += [{'name':'claim_controls','threefold_now':True,'threefold_by_move':True,'fifty_now':True,'fifty_by_move':True}]

    # Fivefold automatic on a quiet successor (seed successor with 4 prior occurrences).
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 0 1'); mv='g2g3'; p=A.transition(s,mv,classify_terminal=False); s['rep_counts'][A.rep_key(p)]=4
    c=transition_compare(s,mv,'fivefold_auto'); assert c['terminal']=='FIVEFOLD_REPETITION'
    # 75 move automatic and mate precedence.
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 149 1'); c=transition_compare(s,'g2g3','75_auto'); assert c['terminal']=='SEVENTYFIVE_MOVE'
    s=state_from_fen('7k/5Q2/6K1/8/8/8/8/8 w - - 149 1'); c=transition_compare(s,'f7g7','mate_over_75'); assert c['terminal']=='CHECKMATE' and c['halfmove_clock']==150
    tests += [{'name':'automatic_draw_controls','fivefold':True,'seventyfive':True,'mate_precedence_150':True}]

    # Barrier / non-barrier history behavior.
    s=state_from_fen('7k/8/8/8/8/8/P5R1/7K w - - 0 1'); s['rep_counts']['old-key']=2
    c=transition_compare(s,'a2a3','pawn_barrier'); assert c['halfmove_clock']==0 and len(c['rep_counts'])==1 and 'old-key' not in c['rep_counts']
    s=state_from_fen('7k/8/8/8/8/8/6R1/7K w - - 7 1'); s['rep_counts']['old-key']=2
    c=transition_compare(s,'g2g3','quiet_nonbarrier'); assert c['halfmove_clock']==8 and c['rep_counts'].get('old-key')==2
    tests += [{'name':'history_barriers','pawn_reset':True,'quiet_preserve':True}]

    # Malformed / locally inconsistent corpus.
    bad=[]
    def badcase(name,fen=None,mut=None,expected='MALFORMED'):
        s=state_from_fen(fen,canonicalize_ep=False) if fen else initial_state()
        if mut: mut(s)
        # If mutation changes semantic key, ensure rep map doesn't create spurious mismatch unless testing it.
        if mut and name not in ('rep_missing',):
            s['rep_counts']={A.rep_key(s):1}
        va=A.validate(s); vb=B.validate(s); assert va==vb and va[0]==expected,(name,va,vb)
        bad.append({'name':name,'status':va[0],'issues':va[1]})
    badcase('missing_black_king',mut=lambda s:s.update(board64=s['board64'].replace('k','.')))
    badcase('adjacent_kings','8/8/8/8/8/8/4k3/4K3 w - - 0 1')
    badcase('castling_without_rook','4k3/8/8/8/8/8/8/4K3 w K - 0 1')
    badcase('pawn_backrank','7k/8/8/8/8/8/8/P6K w - - 0 1')
    # ineffective EP deliberately not canonicalized
    badcase('ineffective_ep','k3r3/8/8/3pP3/8/8/8/4K3 w - d6 0 2', expected='HISTORY_INCONSISTENT')
    badcase('nonmoving_king_in_check','4k3/8/8/8/8/8/4R3/7K w - - 0 1')
    badcase('promotion_material_infeasible','7k/8/8/8/8/8/PPPPPPPP/QQ5K w - - 0 1')
    tests += bad
    ledger['curated']=tests


def perft_tests(ledger):
    # Fixed external/reference anchors selected before this run.
    anchors=[
      ('start',initial_state(),[(1,20),(2,400),(3,8902),(4,197281)]),
      ('perft_position_3',state_from_fen('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'),[(1,14),(2,191),(3,2812),(4,43238)]),
      ('perft_position_5',state_from_fen('rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8'),[(1,44),(2,1486),(3,62379)]),
    ]
    rows=[]
    for name,st,ds in anchors:
        for d,expected in ds:
            vals=[]
            for eng in (A,B):
                t=time.time(); n=perft(eng,st,d); vals.append((n,time.time()-t))
            if vals[0][0]!=expected or vals[1][0]!=expected: raise AssertionError(('perft',name,d,expected,vals))
            rows.append({'position':name,'depth':d,'expected':expected,'A':vals[0][0],'B':vals[1][0],'A_s':round(vals[0][1],6),'B_s':round(vals[1][1],6)})
    ledger['perft']=rows

def exhaustive_kings(ledger):
    checked=0; mism=0; edges=0; t=time.time()
    base=['.']*64
    for wk in range(64):
      for bk in range(64):
        if wk==bk or max(abs(wk%8-bk%8),abs(wk//8-bk//8))<=1: continue
        b=base.copy(); b[wk]='K'; b[bk]='k'; board=''.join(b)
        for turn in ('w','b'):
            st={'board64':board,'turn':turn,'castling_rights':'','ep_effective':None,'halfmove_clock':0,'rep_counts':{},'provenance':'ARENA_ADMISSIBLE'}
            k=A.rep_key(st); st['rep_counts']={k:1}
            ma=A.legal_moves(st); mb=B.legal_moves(st); checked+=1; edges+=len(ma)
            if ma!=mb or A.in_check(st)!=B.in_check(st): mism+=1; raise AssertionError(('KvsK',wk,bk,turn,ma,mb))
    ledger['exhaustive_kings']={'states':checked,'legal_edges_A':edges,'mismatches':mism,'seconds':round(time.time()-t,6)}


def exhaustive_three_piece_slices(ledger):
    # The initially declared files a-d slice exceeded a 300 s execution budget before completion;
    # no partial result from that timed-out run is accepted. The replacement a-file slice was
    # frozen solely on runtime grounds, before inspecting any outcome/mismatch result.
    ledger['tractability_holds']=[{'domain':'all K+R vs K and K+P vs K placements, extra piece files a-d, both turns','status':'HOLD_NO_RESULT','reason':'single-run wall time exceeded 300 s before completion'}]
    rows=[]
    for piece in ('R','P'):
        checked=0; edges=0; t=time.time()
        x=0
        for y in range(8):
            if piece=='P' and y in (0,7): continue
            ps=y*8+x
            for wk in range(64):
              if wk==ps: continue
              for bk in range(64):
                if bk in (ps,wk) or max(abs(wk%8-bk%8),abs(wk//8-bk//8))<=1: continue
                arr=['.']*64; arr[wk]='K'; arr[bk]='k'; arr[ps]=piece; board=''.join(arr)
                for turn in ('w','b'):
                    st={'board64':board,'turn':turn,'castling_rights':'','ep_effective':None,'halfmove_clock':0,'rep_counts':{},'provenance':'ARENA_ADMISSIBLE'}; st['rep_counts']={A.rep_key(st):1}
                    va=A.validate(st); vb=B.validate(st)
                    if va!=vb: raise AssertionError(('slice validation',piece,ps,wk,bk,turn,va,vb))
                    if va[0] != 'ARENA_ADMISSIBLE': continue
                    ma=A.legal_moves(st); mb=B.legal_moves(st); checked+=1; edges+=len(ma)
                    if ma!=mb: raise AssertionError(('slice',piece,ps,wk,bk,turn,ma,mb))
        rows.append({'piece':piece,'extra_piece_file':'a','states':checked,'legal_edges_A':edges,'mismatches':0,'seconds':round(time.time()-t,6)})
    ledger['exhaustive_three_piece_slices']=rows

def reachable_fuzz(ledger, seed=110011, games=24, maxplies=64):
    ledger.setdefault('tractability_holds',[]).append({'domain':'reachable fuzz 120 games x 80 plies','status':'HOLD_NO_RESULT','reason':'combined run exceeded 300 s command budget before fuzz completion; no partial result accepted'})
    rng=random.Random(seed); states=0; transitions=0; terminal_spotchecks=0; undo_spotchecks=0; term=Counter(); moveclass=Counter(); t=time.time()
    for g in range(games):
        st=initial_state()
        for ply in range(maxplies):
            moves=compare_state_fast(st,f'fuzz_g{g}_p{ply}'); states+=1
            if not moves: term['no_legal']+=1; break
            mv=rng.choice(moves)
            p=st['board64'][(ord(mv[0])-97)+8*(int(mv[1])-1)]
            if p.upper()=='P': moveclass['pawn']+=1
            if len(mv)==5: moveclass['promotion']+=1
            if p.upper()=='K' and abs(ord(mv[2])-ord(mv[0]))==2: moveclass['castle']+=1
            if st.get('ep_effective') and mv[2:4]==st['ep_effective'] and p.upper()=='P' and mv[0]!=mv[2]: moveclass['ep']+=1
            child=transition_compare_fast(st,mv,f'fuzz_g{g}_p{ply}'); transitions+=1
            if transitions % 19 == 0:
                ca,ra=A.transition_with_undo(st,mv); cb,rb=B.transition_with_undo(st,mv)
                if sem(A.undo(ca,ra))!=sem(st) or sem(B.undo(cb,rb))!=sem(st): raise AssertionError(('undo fuzz mismatch',g,ply))
                undo_spotchecks+=1
            # Every 17th transition independently compares terminal classification too.
            if transitions % 17 == 0:
                ta=A.terminal_after_move(child); tb=B.terminal_after_move(child)
                if ta!=tb: raise AssertionError(('terminal spot mismatch',g,ply,ta,tb))
                terminal_spotchecks+=1; term[ta]+=1
                if ta not in ('ACTIVE','ACTIVE_DEADNESS_UNRESOLVED'): break
            st=child
    ledger['reachable_fuzz']={'seed':seed,'games':games,'maxplies':maxplies,'states_compared':states,'transitions_compared':transitions,'terminal_spotchecks':terminal_spotchecks,'undo_spotchecks':undo_spotchecks,'mismatches':0,'terminal_spotcheck_counts':dict(term),'move_classes':dict(moveclass),'seconds':round(time.time()-t,6)}


def attack_map_fuzz(ledger, seed=110013, boards=2000):
    rng=random.Random(seed); queries=0; t=time.time(); piece_pool='PNBRQpnbrq'
    for case in range(boards):
        squares=list(range(64)); rng.shuffle(squares)
        wk=squares.pop(); bk=squares.pop()
        # force distinct, usually nonadjacent but raw attack equivalence does not require legal history
        arr=['.']*64; arr[wk]='K'; arr[bk]='k'
        for _ in range(rng.randint(0,12)):
            if not squares: break
            q=squares.pop(); arr[q]=rng.choice(piece_pool)
        board=''.join(arr); amap={(i%8,i//8):p for i,p in enumerate(board) if p!='.'}
        bl=list(board)
        for side in ('w','b'):
            for target in range(64):
                aa=A._attacked(bl,target,side); bb=B.attacked_map(amap,(target%8,target//8),side); queries+=1
                if aa!=bb: raise AssertionError(('attack map mismatch',case,side,target,board,aa,bb))
    ledger['attack_map_fuzz']={'seed':seed,'boards':boards,'square_side_queries':queries,'mismatches':0,'seconds':round(time.time()-t,6)}


def mixed_board_fuzz(ledger, seed=110014, accepted_target=5000):
    rng=random.Random(seed); accepted=0; attempted=0; transitions=0; t=time.time(); pool='PNBRQpnbrq'
    piece_hist=Counter(); turn_hist=Counter()
    while accepted<accepted_target and attempted<accepted_target*20:
        attempted+=1; arr=['.']*64
        wk=rng.randrange(64); bk=rng.randrange(64)
        if wk==bk or max(abs(wk%8-bk%8),abs(wk//8-bk//8))<=1: continue
        arr[wk]='K'; arr[bk]='k'; used={wk,bk}
        for _ in range(rng.randint(0,10)):
            choices=[q for q in range(64) if q not in used]
            if not choices: break
            q=rng.choice(choices); p=rng.choice(pool)
            if p in 'Pp' and q//8 in (0,7): continue
            arr[q]=p; used.add(q)
        turn=rng.choice(('w','b')); board=''.join(arr)
        st={'board64':board,'turn':turn,'castling_rights':'','ep_effective':None,'halfmove_clock':rng.randrange(0,150),'rep_counts':{},'provenance':'ARENA_ADMISSIBLE'}
        st['rep_counts']={A.rep_key(st):1}
        va=A.validate(st); vb=B.validate(st)
        if va!=vb: raise AssertionError(('mixed validate mismatch',attempted,va,vb,st))
        if va[0]!='ARENA_ADMISSIBLE': continue
        moves=compare_state_fast(st,f'mixed_{accepted}')
        accepted+=1; turn_hist[turn]+=1
        for p in board:
            if p!='.': piece_hist[p]+=1
        if moves and transitions<2000:
            mv=rng.choice(moves); transition_compare_fast(st,mv,f'mixed_transition_{transitions}'); transitions+=1
    if accepted<accepted_target: raise AssertionError(('mixed fuzz insufficient accepted',accepted,attempted))
    ledger['mixed_board_fuzz']={'seed':seed,'attempted':attempted,'accepted':accepted,'transition_samples':transitions,'mismatches':0,'turn_counts':dict(turn_hist),'aggregate_piece_occurrences':dict(piece_hist),'seconds':round(time.time()-t,6)}


def ep_adversarial_fuzz(ledger, seed=110015, cases=2000):
    rng=random.Random(seed); t=time.time(); effective=0; null=0; validated=0; mism=0
    extras='RBNQrbnq'
    for i in range(cases):
        white_case=(i%2==0)
        arr=['.']*64
        # pick kings away from fixed pawns; retry until nonadjacent and distinct
        fixed={36,35} if white_case else {27,28}  # e5,d5 or d4,e4
        avail=[q for q in range(64) if q not in fixed]
        while True:
            wk,bk=rng.sample(avail,2)
            if max(abs(wk%8-bk%8),abs(wk//8-bk//8))>1: break
        arr[wk]='K'; arr[bk]='k'
        if white_case:
            arr[36]='P'; arr[35]='p'; turn='w'; nominal='d6'
        else:
            arr[27]='P'; arr[28]='p'; turn='b'; nominal='d3'
        used={wk,bk}|fixed
        for _ in range(rng.randint(0,5)):
            choices=[q for q in range(64) if q not in used]
            if not choices: break
            q=rng.choice(choices); arr[q]=rng.choice(extras); used.add(q)
        st={'board64':''.join(arr),'turn':turn,'castling_rights':'','ep_effective':nominal,'halfmove_clock':0,'rep_counts':{},'provenance':'ARENA_ADMISSIBLE'}
        ea=A.canonicalize_ep(st,nominal); eb=B.canonicalize_ep(st,nominal)
        if ea!=eb: raise AssertionError(('EP canonical mismatch',i,ea,eb,st))
        if ea: effective+=1
        else: null+=1
        st['ep_effective']=ea; st['rep_counts']={A.rep_key(st):1}
        va=A.validate(st); vb=B.validate(st)
        if va!=vb: raise AssertionError(('EP validation mismatch',i,va,vb,st))
        if va[0]=='ARENA_ADMISSIBLE':
            compare_state_fast(st,f'ep_adv_{i}'); validated+=1
    ledger['ep_adversarial_fuzz']={'seed':seed,'cases':cases,'effective_ep':effective,'canonical_null':null,'locally_admissible_compared':validated,'mismatches':mism,'seconds':round(time.time()-t,6)}

def mutation_fuzz(ledger, seed=110012, cases=5000):
    rng=random.Random(seed); status=Counter(); t=time.time()
    base=initial_state()
    for i in range(cases):
        s=json.loads(json.dumps(base)); mode=rng.randrange(10); arr=list(s['board64'])
        if mode==0: arr[arr.index('k')]='.'
        elif mode==1:
            # force kings adjacent at e1/e2
            arr=['.']*64; arr[4]='K'; arr[12]='k'
        elif mode==2: s['castling_rights']='K'; arr[7]='.'
        elif mode==3: arr[0]='P'
        elif mode==4: s['halfmove_clock']=150
        elif mode==5: s['turn']='x'
        elif mode==6: s['castling_rights']='KK'
        elif mode==7: s['ep_effective']='a4'
        elif mode==8:
            arr=['.']*64; arr[7]='K'; arr[12]='R'; arr[60]='k'; s['turn']='w'; s['castling_rights']=''
        elif mode==9:
            arr=['.']*64; arr[7]='K'; arr[63]='k'; [arr.__setitem__(8+i,'P') for i in range(8)]; arr[0]='Q'; arr[1]='Q'; s['castling_rights']=''
        s['board64']=''.join(arr); s['rep_counts']={A.rep_key(s):1}
        va=A.validate(s); vb=B.validate(s)
        if va!=vb: raise AssertionError(('mutation validation mismatch',i,mode,va,vb))
        status[va[0]]+=1
    ledger['mutation_fuzz']={'seed':seed,'cases':cases,'status_counts':dict(status),'mismatches':0,'seconds':round(time.time()-t,6)}


def main():
    ledger={'programme':'G11','engines':[A.name,B.name],'local_serialization_profile':'G11LC1 (cross-engine only; G10 canonical bundle unavailable)','started_unix':time.time()}
    phases=[('curated',curated_tests),('perft',perft_tests),('exhaustive_kings',exhaustive_kings),('exhaustive_three_piece_slices',exhaustive_three_piece_slices),('attack_map_fuzz',attack_map_fuzz),('mixed_board_fuzz',mixed_board_fuzz),('ep_adversarial_fuzz',ep_adversarial_fuzz),('reachable_fuzz',reachable_fuzz),('mutation_fuzz',mutation_fuzz)]
    for name,fn in phases:
        t=time.time(); print('RUN',name,flush=True); fn(ledger); print('PASS',name,'%.3fs'%(time.time()-t),flush=True)
    ledger['finished_unix']=time.time(); ledger['overall']='PASS_WITH_G10_ARTIFACT_GAP'
    payload=json.dumps(ledger,sort_keys=True,indent=2).encode()
    ledger['ledger_sha256_pre_self']=hashlib.sha256(payload).hexdigest()
    out='/mnt/data/g11_work/G11_Conformance_Ledger.json'
    with open(out,'w') as f: json.dump(ledger,f,sort_keys=True,indent=2)
    print('WROTE',out)
    print(json.dumps(ledger,indent=2,sort_keys=True))

if __name__=='__main__': main()
