#include <bits/stdc++.h>
using namespace std;
static inline int F(int s){return s&7;} static inline int R(int s){return s>>3;} static inline int cheb(int a,int b){return max(abs(F(a)-F(b)),abs(R(a)-R(b)));}
static inline bool wpAtt(int p,int s){return R(s)==R(p)+1&&abs(F(s)-F(p))==1;} static inline bool bpAtt(int p,int s){return R(s)==R(p)-1&&abs(F(s)-F(p))==1;}
vector<int> KM[64],NM[64];void init(){for(int s=0;s<64;s++){for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++)if(dr||df){int r=R(s)+dr,f=F(s)+df;if(r>=0&&r<8&&f>=0&&f<8)KM[s].push_back(r*8+f);}int d[8][2]={{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1},{-2,1},{-1,2}};for(auto &x:d){int f=F(s)+x[0],r=R(s)+x[1];if(f>=0&&f<8&&r>=0&&r<8)NM[s].push_back(r*8+f);}}}
enum PT{KNIGHT=0,BISHOP=1,ROOK=2};
struct DB{
 static constexpr int WP=51,BP=13,PROMO=59; // d7,f2,d8
 static constexpr int SZ=65*2*2*64*64*2;
 PT pt; vector<uint8_t>valid,win;vector<uint16_t>total;vector<int16_t>dist;vector<uint32_t>off,pred;vector<int>ids;long long edges=0;
 DB(PT p):pt(p),valid(SZ),win(SZ),total(SZ),dist(SZ,-1){}
 static int enc(int m,int wp,int bp,int wk,int bk,int t){return (((((m*2+wp)*2+bp)*64+wk)*64+bk)*2+t);}
 static void dec(int id,int&m,int&wp,int&bp,int&wk,int&bk,int&t){t=id&1;id>>=1;bk=id%64;id/=64;wk=id%64;id/=64;bp=id%2;id/=2;wp=id%2;id/=2;m=id;}
 static int msq(int m){return m?m-1:-1;}
 bool batt(int b,int s,int wk,int wp,int bp,int bk,bool includeBKblock=false)const{int df=F(s)-F(b),dr=R(s)-R(b);if(!df||abs(df)!=abs(dr))return false;int sf=df>0?1:-1,sr=dr>0?1:-1;for(int f=F(b)+sf,r=R(b)+sr;f!=F(s)||r!=R(s);f+=sf,r+=sr){int q=r*8+f;if(q==wk||(wp&&q==WP)||(bp&&q==BP)||(includeBKblock&&q==bk))return false;}return true;}
 bool ratt(int ro,int s,int wk,int wp,int bp)const{if(F(ro)!=F(s)&&R(ro)!=R(s))return false;int sf=(F(s)>F(ro))-(F(s)<F(ro)),sr=(R(s)>R(ro))-(R(s)<R(ro));for(int f=F(ro)+sf,r=R(ro)+sr;f!=F(s)||r!=R(s);f+=sf,r+=sr){int q=r*8+f;if(q==wk||(wp&&q==WP)||(bp&&q==BP))return false;}return true;}
 bool mattBK(int m,int wp,int bp,int wk,int bk)const{if(!m)return false;int q=msq(m);if(pt==KNIGHT)return find(NM[q].begin(),NM[q].end(),bk)!=NM[q].end();if(pt==BISHOP)return batt(q,bk,wk,wp,bp,bk,false);return ratt(q,bk,wk,wp,bp);}
 bool mattSq(int m,int target,int wp,int bp,int wk)const{if(!m)return false;int q=msq(m);if(pt==KNIGHT)return find(NM[q].begin(),NM[q].end(),target)!=NM[q].end();if(pt==BISHOP)return batt(q,target,wk,wp,bp,target,false);return ratt(q,target,wk,wp,bp);}
 bool val(int m,int wp,int bp,int wk,int bk,int t)const{int q=msq(m);if(wk==bk||cheb(wk,bk)<=1)return false;if(m&&(q==wk||q==bk))return false;if(wp&&(WP==wk||WP==bk||(m&&WP==q)))return false;if(bp&&(BP==wk||BP==bk||(m&&BP==q)))return false;if(t==0){if((wp&&wpAtt(WP,bk))||mattBK(m,wp,bp,wk,bk))return false;}else{if(bp&&bpAtt(BP,wk))return false;}return true;}
 bool inCheck(int m,int wp,int bp,int wk,int bk,int t)const{return t==0?(bp&&bpAtt(BP,wk)):((wp&&wpAtt(WP,bk))||mattBK(m,wp,bp,wk,bk));}
 void gen(int m,int wp,int bp,int wk,int bk,int t,vector<int>&su,int&ew,int&en)const{su.clear();ew=en=0;int mq=msq(m);if(t==0){
   for(int nw:KM[wk]){if(nw==bk||cheb(nw,bk)<=1||(m&&nw==mq)||(wp&&nw==WP))continue;int nbp=bp;if(bp&&nw==BP)nbp=0;else if(bp&&bpAtt(BP,nw))continue;int id=enc(m,wp,nbp,nw,bk,1);if(val(m,wp,nbp,nw,bk,1))su.push_back(id);}
   if(m){if(pt==KNIGHT){for(int nq:NM[mq]){if(nq==wk||nq==bk||(wp&&nq==WP))continue;int nbp=bp;if(bp&&nq==BP)nbp=0;int nm=nq+1;int id=enc(nm,wp,nbp,wk,bk,1);if(val(nm,wp,nbp,wk,bk,1))su.push_back(id);}}
     else {int bdirs[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}},rdirs[4][2]={{1,0},{-1,0},{0,1},{0,-1}};int (*dirs)[2]=(pt==BISHOP?bdirs:rdirs);for(int di=0;di<4;di++){auto &d=dirs[di];int f=F(mq)+d[0],r=R(mq)+d[1];while(f>=0&&f<8&&r>=0&&r<8){int nq=r*8+f;if(nq==wk||nq==bk||(wp&&nq==WP))break;int nbp=bp;if(bp&&nq==BP)nbp=0;int nm=nq+1;int id=enc(nm,wp,nbp,wk,bk,1);if(val(nm,wp,nbp,wk,bk,1))su.push_back(id);if(bp&&nq==BP)break;f+=d[0];r+=d[1];}}}
   }
   if(wp){ // d7-d8 promotion if clear
     if(PROMO!=wk&&PROMO!=bk&&(!m||PROMO!=mq)&&(!bp||PROMO!=BP))ew++;
   }
 }else{
   for(int nb:KM[bk]){if(nb==wk||cheb(nb,wk)<=1||(bp&&nb==BP))continue;int nm=m,nwp=wp;if(wp&&nb==WP)nwp=0;if(m&&nb==mq)nm=0;if(nwp&&wpAtt(WP,nb))continue;if(nm&&mattSq(nm,nb,nwp,bp,wk))continue;int id=enc(nm,nwp,bp,wk,nb,0);if(val(nm,nwp,bp,wk,nb,0))su.push_back(id);}
   if(bp){ // f2-f1 promotion straight, or capture-promote minor on e1/g1. Any such exit is White non-win.
     int f1=5;if(f1!=wk&&f1!=bk&&(!m||f1!=mq)&&(!wp||f1!=WP))en++;
     if(m&&(mq==4||mq==6))en++; // e1/g1 minor capture-promotion; WK cannot share mq
   }
 }}
 void build(){ids.reserve(1600000);for(int m=0;m<=64;m++)for(int wp=0;wp<2;wp++)for(int bp=0;bp<2;bp++)for(int wk=0;wk<64;wk++)for(int bk=0;bk<64;bk++)for(int t=0;t<2;t++){int id=enc(m,wp,bp,wk,bk,t);if(val(m,wp,bp,wk,bk,t)){valid[id]=1;ids.push_back(id);}}vector<uint32_t>ind(SZ);vector<int>su;int ew,en;for(int id:ids){int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);gen(m,wp,bp,wk,bk,t,su,ew,en);total[id]=su.size()+ew+en;for(int s:su){ind[s]++;edges++;}}off.assign(SZ+1,0);for(int i=0;i<SZ;i++)off[i+1]=off[i]+ind[i];vector<uint32_t>cur=off;pred.resize(edges);for(int id:ids){int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);gen(m,wp,bp,wk,bk,t,su,ew,en);for(int s:su)pred[cur[s]++]=id;}cerr<<"valid="<<ids.size()<<" edges="<<edges<<"\n";}
 void solve(){vector<uint16_t>rem=total;deque<int>q;vector<int>su;int ew,en;for(int id:ids){int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);gen(m,wp,bp,wk,bk,t,su,ew,en);if(t==0&&ew){win[id]=1;dist[id]=1;q.push_back(id);}else if(t==1&&total[id]==0&&inCheck(m,wp,bp,wk,bk,t)){win[id]=1;dist[id]=0;q.push_back(id);}}
 while(!q.empty()){int s=q.front();q.pop_front();for(uint32_t k=off[s];k<off[s+1];k++){int p=pred[k];if(win[p])continue;int m,wp,bp,wk,bk,t;dec(p,m,wp,bp,wk,bk,t);if(t==0){win[p]=1;q.push_back(p);}else{if(rem[p])rem[p]--;if(rem[p]==0&&total[p]>0){win[p]=1;q.push_back(p);}}}}
 }
 void audit(){vector<int>su;int ew,en;long long bad=0;for(int id:ids){int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);gen(m,wp,bp,wk,bk,t,su,ew,en);bool rhs=false;if(t==0){rhs=ew;for(int s:su)rhs|=win[s];}else{if(total[id]==0)rhs=inCheck(m,wp,bp,wk,bk,t);else if(en==0){rhs=true;for(int s:su)if(!win[s]){rhs=false;break;}}}if(rhs!=(bool)win[id])bad++;}cout<<"BELLMAN_BAD="<<bad<<"\n";}
 bool stale(int id)const{int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);if(t!=1)return false;vector<int>su;int ew,en;gen(m,wp,bp,wk,bk,t,su,ew,en);return total[id]==0&&!inCheck(m,wp,bp,wk,bk,t);}
 bool targetSafe(int id)const{int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);return wp&&cheb(wk,PROMO)<=4&&cheb(bk,PROMO)>=5&&!stale(id);}
 bool targetRaceClear(int id)const{if(!targetSafe(id))return false;int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);int TW=2-(t==0),TB=bp?(2-(t==1)):999;return TB>TW&&wk!=PROMO;}
 vector<uint8_t> attr(function<bool(int)>T)const{vector<uint8_t>a(SZ);vector<uint16_t>rem=total;deque<int>q;for(int id:ids)if(T(id)){a[id]=1;q.push_back(id);}while(!q.empty()){int s=q.front();q.pop_front();for(uint32_t k=off[s];k<off[s+1];k++){int p=pred[k];if(a[p])continue;int m,wp,bp,wk,bk,t;dec(p,m,wp,bp,wk,bk,t);if(t==0){a[p]=1;q.push_back(p);}else{if(rem[p])rem[p]--;if(rem[p]==0&&total[p]>0){a[p]=1;q.push_back(p);}}}}return a;}
 void report(const string&name){long long W=0,full=0,fullW=0;for(int id:ids){W+=win[id];int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);if(m&&wp&&bp){full++;fullW+=win[id];}}cout<<name<<" closure="<<ids.size()<<" W="<<W<<" nonW="<<ids.size()-W<<" full="<<full<<" fullW="<<fullW<<" fullNonW="<<full-fullW<<"\n";long long nS=0,bS=0,nR=0,bR=0;map<string,long long>M;for(int id:ids){if(targetSafe(id)){nS++;bS+=!win[id];}if(targetRaceClear(id)){nR++;if(!win[id]){bR++;int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);if(m&&msq(m)==PROMO)M["minor_on_promo"]++;if(t==0)M["WTM"]++;else M["BTM"]++;if(inCheck(m,wp,bp,wk,bk,t))M["in_check"]++;}}}cout<<"TARGET_SAFE n="<<nS<<" bad="<<bS<<" TARGET_RACE_CLEAR n="<<nR<<" bad="<<bR<<"\n";for(auto&x:M)cout<<" bad_"<<x.first<<"="<<x.second;cout<<"\n";if(bR==0){auto A=attr([&](int id){return targetRaceClear(id);});long long an=0,ab=0,afull=0;for(int id:ids){an+=A[id];ab+=A[id]&&!win[id];int m,wp,bp,wk,bk,t;dec(id,m,wp,bp,wk,bk,t);if(m&&wp&&bp)afull+=A[id];}cout<<"ATTR="<<an<<" bad="<<ab<<" fullAttr="<<afull<<"\n";string p="/mnt/data/db_"+name+"_attr.bin";FILE*f=fopen(p.c_str(),"wb");fwrite(A.data(),1,A.size(),f);fclose(f);}string p="/mnt/data/db_"+name+"_win.bin";FILE*f=fopen(p.c_str(),"wb");fwrite(win.data(),1,win.size(),f);fclose(f);}
};
int main(int argc,char**argv){init();string a=argc>1?string(argv[1]):"N";PT p=a=="B"?BISHOP:(a=="R"?ROOK:KNIGHT);string n=p==KNIGHT?"N":(p==BISHOP?"B":"R");DB A(p);A.build();A.solve();A.audit();A.report(n);}
