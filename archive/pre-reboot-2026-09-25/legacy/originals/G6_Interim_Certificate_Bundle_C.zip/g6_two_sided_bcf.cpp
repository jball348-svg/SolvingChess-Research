#include <bits/stdc++.h>
using namespace std;
static inline int F(int s){return s&7;} static inline int R(int s){return s>>3;}
static inline int cheb(int a,int b){return max(abs(F(a)-F(b)),abs(R(a)-R(b)));}
static inline bool wpAtt(int p,int sq){return R(sq)==R(p)+1 && abs(F(sq)-F(p))==1;}
static inline bool bpAtt(int p,int sq){return R(sq)==R(p)-1 && abs(F(sq)-F(p))==1;}

struct Arena {
 static constexpr int FB=1, FC=2, FF=5; // files b,c,f
 static constexpr int NP=7, NSQ=64, NT=2;
 static constexpr int SZ=NP*NP*NP*NSQ*NSQ*NT;
 vector<uint8_t> valid, win;
 vector<int16_t> dist;
 vector<uint16_t> total;
 vector<uint32_t> off, pred;
 vector<int> ids;
 long long edges=0;
 Arena():valid(SZ,0),win(SZ,0),dist(SZ,-1),total(SZ,0){}
 static inline int enc(int pb,int pc,int pf,int wk,int bk,int t){return (((((pb*7+pc)*7+pf)*64+wk)*64+bk)*2+t);}
 static inline void dec(int id,int&pb,int&pc,int&pf,int&wk,int&bk,int&t){t=id&1;id>>=1;bk=id%64;id/=64;wk=id%64;id/=64;pf=id%7;id/=7;pc=id%7;id/=7;pb=id;}
 static inline int psq(int code,int file){if(!code)return -1;int rank=code+1;return (rank-1)*8+file;}
 bool whiteChecksBK(int pb,int pc,int bk) const {int b=psq(pb,FB),c=psq(pc,FC);return (b>=0&&wpAtt(b,bk))||(c>=0&&wpAtt(c,bk));}
 bool blackChecksWK(int pf,int wk) const {int f=psq(pf,FF);return f>=0&&bpAtt(f,wk);}
 bool val(int pb,int pc,int pf,int wk,int bk,int t) const {
   int b=psq(pb,FB),c=psq(pc,FC),f=psq(pf,FF);
   if(wk==bk||cheb(wk,bk)<=1)return false;
   if((b>=0&&(wk==b||bk==b))||(c>=0&&(wk==c||bk==c))||(f>=0&&(wk==f||bk==f)))return false;
   if(t==0 && whiteChecksBK(pb,pc,bk)) return false; // Black not to move already in check invalid
   if(t==1 && blackChecksWK(pf,wk)) return false;   // White not to move already in check invalid
   return true;
 }
 bool inCheck(int pb,int pc,int pf,int wk,int bk,int t) const {return t==0?blackChecksWK(pf,wk):whiteChecksBK(pb,pc,bk);}
 void gen(int pb,int pc,int pf,int wk,int bk,int t, vector<int>&su,int &extW,int &extN) const {
   su.clear();extW=extN=0;int b=psq(pb,FB),c=psq(pc,FC),f=psq(pf,FF);
   if(t==0){
     // White king moves/capture black pawn.
     for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++)if(dr||df){int nr=R(wk)+dr,nf=F(wk)+df;if(nr<0||nr>7||nf<0||nf>7)continue;int nw=nr*8+nf;if(nw==bk||cheb(nw,bk)<=1||nw==b||nw==c)continue;int npf=pf;if(nw==f)npf=0;else if(f>=0&&bpAtt(f,nw))continue;int id=enc(pb,pc,npf,nw,bk,1);if(val(pb,pc,npf,nw,bk,1))su.push_back(id);}
     auto pushW=[&](int code,int file,bool isB){if(!code)return;int p=psq(code,file),rank=code+1; if(rank==7){int q=p+8;if(q!=wk&&q!=bk&&q!=b&&q!=c&&q!=f){extW++;}return;} int q=p+8;if(q==wk||q==bk||q==b||q==c||q==f)return;int nc=code+1;int npb=pb,npc=pc;if(isB)npb=nc;else npc=nc;int id=enc(npb,npc,pf,wk,bk,1);if(val(npb,npc,pf,wk,bk,1))su.push_back(id);if(rank==2){int q2=p+16;if(q2==wk||q2==bk||q2==b||q2==c||q2==f)return;nc=code+2;npb=pb;npc=pc;if(isB)npb=nc;else npc=nc;id=enc(npb,npc,pf,wk,bk,1);if(val(npb,npc,pf,wk,bk,1))su.push_back(id);}};
     pushW(pb,FB,true);pushW(pc,FC,false);
   } else {
     // Black king moves/capture white pawn.
     for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++)if(dr||df){int nr=R(bk)+dr,nf=F(bk)+df;if(nr<0||nr>7||nf<0||nf>7)continue;int nb=nr*8+nf;if(nb==wk||cheb(nb,wk)<=1||nb==f)continue;int npb=pb,npc=pc;if(nb==b)npb=0;if(nb==c)npc=0;int rb=psq(npb,FB),rc=psq(npc,FC);if((rb>=0&&wpAtt(rb,nb))||(rc>=0&&wpAtt(rc,nb)))continue;int id=enc(npb,npc,pf,wk,nb,0);if(val(npb,npc,pf,wk,nb,0))su.push_back(id);}
     // Black pawn push downward.
     if(pf){int p=f,rank=pf+1;if(rank==2){int q=p-8;if(q!=wk&&q!=bk&&q!=b&&q!=c){extN++;}}
       else {int q=p-8;if(q!=wk&&q!=bk&&q!=b&&q!=c){int npf=pf-1;int id=enc(pb,pc,npf,wk,bk,0);if(val(pb,pc,npf,wk,bk,0))su.push_back(id);if(rank==7){int q2=p-16;if(q2!=wk&&q2!=bk&&q2!=b&&q2!=c){npf=pf-2;id=enc(pb,pc,npf,wk,bk,0);if(val(pb,pc,npf,wk,bk,0))su.push_back(id);}}}}
     }
   }
 }
 void build(){
   ids.reserve(SZ*3/4);for(int pb=0;pb<7;pb++)for(int pc=0;pc<7;pc++)for(int pf=0;pf<7;pf++)for(int wk=0;wk<64;wk++)for(int bk=0;bk<64;bk++)for(int t=0;t<2;t++){int id=enc(pb,pc,pf,wk,bk,t);if(val(pb,pc,pf,wk,bk,t)){valid[id]=1;ids.push_back(id);}}
   cerr<<"valid all closure="<<ids.size()<<" raw="<<SZ<<"\n";
   vector<uint32_t> indeg(SZ,0);vector<int> su;su.reserve(16);int ew,en;
   for(int id:ids){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);gen(pb,pc,pf,wk,bk,t,su,ew,en);total[id]=su.size()+ew+en;for(int d:su){indeg[d]++;edges++;}}
   cerr<<"edges="<<edges<<"\n";off.assign(SZ+1,0);for(int i=0;i<SZ;i++)off[i+1]=off[i]+indeg[i];vector<uint32_t> cur=off;pred.resize(edges);
   for(int id:ids){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);gen(pb,pc,pf,wk,bk,t,su,ew,en);for(int d:su)pred[cur[d]++]=id;}
 }
 void solve(){
   vector<uint16_t> rem=total;deque<int> q;vector<int> su;int ew,en;
   // Seeds: WTM with immediate white promotion; BTM checkmate. BTM universal with zero nonwinning obligations can include only internal? no external W for B.
   for(int id:ids){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);gen(pb,pc,pf,wk,bk,t,su,ew,en);if(t==0&&ew){win[id]=1;dist[id]=1;q.push_back(id);}else if(t==1&&total[id]==0&&inCheck(pb,pc,pf,wk,bk,t)){win[id]=1;dist[id]=0;q.push_back(id);}}
   while(!q.empty()){int s=q.front();q.pop_front();for(uint32_t k=off[s];k<off[s+1];k++){int p=pred[k];if(win[p])continue;int pb,pc,pf,wk,bk,t;dec(p,pb,pc,pf,wk,bk,t);if(t==0){win[p]=1;dist[p]=dist[s]+1;q.push_back(p);}else{if(rem[p])rem[p]--;if(rem[p]==0&&total[p]>0){win[p]=1;dist[p]=dist[s]+1;q.push_back(p);}}}}
   long long W=0;for(int id:ids)W+=win[id];cerr<<"closure W="<<W<<" nonW="<<ids.size()-W<<"\n";
 }
 vector<uint8_t> strictAttr(function<bool(int)> target) const {
   vector<uint8_t> a(SZ,0);vector<uint16_t> rem=total;deque<int>q;
   for(int id:ids)if(target(id)){a[id]=1;q.push_back(id);}
   while(!q.empty()){int s=q.front();q.pop_front();for(uint32_t k=off[s];k<off[s+1];k++){int p=pred[k];if(a[p])continue;int pb,pc,pf,wk,bk,t;dec(p,pb,pc,pf,wk,bk,t);if(t==0){a[p]=1;q.push_back(p);}else{if(rem[p])rem[p]--;if(rem[p]==0&&total[p]>0){a[p]=1;q.push_back(p);}}}}
   return a;
 }
 bool immediateStalemate(int id) const {int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);if(t!=1)return false;vector<int>su;int ew,en;gen(pb,pc,pf,wk,bk,t,su,ew,en);return su.empty()&&ew==0&&en==0&&!inCheck(pb,pc,pf,wk,bk,t);}
 static int whiteMovesToProm(int code){if(!code)return 99;int r=code+1;return r==2?5:8-r;}
 static int blackMovesToProm(int code){if(!code)return 99;int r=code+1;return r==7?5:r-1;}
 bool raceTarget(int id,bool whichB) const {int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);int code=whichB?pb:pc,file=whichB?FB:FC;if(code!=6)return false;int promo=7*8+file;if(cheb(wk,promo)>4||cheb(bk,promo)<5)return false;if(immediateStalemate(id))return false;int TW=2*whiteMovesToProm(code)-(t==0?1:0);int TB=pf?2*blackMovesToProm(pf)-(t==1?1:0):999;return TB>TW;}
 void report(){
   long long full=0,fullW=0;for(int id:ids){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);if(pb&&pc&&pf){full++;fullW+=win[id];}}
   cout<<"FULL populated valid="<<full<<" W="<<fullW<<" nonW="<<full-fullW<<"\n";
   long long nb=0,bb=0,nc=0,bc=0;for(int id:ids){if(raceTarget(id,true)){nb++;if(!win[id])bb++;}if(raceTarget(id,false)){nc++;if(!win[id])bc++;}}
   cout<<"TARGET_B n="<<nb<<" bad="<<bb<<" TARGET_C n="<<nc<<" bad="<<bc<<"\n";
   auto AB=strictAttr([&](int id){return raceTarget(id,true);});auto AC=strictAttr([&](int id){return raceTarget(id,false);});auto AU=strictAttr([&](int id){return raceTarget(id,true)||raceTarget(id,false);});
   long long ab=0,ac=0,au=0,pure=0,badAB=0,badAC=0,badAU=0;for(int id:ids){ab+=AB[id];ac+=AC[id];au+=AU[id];if(AU[id]&&!AB[id]&&!AC[id])pure++;if(AB[id]&&!win[id])badAB++;if(AC[id]&&!win[id])badAC++;if(AU[id]&&!win[id])badAU++;}
   cout<<"ATTR_B="<<ab<<" bad="<<badAB<<" ATTR_C="<<ac<<" bad="<<badAC<<" UNION="<<au<<" bad="<<badAU<<" PURE="<<pure<<"\n";
   // branch kernel: pure defender states whose internal/legal successors lie in AB|AC and span both exclusive basins; no external shortcuts.
   vector<uint8_t> P(SZ,0),K(SZ,0);for(int id:ids)if(AU[id]&&!AB[id]&&!AC[id])P[id]=1;vector<int>su;int ew,en;long long ker=0;for(int id:ids)if(P[id]){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);if(t!=1)continue;gen(pb,pc,pf,wk,bk,t,su,ew,en);if(ew||en)continue;bool all=true,hasB=false,hasC=false;for(int s:su){if(!(AB[s]||AC[s])){all=false;break;}hasB|=AB[s]&&!AC[s];hasC|=AC[s]&&!AB[s];}if(all&&hasB&&hasC){K[id]=1;ker++;}}
   cout<<"BRANCH_KERNEL="<<ker<<"\n";
   FILE*f=fopen("/mnt/data/g6_bcf_win.bin","wb");fwrite(win.data(),1,win.size(),f);fclose(f);f=fopen("/mnt/data/g6_bcf_attrB.bin","wb");fwrite(AB.data(),1,AB.size(),f);fclose(f);f=fopen("/mnt/data/g6_bcf_attrC.bin","wb");fwrite(AC.data(),1,AC.size(),f);fclose(f);f=fopen("/mnt/data/g6_bcf_attrU.bin","wb");fwrite(AU.data(),1,AU.size(),f);fclose(f);
 }
 void bellmanAudit(){vector<int>su;int ew,en;long long bad=0;for(int id:ids){int pb,pc,pf,wk,bk,t;dec(id,pb,pc,pf,wk,bk,t);gen(pb,pc,pf,wk,bk,t,su,ew,en);bool rhs=false;if(t==0){rhs=ew>0;for(int s:su)rhs|=win[s];}else{if(total[id]==0)rhs=inCheck(pb,pc,pf,wk,bk,t);else if(en==0){rhs=true;for(int s:su)if(!win[s]){rhs=false;break;}}}if((bool)win[id]!=rhs){if(bad<10)cerr<<"Bellman mismatch id="<<id<<" t="<<t<<"\n";bad++;}}cout<<"BELLMAN_BAD="<<bad<<"\n";}
};
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);Arena A;A.build();A.solve();A.bellmanAudit();A.report();}
