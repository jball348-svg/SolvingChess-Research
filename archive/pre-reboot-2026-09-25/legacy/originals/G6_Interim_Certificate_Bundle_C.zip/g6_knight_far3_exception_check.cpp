#define main origmain
#include "/mnt/data/g6_lab_corrected_v2.cpp"
#undef main
bool exc(int ff,int rank,int wk,int n,int bk,int t){if(rank!=3||t!=1)return false;int s=ff<=2?1:(ff>=5?-1:0);if(!s)return false;if(F(n)!=ff||R(n)!=6)return false;if(R(bk)!=0||F(bk)!=ff+3*s)return false;if(s*(F(wk)-ff)<5)return false;return true;}
int main(){initMoves();long long ante=0,fail=0,e=0,efail=0,ewin=0,miss=0;for(int ff=0;ff<8;ff++){auto K=solveKPK(ff);G5Arena A(KNIGHT,{2,3,4,5,6,7},&K,ff);auto S=A.solveGame(true);for(int id=0;id<A.SZ;id++)if(A.valid[id]&&A.projectedKpkWin(id)&&!A.immediateStalemate(id)){int pri,wk,n,bk,t;gdecode(id,pri,wk,n,bk,t);int p=(A.ranks[pri]-1)*8+ff;if(cheb(bk,p)<3)continue;ante++;bool f=!S.winMask[id],x=exc(ff,A.ranks[pri],wk,n,bk,t);fail+=f;e+=x;efail+=x&&f;ewin+=x&&!f;miss+=f&&!x;}}cout<<"ante="<<ante<<" fail="<<fail<<" exception="<<e<<" exceptionFail="<<efail<<" exceptionWin="<<ewin<<" failOutsideException="<<miss<<"\n";}
