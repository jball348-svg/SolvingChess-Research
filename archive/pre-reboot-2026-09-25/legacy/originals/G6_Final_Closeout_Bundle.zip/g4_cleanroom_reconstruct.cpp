#include <bits/stdc++.h>
using namespace std;
static inline int F(int s){return s&7;} static inline int R(int s){return s>>3;}
static inline int cheb(int a,int b){return max(abs(F(a)-F(b)),abs(R(a)-R(b)));}
static inline bool wpAttSq(int p,int sq){return R(sq)==R(p)+1 && abs(F(sq)-F(p))==1;}
static inline bool bpAttSq(int p,int sq){return R(sq)==R(p)-1 && abs(F(sq)-F(p))==1;}
struct Key{vector<int>wf,bf; bool operator<(Key const&o)const{return tie(wf,bf)<tie(o.wf,o.bf);} };
string keystr(const Key&k){string s="W";for(int f:k.wf)s+=char('a'+f);s+="_B";for(int f:k.bf)s+=char('a'+f);return s;}
struct Solver;
map<Key,shared_ptr<Solver>> cache;
struct Move{int internal=-1; int ext=0;}; // ext 1 W, -1 B, 2 D
struct Solver{
 Key key; int nw,nb,np,SZ; vector<uint8_t>valid,res; vector<int> ids; // res 1 W 2 B 3 D after solve
 Solver(Key k):key(move(k)){nw=key.wf.size();nb=key.bf.size();np=nw+nb;int pow6=1;for(int i=0;i<np;i++)pow6*=6;SZ=pow6*64*64*2;valid.assign(SZ,0);res.assign(SZ,0);}
 int enc(const vector<int>&wr,const vector<int>&br,int wk,int bk,int t)const{int x=0;for(int r:wr)x=x*6+(r-2);for(int r:br)x=x*6+(r-2);return (((x*64+wk)*64+bk)*2+t);}
 void dec(int id,vector<int>&wr,vector<int>&br,int&wk,int&bk,int&t)const{t=id&1;id>>=1;bk=id%64;id/=64;wk=id%64;id/=64;int x=id;vector<int> all(np);for(int i=np-1;i>=0;i--){all[i]=x%6+2;x/=6;}wr.assign(all.begin(),all.begin()+nw);br.assign(all.begin()+nw,all.end());}
 void squares(const vector<int>&wr,const vector<int>&br,vector<int>&ws,vector<int>&bs)const{ws.resize(nw);bs.resize(nb);for(int i=0;i<nw;i++)ws[i]=(wr[i]-1)*8+key.wf[i];for(int i=0;i<nb;i++)bs[i]=(br[i]-1)*8+key.bf[i];}
 bool whiteChecks(const vector<int>&ws,int bk)const{for(int p:ws)if(wpAttSq(p,bk))return true;return false;}
 bool blackChecks(const vector<int>&bs,int wk)const{for(int p:bs)if(bpAttSq(p,wk))return true;return false;}
 bool val(const vector<int>&wr,const vector<int>&br,int wk,int bk,int t)const{vector<int>ws,bs;squares(wr,br,ws,bs);if(wk==bk||cheb(wk,bk)<=1)return false;for(int p:ws)if(p==wk||p==bk)return false;for(int p:bs)if(p==wk||p==bk)return false;for(int a:ws)for(int b:bs)if(a==b)return false;for(int i=0;i<(int)ws.size();i++)for(int j=i+1;j<(int)ws.size();j++)if(ws[i]==ws[j])return false;for(int i=0;i<(int)bs.size();i++)for(int j=i+1;j<(int)bs.size();j++)if(bs[i]==bs[j])return false;if(t==0&&whiteChecks(ws,bk))return false;if(t==1&&blackChecks(bs,wk))return false;return true;}
 bool inCheck(const vector<int>&wr,const vector<int>&br,int wk,int bk,int t)const{vector<int>ws,bs;squares(wr,br,ws,bs);return t==0?blackChecks(bs,wk):whiteChecks(ws,bk);}
 static shared_ptr<Solver> get(Key k);
 int childOutcome(Key ck,vector<int> cwr,vector<int> cbr,int wk,int bk,int t)const{auto C=get(ck);int id=C->enc(cwr,cbr,wk,bk,t);if(id<0||id>=C->SZ||!C->valid[id]) return 0;return C->res[id]==1?1:C->res[id]==2?-1:2;}
 void gen(int id,vector<Move>&mv)const{mv.clear();vector<int>wr,br,ws,bs;int wk,bk,t;dec(id,wr,br,wk,bk,t);squares(wr,br,ws,bs);
   auto occupied=[&](int q)->bool{if(q==wk||q==bk)return true;for(int p:ws)if(p==q)return true;for(int p:bs)if(p==q)return true;return false;};
   if(t==0){
    // White king moves, possibly capturing black pawn
    for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++)if(dr||df){int nr=R(wk)+dr,nf=F(wk)+df;if(nr<0||nr>7||nf<0||nf>7)continue;int q=nr*8+nf;if(q==bk||cheb(q,bk)<=1)continue;bool own=false;for(int p:ws)if(p==q)own=true;if(own)continue;int bi=-1;for(int i=0;i<nb;i++)if(bs[i]==q)bi=i;vector<int> nbr=br;Key ck=key;if(bi>=0){nbr.erase(nbr.begin()+bi);ck.bf.erase(ck.bf.begin()+bi);}vector<int> nbs;for(int i=0;i<(int)nbr.size();i++)nbs.push_back((nbr[i]-1)*8+ck.bf[i]);bool atk=false;for(int p:nbs)if(bpAttSq(p,q))atk=true;if(atk)continue;if(bi>=0){int o=childOutcome(ck,wr,nbr,q,bk,1);if(o)mv.push_back({-1,o});}else{int nid=enc(wr,br,q,bk,1);if(valid[nid])mv.push_back({nid,0});}
    }
    // White pawn moves/captures
    for(int i=0;i<nw;i++){int p=ws[i],rank=wr[i],file=key.wf[i];int q=p+8;if(q<64&&!occupied(q)){if(rank==7)mv.push_back({-1,1});else{auto nwr=wr;nwr[i]++;int nid=enc(nwr,br,wk,bk,1);if(valid[nid])mv.push_back({nid,0});if(rank==2){int q2=p+16;if(!occupied(q2)){nwr=wr;nwr[i]+=2;nid=enc(nwr,br,wk,bk,1);if(valid[nid])mv.push_back({nid,0});}}}}
      for(int df:{-1,1}){int nf=file+df,nr=rank+1;if(nf<0||nf>7||nr>8)continue;int tq=(nr-1)*8+nf;int bi=-1;for(int j=0;j<nb;j++)if(bs[j]==tq)bi=j;if(bi<0)continue;if(nr==8){mv.push_back({-1,1});continue;}Key ck=key;ck.wf[i]=nf;ck.bf.erase(ck.bf.begin()+bi);auto nwr=wr,nbr=br;nwr[i]=nr;nbr.erase(nbr.begin()+bi);{int o=childOutcome(ck,nwr,nbr,wk,bk,1);if(o)mv.push_back({-1,o});}}
    }
   }else{
    // Black king
    for(int dr=-1;dr<=1;dr++)for(int df=-1;df<=1;df++)if(dr||df){int nr=R(bk)+dr,nf=F(bk)+df;if(nr<0||nr>7||nf<0||nf>7)continue;int q=nr*8+nf;if(q==wk||cheb(q,wk)<=1)continue;bool own=false;for(int p:bs)if(p==q)own=true;if(own)continue;int wi=-1;for(int i=0;i<nw;i++)if(ws[i]==q)wi=i;vector<int> nwr=wr;Key ck=key;if(wi>=0){nwr.erase(nwr.begin()+wi);ck.wf.erase(ck.wf.begin()+wi);}vector<int> nws;for(int i=0;i<(int)nwr.size();i++)nws.push_back((nwr[i]-1)*8+ck.wf[i]);bool atk=false;for(int p:nws)if(wpAttSq(p,q))atk=true;if(atk)continue;if(wi>=0){int o=childOutcome(ck,nwr,br,wk,q,0);if(o)mv.push_back({-1,o});}else{int nid=enc(wr,br,wk,q,0);if(valid[nid])mv.push_back({nid,0});}
    }
    // black pawns
    for(int i=0;i<nb;i++){int p=bs[i],rank=br[i],file=key.bf[i];int q=p-8;if(q>=0&&!occupied(q)){if(rank==2)mv.push_back({-1,-1});else{auto nbr=br;nbr[i]--;int nid=enc(wr,nbr,wk,bk,0);if(valid[nid])mv.push_back({nid,0});if(rank==7){int q2=p-16;if(!occupied(q2)){nbr=br;nbr[i]-=2;nid=enc(wr,nbr,wk,bk,0);if(valid[nid])mv.push_back({nid,0});}}}}
      for(int df:{-1,1}){int nf=file+df,nr=rank-1;if(nf<0||nf>7||nr<1)continue;int tq=(nr-1)*8+nf;int wi=-1;for(int j=0;j<nw;j++)if(ws[j]==tq)wi=j;if(wi<0)continue;if(nr==1){mv.push_back({-1,-1});continue;}Key ck=key;ck.bf[i]=nf;ck.wf.erase(ck.wf.begin()+wi);auto nbr=br,nwr=wr;nbr[i]=nr;nwr.erase(nwr.begin()+wi);{int o=childOutcome(ck,nwr,nbr,wk,bk,0);if(o)mv.push_back({-1,o});}}
    }
   }
 }
 void build(){vector<int>wr(nw,2),br(nb,2);int rankcomb=1;for(int i=0;i<np;i++)rankcomb*=6;ids.reserve(SZ*3/4);for(int x=0;x<rankcomb;x++){int y=x;vector<int>all(np);for(int i=np-1;i>=0;i--){all[i]=y%6+2;y/=6;}for(int i=0;i<nw;i++)wr[i]=all[i];for(int i=0;i<nb;i++)br[i]=all[nw+i];for(int wk=0;wk<64;wk++)for(int bk=0;bk<64;bk++)for(int t=0;t<2;t++){int id=enc(wr,br,wk,bk,t);if(val(wr,br,wk,bk,t)){valid[id]=1;ids.push_back(id);}}}cerr<<"BUILD "<<keystr(key)<<" valid="<<ids.size()<<" raw="<<SZ<<"\n";}
 void solve(){build(); vector<uint8_t>W(SZ,0),B(SZ,0);vector<Move>mv;auto attract=[&](bool white,vector<uint8_t>&A){bool ch=true;int pass=0;while(ch&&pass<100){ch=false;pass++;long long add=0;for(int id:ids)if(!A[id]){vector<int>wr,br;int wk,bk,t;dec(id,wr,br,wk,bk,t);gen(id,mv);bool moverWhite=(t==0);bool attacker=(moverWhite==white);if(mv.empty()){if(inCheck(wr,br,wk,bk,t)&&attacker==false){ // side to move checkmated, winner is other; belongs if winner==white
            bool winnerWhite=!moverWhite;if(winnerWhite==white){A[id]=1;ch=true;add++;}}
          continue;}
        if(attacker){bool ok=false;for(auto&m:mv){bool good=m.internal>=0?A[m.internal]:(white?m.ext==1:m.ext==-1);if(good){ok=true;break;}}if(ok){A[id]=1;ch=true;add++;}}
        else {bool all=true;for(auto&m:mv){bool good=m.internal>=0?A[m.internal]:(white?m.ext==1:m.ext==-1);if(!good){all=false;break;}}if(all){A[id]=1;ch=true;add++;}}
      }cerr<<"  "<<(white?"W":"B")<<" pass="<<pass<<" add="<<add<<"\n";}
    };
  attract(true,W);attract(false,B);long long cw=0,cb=0,cd=0,ov=0;for(int id:ids){if(W[id]&&B[id])ov++;if(W[id])res[id]=1,cw++;else if(B[id])res[id]=2,cb++;else res[id]=3,cd++;}cerr<<"SOLVE "<<keystr(key)<<" W="<<cw<<" B="<<cb<<" D="<<cd<<" overlap="<<ov<<"\n";
 }
};
shared_ptr<Solver> Solver::get(Key k){auto it=cache.find(k);if(it!=cache.end())return it->second;auto p=make_shared<Solver>(k);cache[k]=p;p->solve();return p;}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);
 auto full=Solver::get(Key{{3,4},{2}}); long long W=0,B=0,D=0;for(int id:full->ids){auto r=full->res[id];W+=r==1;B+=r==2;D+=r==3;}cout<<"FULL valid="<<full->ids.size()<<" W="<<W<<" B="<<B<<" D="<<D<<"\n";
 auto p2=Solver::get(Key{{3,4},{}});long long pW=0,pB=0,pD=0;for(int id:p2->ids){auto r=p2->res[id];pW+=r==1;pB+=r==2;pD+=r==3;}cout<<"PILOT2 ordinary valid="<<p2->ids.size()<<" W="<<pW<<" B="<<pB<<" D="<<pD<<"\n";
}
