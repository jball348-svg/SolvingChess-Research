#define main rank_termall_orig_main
#include "/mnt/data/g6_rank_termall.cpp"
#undef main

static string sqn(int s){string x="a1";x[0]='a'+F(s);x[1]='1'+R(s);return x;}
void traceType(PType pt,const char* nm){auto K=solveKPK(3);G5Arena A(pt,{5,6,7},&K,3);auto T=A.solveGame(true);int cur=-1;for(int c=0;c<A.SZ;c++)if(A.valid[c]&&T.winMask[c]&&T.dist[c]==T.maxr){cur=c;break;}cerr<<nm<<" max="<<T.maxr<<" start="<<cur<<"\n";vector<int>ss;int tw,ew,ewm,ed;int steps=0;while(cur>=0&&steps<100){int pri,wk,m,bk,t;gdecode(cur,pri,wk,m,bk,t);int d=T.dist[cur];cout<<nm<<" step="<<steps<<" d="<<d<<" stm="<<(t?"B":"W")<<" p=d"<<A.ranks[pri]<<" WK="<<sqn(wk)<<" M="<<sqn(m)<<" BK="<<sqn(bk);if(d==0){if(!t){A.whiteSucc(cur,ss,tw);cout<<" rank0 W tw="<<tw<<" succ="<<ss.size();}else{A.blackSucc(cur,ss,ew,ewm,ed);cout<<" rank0 B check="<<A.blackInCheck(pri,wk,m,bk)<<" succ="<<ss.size()<<" ew="<<ew<<" ed="<<ed;}cout<<"\n";break;}cout<<"\n";
 if(!t){A.whiteSucc(cur,ss,tw);int best=-1,bd=999;for(int s:ss)if(T.winMask[s]&&T.dist[s]>=0&&T.dist[s]<bd){bd=T.dist[s];best=s;}if(best<0){cout<<"WHITE external? tw="<<tw<<"\n";break;}cur=best;}
 else {A.blackSucc(cur,ss,ew,ewm,ed);int best=-1,bd=-1;for(int s:ss)if(T.winMask[s]&&T.dist[s]>bd){bd=T.dist[s];best=s;}if(best<0){cout<<"BLACK external all? ew="<<ew<<" ewm="<<ewm<<" ed="<<ed<<"\n";break;}cur=best;}
 steps++;}
}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);initMoves();traceType(KNIGHT,"N");traceType(BISHOP,"B");}
