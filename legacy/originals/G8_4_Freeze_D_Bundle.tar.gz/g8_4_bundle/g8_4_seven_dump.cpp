#include <bits/stdc++.h>
using namespace std;
static inline int FF(int s){return s&7;} static inline int RR(int s){return s>>3;} static inline int CC(int s){return (FF(s)+RR(s))&1;}
static inline int cheb(int a,int b){return max(abs(FF(a)-FF(b)),abs(RR(a)-RR(b)));}
vector<int> kingMv[64];
void initMoves(){for(int s=0;s<64;s++)for(int df=-1;df<=1;df++)for(int dr=-1;dr<=1;dr++)if(df||dr){int f=FF(s)+df,r=RR(s)+dr;if(f>=0&&f<8&&r>=0&&r<8)kingMv[s].push_back(r*8+f);}}
enum PT{BISHOP};
struct Fam{string name; int wcolor,bcolor; int wpa,wpc,bp;};
// sig bits: 16 WB, 8 BB, 4 Wa, 2 Wc, 1 Bb
struct S{int wk,bk,wb,bb; bool wa,wc,bp; int turn;};
struct Bitset{vector<uint64_t>w;size_t n=0;Bitset(){}Bitset(size_t n_):w((n_+63)/64),n(n_){}inline bool get(uint64_t i)const{return(w[i>>6]>>(i&63))&1ULL;}inline void set(uint64_t i){w[i>>6]|=1ULL<<(i&63);}};
struct Packed2{vector<uint64_t>w;size_t n=0;Packed2(){}Packed2(size_t n_):w((n_+31)/32),n(n_){}inline uint8_t get(uint64_t i)const{return(w[i>>5]>>((i&31)*2))&3ULL;}inline void set(uint64_t i,uint8_t v){uint64_t sh=(i&31)*2,mask=3ULL<<sh;w[i>>5]=(w[i>>5]&~mask)|(uint64_t(v)<<sh);}};
struct Table;struct Engine;
struct Table{Engine*e=nullptr;int sig=0;vector<int>wSquares,bSquares,wIndex,bIndex;int nw=1,nb=1;uint64_t RAW=0;Bitset valid;Packed2 out;uint64_t staticN=0,W=0,B=0,D=0;double sec=0;};
struct Engine{
 Fam f;array<unique_ptr<Table>,32>T;uint64_t capFromFull[32]={0};
 Engine(Fam ff):f(ff){}
 void buildSquares(int col,vector<int>&v,vector<int>&idx){idx.assign(64,-1);for(int s=0;s<64;s++)if(CC(s)==col){idx[s]=v.size();v.push_back(s);}}
 void initTable(int sig){auto t=make_unique<Table>();t->e=this;t->sig=sig;if(sig&16){buildSquares(f.wcolor,t->wSquares,t->wIndex);t->nw=t->wSquares.size();}else{t->wIndex.assign(64,-1);}if(sig&8){buildSquares(f.bcolor,t->bSquares,t->bIndex);t->nb=t->bSquares.size();}else{t->bIndex.assign(64,-1);}t->RAW=uint64_t(64)*64*t->nw*t->nb*2;t->valid=Bitset(t->RAW);t->out=Packed2(t->RAW);T[sig]=move(t);}
 inline uint64_t code(const Table&t,const S&s)const{int wi=(t.sig&16)?t.wIndex[s.wb]:0,bi=(t.sig&8)?t.bIndex[s.bb]:0;uint64_t x=s.wk;x=x*64+s.bk;x=x*t.nw+wi;x=x*t.nb+bi;x=x*2+s.turn;return x;}
 inline S dec(const Table&t,uint64_t x)const{S s{};s.turn=x%2;x/=2;int bi=x%t.nb;x/=t.nb;int wi=x%t.nw;x/=t.nw;s.bk=x%64;x/=64;s.wk=x%64;s.wb=(t.sig&16)?t.wSquares[wi]:-1;s.bb=(t.sig&8)?t.bSquares[bi]:-1;s.wa=t.sig&4;s.wc=t.sig&2;s.bp=t.sig&1;return s;}
 inline bool occ(const S&s,int sq)const{return s.wk==sq||s.bk==sq||s.wb==sq||s.bb==sq||(s.wa&&f.wpa==sq)||(s.wc&&f.wpc==sq)||(s.bp&&f.bp==sq);}
 bool bishopAtt(int from,int to,const S&s,int ignore=-2,int extraBlock=-1)const{if(from<0)return false;int df=FF(to)-FF(from),dr=RR(to)-RR(from);if(df==0||abs(df)!=abs(dr))return false;int sf=df>0?1:-1,sr=dr>0?1:-1;for(int ff=FF(from)+sf,rr=RR(from)+sr;ff!=FF(to)||rr!=RR(to);ff+=sf,rr+=sr){int q=rr*8+ff;if(q!=ignore&&(q==extraBlock||occ(s,q)))return false;}return true;}
 bool pawnAtt(bool white,int from,int to)const{return abs(FF(to)-FF(from))==1&&RR(to)-RR(from)==(white?1:-1);}
 bool attackedW(const S&s,int sq,int ignore=-2,int extra=-1)const{if(cheb(s.wk,sq)<=1)return true;if(s.wa&&f.wpa!=ignore&&pawnAtt(true,f.wpa,sq))return true;if(s.wc&&f.wpc!=ignore&&pawnAtt(true,f.wpc,sq))return true;if(s.wb>=0&&s.wb!=ignore&&bishopAtt(s.wb,sq,s,ignore,extra))return true;return false;}
 bool attackedB(const S&s,int sq,int ignore=-2,int extra=-1)const{if(cheb(s.bk,sq)<=1)return true;if(s.bp&&f.bp!=ignore&&pawnAtt(false,f.bp,sq))return true;if(s.bb>=0&&s.bb!=ignore&&bishopAtt(s.bb,sq,s,ignore,extra))return true;return false;}
 bool staticValid(const S&s)const{if(s.wk==s.bk||cheb(s.wk,s.bk)<=1)return false;int q[7],n=0;q[n++]=s.wk;q[n++]=s.bk;if(s.wb>=0)q[n++]=s.wb;if(s.bb>=0)q[n++]=s.bb;if(s.wa)q[n++]=f.wpa;if(s.wc)q[n++]=f.wpc;if(s.bp)q[n++]=f.bp;sort(q,q+n);for(int i=1;i<n;i++)if(q[i]==q[i-1])return false;if(s.wb>=0&&CC(s.wb)!=f.wcolor)return false;if(s.bb>=0&&CC(s.bb)!=f.bcolor)return false;if(s.turn==0&&attackedW(s,s.bk))return false;if(s.turn==1&&attackedB(s,s.wk))return false;return true;}
 bool inCheck(const S&s)const{return s.turn==0?attackedB(s,s.wk):attackedW(s,s.bk);}
 void bishopDests(int from,const S&s,vector<int>&d)const{d.clear();int ds[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};for(auto &v:ds){int ff=FF(from)+v[0],rr=RR(from)+v[1];while(ff>=0&&ff<8&&rr>=0&&rr<8){int q=rr*8+ff;d.push_back(q);if(occ(s,q))break;ff+=v[0];rr+=v[1];}}}
 // Is at least one legal immediate promotion available for side to move? Promotion ends as win, so promoted piece is not represented.
 bool onePromoLegal(const S&s,bool white,int p)const{
   int forward=p+(white?8:-8);
   auto test=[&](int dest,int captureKind)->bool{S z=s;if(white){if(p==f.wpa)z.wa=false;else z.wc=false;}else z.bp=false;if(captureKind==1){if(white)z.bb=-1;else z.wb=-1;}int king=white?z.wk:z.bk;return !(white?attackedB(z,king,-2,dest):attackedW(z,king,-2,dest));};
   if(forward>=0&&forward<64&&!occ(s,forward)&&test(forward,0))return true;
   for(int df:{-1,1}){int ff=FF(p)+df,rr=RR(p)+(white?1:-1);if(ff<0||ff>=8||rr<0||rr>=8)continue;int d=rr*8+ff;if(white){if(d==s.bb&&test(d,1))return true;}else{if(d==s.wb&&test(d,1))return true;}}
   return false;
 }
 bool promoLegal(const S&s,bool white)const{if(white){if(s.wa&&onePromoLegal(s,true,f.wpa))return true;if(s.wc&&onePromoLegal(s,true,f.wpc))return true;return false;}return s.bp&&onePromoLegal(s,false,f.bp);}
 struct Mv{int childSig;uint64_t childCode;};
 void successors(const Table&t,const S&s,vector<Mv>&mv,bool&promo)const{mv.clear();promo=false;bool white=s.turn==0;int k=white?s.wk:s.bk;
   for(int nk:kingMv[k]){if(white){if(nk==s.wb||(s.wa&&nk==f.wpa)||(s.wc&&nk==f.wpc)||nk==s.bk)continue;}else{if(nk==s.bb||(s.bp&&nk==f.bp)||nk==s.wk)continue;}S z=s;int cs=t.sig;if(white){z.wk=nk;if(nk==z.bb){z.bb=-1;cs&=~8;}if(z.bp&&nk==f.bp){z.bp=false;cs&=~1;}}else{z.bk=nk;if(nk==z.wb){z.wb=-1;cs&=~16;}if(z.wa&&nk==f.wpa){z.wa=false;cs&=~4;}if(z.wc&&nk==f.wpc){z.wc=false;cs&=~2;}}z.turn^=1;uint64_t cc=code(*T[cs],z);if(T[cs]->valid.get(cc))mv.push_back({cs,cc});}
   int pc=white?s.wb:s.bb;if(pc>=0){static thread_local vector<int>d;if(d.capacity()<32)d.reserve(32);bishopDests(pc,s,d);for(int np:d){if(white){if(np==s.wk||(s.wa&&np==f.wpa)||(s.wc&&np==f.wpc)||np==s.bk)continue;}else{if(np==s.bk||(s.bp&&np==f.bp)||np==s.wk)continue;}S z=s;int cs=t.sig;if(white){z.wb=np;if(np==z.bb){z.bb=-1;cs&=~8;}if(z.bp&&np==f.bp){z.bp=false;cs&=~1;}}else{z.bb=np;if(np==z.wb){z.wb=-1;cs&=~16;}if(z.wa&&np==f.wpa){z.wa=false;cs&=~4;}if(z.wc&&np==f.wpc){z.wc=false;cs&=~2;}}z.turn^=1;uint64_t cc=code(*T[cs],z);if(T[cs]->valid.get(cc))mv.push_back({cs,cc});}}
   promo=promoLegal(s,white);
 }
 template<class Fn>void bishopOrigins(int dest,const S&cur,Fn fn)const{int ds[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};for(auto &v:ds){int ff=FF(dest)+v[0],rr=RR(dest)+v[1];while(ff>=0&&ff<8&&rr>=0&&rr<8){int o=rr*8+ff;if(occ(cur,o))break;fn(o);ff+=v[0];rr+=v[1];}}}
 template<class Fn>void predecessorsSame(const Table&t,uint64_t zc,Fn fn)const{S s=dec(t,zc);bool pw=s.turn==1;int dest=pw?s.wk:s.bk;for(int o:kingMv[dest]){S p=s;if(pw)p.wk=o;else p.bk=o;p.turn^=1;uint64_t pc=code(t,p);if(t.valid.get(pc))fn(pc);}int pd=pw?s.wb:s.bb;if(pd>=0)bishopOrigins(pd,s,[&](int o){S p=s;if(pw)p.wb=o;else p.bb=o;p.turn^=1;uint64_t pc=code(t,p);if(t.valid.get(pc))fn(pc);});}
 void buildValid(Table&t){for(uint64_t c=0;c<t.RAW;c++){S s=dec(t,c);if(staticValid(s)){t.valid.set(c);t.staticN++;}}}
 void solveSig(int sig){Table&t=*T[sig];auto t0=chrono::steady_clock::now();buildValid(t);vector<uint8_t>rem(t.RAW,0);deque<uint32_t>q;vector<Mv>mv;for(uint64_t c=0;c<t.RAW;c++)if(t.valid.get(c)){S s=dec(t,c);bool promo=false;successors(t,s,mv,promo);if(sig==31)for(auto&m:mv)if(m.childSig!=sig)capFromFull[m.childSig]++;if(promo){t.out.set(c,1);q.push_back((uint32_t)c);continue;}if(mv.empty()){if(inCheck(s)){t.out.set(c,2);q.push_back((uint32_t)c);}else t.out.set(c,3);continue;}bool childLoss=false;int unresolved=0,block=0;for(auto&m:mv){if(m.childSig==sig)unresolved++;else{uint8_t co=T[m.childSig]->out.get(m.childCode);if(co==2){childLoss=true;break;}else if(co==1){}else block++;}}if(childLoss){t.out.set(c,1);q.push_back((uint32_t)c);continue;}int r=unresolved+block;if(r==0){t.out.set(c,2);q.push_back((uint32_t)c);}else rem[c]=(uint8_t)min(255,r);}
   while(!q.empty()){uint32_t z=q.front();q.pop_front();uint8_t oz=t.out.get(z);predecessorsSame(t,z,[&](uint64_t p){if(t.out.get(p)!=0)return;if(oz==2){t.out.set(p,1);q.push_back((uint32_t)p);}else if(oz==1){if(rem[p]>0)--rem[p];if(rem[p]==0){t.out.set(p,2);q.push_back((uint32_t)p);}}});}
   for(uint64_t c=0;c<t.RAW;c++)if(t.valid.get(c)){uint8_t o=t.out.get(c);if(o==0){t.out.set(c,3);o=3;}S s=dec(t,c);if(o==3)t.D++;else{bool whiteWin=(s.turn==0&&o==1)||(s.turn==1&&o==2);if(whiteWin)t.W++;else t.B++;}}
   t.sec=chrono::duration<double>(chrono::steady_clock::now()-t0).count();cerr<<f.name<<" sig="<<sig<<" raw="<<t.RAW<<" static="<<t.staticN<<" W="<<t.W<<" B="<<t.B<<" D="<<t.D<<" sec="<<fixed<<setprecision(3)<<t.sec<<"\n";
 }
 void run(const string&dump=""){for(int s=0;s<32;s++)initTable(s);vector<int>order(32);iota(order.begin(),order.end(),0);stable_sort(order.begin(),order.end(),[](int a,int b){return __builtin_popcount((unsigned)a)<__builtin_popcount((unsigned)b);});auto wall0=chrono::steady_clock::now();for(int s:order)solveSig(s);double wall=chrono::duration<double>(chrono::steady_clock::now()-wall0).count();uint64_t st=0,W=0,B=0,D=0;double sum=0;for(int s=0;s<32;s++){st+=T[s]->staticN;W+=T[s]->W;B+=T[s]->B;D+=T[s]->D;sum+=T[s]->sec;}auto &full=*T[31];cout<<"RESULT "<<f.name<<" graph="<<st<<" W="<<W<<" B="<<B<<" D="<<D<<" full="<<full.staticN<<" fullW="<<full.W<<" fullB="<<full.B<<" fullD="<<full.D<<" sumSigSec="<<fixed<<setprecision(3)<<sum<<" wall="<<wall<<"\n";cout<<"CAP31";uint64_t ct=0;for(int s=0;s<31;s++)if(capFromFull[s]){cout<<" sig"<<s<<"="<<capFromFull[s];ct+=capFromFull[s];}cout<<" total="<<ct<<"\n";uint64_t vb=0,ob=0;for(int s=0;s<32;s++){vb+=T[s]->valid.w.size()*8;ob+=T[s]->out.w.size()*8;}cout<<"PACKED persistent_valid_bytes="<<vb<<" outcome_bytes="<<ob<<" total="<<(vb+ob)<<"\n"; if(!dump.empty()){ofstream os(dump,ios::binary); uint32_t magic=0x47383453,ver=1,n=32; os.write((char*)&magic,4);os.write((char*)&ver,4);os.write((char*)&n,4); for(int s=0;s<32;s++){uint32_t sg=s;uint64_t raw=T[s]->RAW,vw=T[s]->valid.w.size(),ow=T[s]->out.w.size();os.write((char*)&sg,4);os.write((char*)&raw,8);os.write((char*)&vw,8);os.write((char*)&ow,8);os.write((char*)T[s]->valid.w.data(),vw*8);os.write((char*)T[s]->out.w.data(),ow*8);} } }
};
int sq(const string&a){return(a[0]-'a')+8*(a[1]-'1');}
int main(int argc,char**argv){ios::sync_with_stdio(false);cin.tie(nullptr);initMoves();string nm=argc>1?argv[1]:"BB_opp_a7c7_b2";vector<Fam>fs={{"BB_opp_a7c7_b2",0,1,sq("a7"),sq("c7"),sq("b2")},{"BB_same_a7c7_b2",0,0,sq("a7"),sq("c7"),sq("b2")}};for(auto &f:fs)if(f.name==nm){Engine e(f);e.run(argc>2?argv[2]:"");return 0;}cerr<<"unknown arena\n";return 2;}
