#include <bits/stdc++.h>
using namespace std;
static inline int FF(int s){return s&7;} static inline int RR(int s){return s>>3;} static inline int CC(int s){return (FF(s)+RR(s))&1;}
static inline int cheb(int a,int b){return max(abs(FF(a)-FF(b)),abs(RR(a)-RR(b)));}
vector<int> kingMv[64], knightMv[64];
void initMoves(){
  for(int s=0;s<64;s++){
    for(int df=-1;df<=1;df++)for(int dr=-1;dr<=1;dr++)if(df||dr){int f=FF(s)+df,r=RR(s)+dr;if(f>=0&&f<8&&r>=0&&r<8)kingMv[s].push_back(r*8+f);}
    int D[8][2]={{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1},{-2,1},{-1,2}};
    for(auto &d:D){int f=FF(s)+d[0],r=RR(s)+d[1];if(f>=0&&f<8&&r>=0&&r<8)knightMv[s].push_back(r*8+f);}
  }
}
enum PT{BISHOP,KNIGHT,ROOK,QUEEN};
struct Fam{string name; PT wp,bp; int wcolor,bcolor; int wpsq,bpsq;};
struct S{int wk,bk,wpiece,bpiece; bool wpawn,bpawn; int turn;};

struct Bitset {
  vector<uint64_t> w; size_t n=0;
  Bitset(){} Bitset(size_t n_, bool z=false):w((n_+63)/64,z?~0ULL:0),n(n_){if(z&&n%64)w.back()&=((1ULL<<(n%64))-1);} 
  inline bool get(uint64_t i) const {return (w[i>>6]>>(i&63))&1ULL;}
  inline void set(uint64_t i){w[i>>6]|=1ULL<<(i&63);} 
};
struct Packed2 {
  vector<uint64_t> w; size_t n=0;
  Packed2(){} Packed2(size_t n_):w((n_+31)/32,0),n(n_){}
  inline uint8_t get(uint64_t i) const {return (w[i>>5]>>((i&31)*2))&3ULL;}
  inline void set(uint64_t i,uint8_t v){uint64_t sh=(i&31)*2, mask=3ULL<<sh; w[i>>5]=(w[i>>5]&~mask)|(uint64_t(v)<<sh);} 
};

struct Table;
struct Engine;

struct Table {
  Engine* e=nullptr; int sig=0; // bits 8 Wpiece,4 Bpiece,2 Wpawn,1 Bpawn
  vector<int> wSquares,bSquares,wIndex,bIndex; int nw=1,nb=1; uint64_t RAW=0;
  Bitset valid; Packed2 out; // 0 unknown while solving, then all valid become 1/2/3
  uint64_t staticN=0,W=0,B=0,D=0;
  double sec=0;
  Table(){}
};

struct Engine {
  Fam f; array<unique_ptr<Table>,16> T;
  uint64_t capFromFull[16]={0};
  Engine(Fam ff):f(ff){}
  void buildSquares(PT p,int col,vector<int>&v,vector<int>&idx){idx.assign(64,-1);for(int s=0;s<64;s++){if(p==BISHOP&&CC(s)!=col)continue;idx[s]=v.size();v.push_back(s);}}
  void initTable(int sig){
    auto t=make_unique<Table>();t->e=this;t->sig=sig;
    if(sig&8){buildSquares(f.wp,f.wcolor,t->wSquares,t->wIndex);t->nw=t->wSquares.size();} else {t->wIndex.assign(64,-1);t->nw=1;}
    if(sig&4){buildSquares(f.bp,f.bcolor,t->bSquares,t->bIndex);t->nb=t->bSquares.size();} else {t->bIndex.assign(64,-1);t->nb=1;}
    t->RAW=uint64_t(64)*64*t->nw*t->nb*2;
    t->valid=Bitset(t->RAW);t->out=Packed2(t->RAW);
    T[sig]=move(t);
  }
  inline uint64_t code(const Table&t,const S&s) const {
    int wi=(t.sig&8)?t.wIndex[s.wpiece]:0, bi=(t.sig&4)?t.bIndex[s.bpiece]:0;
    uint64_t x=s.wk; x=x*64+s.bk; x=x*t.nw+wi; x=x*t.nb+bi; x=x*2+s.turn; return x;
  }
  inline S dec(const Table&t,uint64_t x) const {
    S s{};s.turn=x%2;x/=2;int bi=x%t.nb;x/=t.nb;int wi=x%t.nw;x/=t.nw;s.bk=x%64;x/=64;s.wk=x%64;
    s.wpiece=(t.sig&8)?t.wSquares[wi]:-1;s.bpiece=(t.sig&4)?t.bSquares[bi]:-1;s.wpawn=t.sig&2;s.bpawn=t.sig&1;return s;
  }
  inline bool occ(const S&s,int sq) const {return s.wk==sq||s.bk==sq||s.wpiece==sq||s.bpiece==sq||(s.wpawn&&f.wpsq==sq)||(s.bpawn&&f.bpsq==sq);} 
  bool pieceAtt(PT p,int from,int to,const S&s,int ignore=-2,int extraBlock=-1) const {
    if(from<0)return false;if(p==KNIGHT){for(int q:knightMv[from])if(q==to)return true;return false;}
    int df=FF(to)-FF(from),dr=RR(to)-RR(from),sf=0,sr=0;
    if(p==BISHOP){if(df==0||abs(df)!=abs(dr))return false;sf=df>0?1:-1;sr=dr>0?1:-1;}
    else if(p==ROOK){if(df!=0&&dr!=0)return false;sf=(df>0)-(df<0);sr=(dr>0)-(dr<0);}
    else {if(df==0||dr==0){sf=(df>0)-(df<0);sr=(dr>0)-(dr<0);}else if(abs(df)==abs(dr)){sf=df>0?1:-1;sr=dr>0?1:-1;}else return false;}
    int ff=FF(from)+sf,rr=RR(from)+sr;while(ff!=FF(to)||rr!=RR(to)){int q=rr*8+ff;if(q!=ignore&&(q==extraBlock||occ(s,q)))return false;ff+=sf;rr+=sr;}return true;
  }
  bool pawnAtt(bool white,int from,int to) const {int dr=RR(to)-RR(from),df=abs(FF(to)-FF(from));return df==1&&dr==(white?1:-1);} 
  bool attackedByWhite(const S&s,int sq,int ignore=-2,int extraBlock=-1) const {if(cheb(s.wk,sq)<=1)return true;if(s.wpawn&&f.wpsq!=ignore&&pawnAtt(true,f.wpsq,sq))return true;if(s.wpiece>=0&&s.wpiece!=ignore&&pieceAtt(f.wp,s.wpiece,sq,s,ignore,extraBlock))return true;return false;}
  bool attackedByBlack(const S&s,int sq,int ignore=-2,int extraBlock=-1) const {if(cheb(s.bk,sq)<=1)return true;if(s.bpawn&&f.bpsq!=ignore&&pawnAtt(false,f.bpsq,sq))return true;if(s.bpiece>=0&&s.bpiece!=ignore&&pieceAtt(f.bp,s.bpiece,sq,s,ignore,extraBlock))return true;return false;}
  bool staticValid(const S&s) const {
    if(s.wk==s.bk||cheb(s.wk,s.bk)<=1)return false;int q[6],n=0;q[n++]=s.wk;q[n++]=s.bk;if(s.wpiece>=0)q[n++]=s.wpiece;if(s.bpiece>=0)q[n++]=s.bpiece;if(s.wpawn)q[n++]=f.wpsq;if(s.bpawn)q[n++]=f.bpsq;sort(q,q+n);for(int i=1;i<n;i++)if(q[i]==q[i-1])return false;
    if(s.wpiece>=0&&f.wp==BISHOP&&CC(s.wpiece)!=f.wcolor)return false;if(s.bpiece>=0&&f.bp==BISHOP&&CC(s.bpiece)!=f.bcolor)return false;
    if(s.turn==0&&attackedByWhite(s,s.bk))return false;if(s.turn==1&&attackedByBlack(s,s.wk))return false;return true;
  }
  bool inCheck(const S&s) const {return s.turn==0?attackedByBlack(s,s.wk):attackedByWhite(s,s.bk);} 
  void pieceDests(PT p,int from,const S&s,vector<int>&d) const {
    d.clear();if(from<0)return;if(p==KNIGHT){d=knightMv[from];return;}int dirs[8][2]={{1,1},{1,-1},{-1,1},{-1,-1},{1,0},{-1,0},{0,1},{0,-1}};int a=0,b=8;if(p==BISHOP)b=4;else if(p==ROOK)a=4;
    for(int k=a;k<b;k++){int ff=FF(from)+dirs[k][0],rr=RR(from)+dirs[k][1];while(ff>=0&&ff<8&&rr>=0&&rr<8){int q=rr*8+ff;d.push_back(q);if(occ(s,q))break;ff+=dirs[k][0];rr+=dirs[k][1];}}
  }
  bool promoLegal(const S&s,bool white) const {
    int p=white?f.wpsq:f.bpsq;if(white?!s.wpawn:!s.bpawn)return false;int dir=white?8:-8,forward=p+dir;
    auto test=[&](int dest,int captured)->bool{S z=s;if(white)z.wpawn=false;else z.bpawn=false;if(captured==1){if(white)z.bpiece=-1;else z.wpiece=-1;}int king=white?z.wk:z.bk;bool atk=white?attackedByBlack(z,king,-2,dest):attackedByWhite(z,king,-2,dest);return !atk;};
    if(forward>=0&&forward<64&&!occ(s,forward)&&test(forward,0))return true;
    for(int df:{-1,1}){int ff=FF(p)+df,rr=RR(p)+(white?1:-1);if(ff<0||ff>=8||rr<0||rr>=8)continue;int d=rr*8+ff;if(white){if(d==s.bpiece&&test(d,1))return true;}else{if(d==s.wpiece&&test(d,1))return true;}}
    return false;
  }
  struct Mv{int childSig;uint64_t childCode;};
  void successors(const Table&t,const S&s,vector<Mv>&mv,bool&promo) const {
    mv.clear();promo=false;bool white=s.turn==0;int k=white?s.wk:s.bk;
    for(int nk:kingMv[k]){
      if(white){if(nk==s.wpiece||(s.wpawn&&nk==f.wpsq)||nk==s.bk)continue;}else{if(nk==s.bpiece||(s.bpawn&&nk==f.bpsq)||nk==s.wk)continue;}
      S z=s;int cs=t.sig;if(white)z.wk=nk;else z.bk=nk;
      if(white){if(nk==z.bpiece){z.bpiece=-1;cs&=~4;}if(z.bpawn&&nk==f.bpsq){z.bpawn=false;cs&=~1;}}
      else {if(nk==z.wpiece){z.wpiece=-1;cs&=~8;}if(z.wpawn&&nk==f.wpsq){z.wpawn=false;cs&=~2;}}
      z.turn^=1;if(!staticValid(z))continue;mv.push_back({cs,code(*T[cs],z)});
    }
    int pc=white?s.wpiece:s.bpiece;PT pt=white?f.wp:f.bp;if(pc>=0){vector<int>d;pieceDests(pt,pc,s,d);for(int np:d){
      if(white){if(np==s.wk||(s.wpawn&&np==f.wpsq)||np==s.bk)continue;}else{if(np==s.bk||(s.bpawn&&np==f.bpsq)||np==s.wk)continue;}
      S z=s;int cs=t.sig;if(white){z.wpiece=np;if(np==z.bpiece){z.bpiece=-1;cs&=~4;}if(z.bpawn&&np==f.bpsq){z.bpawn=false;cs&=~1;}}
      else {z.bpiece=np;if(np==z.wpiece){z.wpiece=-1;cs&=~8;}if(z.wpawn&&np==f.wpsq){z.wpawn=false;cs&=~2;}}
      z.turn^=1;if(!staticValid(z))continue;mv.push_back({cs,code(*T[cs],z)});
    }}
    if(promoLegal(s,white))promo=true;
  }
  template<class Fn> void originsForPiece(PT p,int dest,const S&cur,bool prevWhite,Fn fn) const {
    if(p==KNIGHT){for(int o:knightMv[dest])fn(o);return;}
    int dirs[8][2]={{1,1},{1,-1},{-1,1},{-1,-1},{1,0},{-1,0},{0,1},{0,-1}};int a=0,b=8;if(p==BISHOP)b=4;else if(p==ROOK)a=4;
    // Walk outward from destination. Current destination contains the moved piece; other current occupancies block possible origins beyond them.
    for(int k=a;k<b;k++){int ff=FF(dest)+dirs[k][0],rr=RR(dest)+dirs[k][1];while(ff>=0&&ff<8&&rr>=0&&rr<8){int o=rr*8+ff;if(occ(cur,o))break;fn(o);ff+=dirs[k][0];rr+=dirs[k][1];}}
  }
  template<class Fn> void predecessorsSame(const Table&t,uint64_t zc,Fn fn) const {
    S s=dec(t,zc);bool prevWhite=s.turn==1; // previous mover
    int dest=prevWhite?s.wk:s.bk;
    for(int o:kingMv[dest]){
      S p=s;if(prevWhite)p.wk=o;else p.bk=o;p.turn^=1;if(!staticValid(p))continue;uint64_t pc=code(t,p);if(t.valid.get(pc))fn(pc);
    }
    int pdest=prevWhite?s.wpiece:s.bpiece;PT pt=prevWhite?f.wp:f.bp;if(pdest>=0){
      originsForPiece(pt,pdest,s,prevWhite,[&](int o){S p=s;if(prevWhite)p.wpiece=o;else p.bpiece=o;p.turn^=1;if(!staticValid(p))return;uint64_t pc=code(t,p);if(t.valid.get(pc))fn(pc);});
    }
  }
  void buildValid(Table&t){for(uint64_t c=0;c<t.RAW;c++){S s=dec(t,c);if(staticValid(s)){t.valid.set(c);t.staticN++;}}}
  void solveSig(int sig){Table&t=*T[sig];auto t0=chrono::steady_clock::now();buildValid(t);vector<uint8_t> rem(t.RAW,0);deque<uint32_t>q;vector<Mv>mv;uint64_t seedsW=0,seedsL=0,stals=0,capEdges=0;
    for(uint64_t c=0;c<t.RAW;c++)if(t.valid.get(c)){
      S s=dec(t,c);bool promo=false;successors(t,s,mv,promo);if(sig==15)for(auto&m:mv)if(m.childSig!=sig){capFromFull[m.childSig]++;capEdges++;}
      if(promo){t.out.set(c,1);q.push_back((uint32_t)c);seedsW++;continue;}
      if(mv.empty()) {if(inCheck(s)){t.out.set(c,2);q.push_back((uint32_t)c);seedsL++;}else{t.out.set(c,3);stals++;}continue;}
      bool anyChildLoss=false;int unresolvedInternal=0, knownOppWin=0, blockers=0;
      for(auto&m:mv){if(m.childSig==sig){unresolvedInternal++;}else{uint8_t co=T[m.childSig]->out.get(m.childCode);if(co==2){anyChildLoss=true;break;}else if(co==1)knownOppWin++;else blockers++;}}
      if(anyChildLoss){t.out.set(c,1);q.push_back((uint32_t)c);seedsW++;continue;}
      int r=unresolvedInternal+blockers; // child WIN moves already eliminated; draw blockers prevent loss
      if(r==0){t.out.set(c,2);q.push_back((uint32_t)c);seedsL++;}else rem[c]=(uint8_t)min(255,r);
    }
    uint64_t pops=0;while(!q.empty()){
      uint32_t z=q.front();q.pop_front();uint8_t oz=t.out.get(z);
      predecessorsSame(t,z,[&](uint64_t p){if(t.out.get(p)!=0)return;if(oz==2){t.out.set(p,1);q.push_back((uint32_t)p);}else if(oz==1){if(rem[p]>0)--rem[p];if(rem[p]==0){t.out.set(p,2);q.push_back((uint32_t)p);}}});
      pops++;
    }
    for(uint64_t c=0;c<t.RAW;c++)if(t.valid.get(c)){uint8_t o=t.out.get(c);if(o==0){t.out.set(c,3);o=3;}S s=dec(t,c);if(o==3)t.D++;else {bool whiteWin=(s.turn==0&&o==1)||(s.turn==1&&o==2);if(whiteWin)t.W++;else t.B++;}}
    t.sec=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
    cerr<<f.name<<" sig="<<sig<<" raw="<<t.RAW<<" static="<<t.staticN<<" W="<<t.W<<" B="<<t.B<<" D="<<t.D<<" sec="<<fixed<<setprecision(3)<<t.sec<<"\n";
  }
  void run(){for(int s=0;s<16;s++)initTable(s);vector<int> order(16);iota(order.begin(),order.end(),0);stable_sort(order.begin(),order.end(),[](int a,int b){return __builtin_popcount((unsigned)a)<__builtin_popcount((unsigned)b);});
    for(int s:order)solveSig(s);
    uint64_t st=0,W=0,B=0,D=0;double total=0;for(int s=0;s<16;s++){st+=T[s]->staticN;W+=T[s]->W;B+=T[s]->B;D+=T[s]->D;total+=T[s]->sec;}
    auto&f15=*T[15];cout<<"RESULT "<<f.name<<" graph="<<st<<" W="<<W<<" B="<<B<<" D="<<D<<" full="<<f15.staticN<<" fullW="<<f15.W<<" fullB="<<f15.B<<" fullD="<<f15.D<<" sumSigSec="<<fixed<<setprecision(3)<<total<<"\n";
    cout<<"CAP15";for(int s=0;s<15;s++)if(capFromFull[s])cout<<" sig"<<s<<"="<<capFromFull[s];cout<<" total="<<accumulate(begin(capFromFull),end(capFromFull),uint64_t(0))<<"\n";
    uint64_t validBytes=0,outBytes=0;for(int s=0;s<16;s++){validBytes+=T[s]->valid.w.size()*8;outBytes+=T[s]->out.w.size()*8;}cout<<"PACKED persistent_valid_bytes="<<validBytes<<" outcome_bytes="<<outBytes<<" total="<<(validBytes+outBytes)<<"\n";
  }
};
int sq(string a){return (a[0]-'a')+8*(a[1]-'1');}
Fam mk(string name,int wc,int bc,string wp,string bp){return{name,BISHOP,BISHOP,wc,bc,sq(wp),sq(bp)};}
int main(int argc,char**argv){ios::sync_with_stdio(false);cin.tie(nullptr);initMoves();string nm=argc>1?argv[1]:"BB_same_c7_f2";vector<Fam>fs={mk("BB_opp_d7_e2",0,1,"d7","e2"),mk("BB_same_c7_f2",0,0,"c7","f2")};for(auto&f:fs)if(f.name==nm){Engine e(f);e.run();return 0;}cerr<<"unknown arena\n";return 2;}
