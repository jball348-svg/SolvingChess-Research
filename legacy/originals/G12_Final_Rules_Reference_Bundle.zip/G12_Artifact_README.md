# G12 Final-Rules Reference Suite

Frozen closeout: 12 August 2026.

## Authority boundary

- Chess-rule/state semantics remain `G10.RULES.v1.0` as quoted and inherited by the G11 handoff.
- The original hash-frozen `G10_Semantics_Contract_Bundle.zip` and its canonical byte/vector payload were not recoverable from the File Library in G12. G12 does **not** reconstruct or pretend to replay those bytes.
- Under the explicit G11 Successor Contract failure branch, `G12.STATE.SERIAL.v2` is a new superseding canonical artifact profile for forward work. It changes serialization/vector provenance, not chess rules.
- Historical G11 remains a formal HOLD against replay of the missing original G10 payload. That historical verdict is not rewritten.

## Core artifacts

- `G12_Superseding_State_Contract_v2.json`: new versioned state serialization profile.
- `G12_Conformance_Vectors_v2.json`: new frozen conformance corpus, explicitly not a reconstruction of G10 vectors.
- `g12_suite.cpp`: producer/reference A plus structurally distinct B checks for final-rules controls and exact arena production.
- `g12_verifier.cpp`: standalone target-centric verifier; contains no producer Engine-A attack/move implementation.
- `G12_Arena_Ledger.json`: exact producer counts/hashes.
- `G12_Verification_Ledger.json`: independent Bellman/rank replay with zero mismatches.
- `G12_History_Rules_Ledger.json`: history-sensitive controls showing board-only truth can change under repetition/move-count metadata and confirming mate precedence.
- `G12_KQK_Certificate_v2.bin`, `G12_KRK_Certificate_v2.bin`, `G12_KPK_Certificate_v2.bin`: frozen valid/win/rank arrays.

Certificate binary format: 8-byte ASCII magic (`G12TB2Q!`, `G12TB2R!`, `G12TB2P!`), u32 big-endian array size, then for every raw encoding id: `valid:u8`, `white_win:u8`, `rank:u16 big-endian`.

## Reproduction

Compile with any conforming C++20 compiler. The frozen run used GCC with `-O3 -std=c++20`.

```sh
g++ -O3 -std=c++20 g12_suite.cpp -o g12_producer
./g12_producer .
g++ -O3 -std=c++20 g12_verifier.cpp -o g12_verifier
./g12_verifier .
```

A second fresh-directory run reproduced seven principal output artifacts byte-for-byte. See `G12_Determinism_Ledger.txt` and `G12_SHA256SUMS.txt`.

## Claim discipline

The KQK, KRK and a-file KPK tables are exact for the declared clean-metadata roots (`halfmove=0`, current repetition count 1, no special rights). Their maximum White-win ranks are below 100 plies, and rank decreases under the certified winning strategy, so threefold/50/75 rules cannot preempt those wins. This does not claim that every possible history-decorated instance of the same board placement has the same outcome; `G12_History_Rules_Ledger.json` contains explicit counterexamples.

The same-colour K+2B vs K deadness result is exact for the declared arena: exhaustive independent mate scans find zero checkmates, bishop moves preserve the single colour complex, and bishop capture exits only to exact dead K+B vs K or K vs K states.
