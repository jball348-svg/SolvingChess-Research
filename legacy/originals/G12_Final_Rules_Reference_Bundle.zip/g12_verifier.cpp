#include <bits/stdc++.h>
using namespace std;
static inline int F(int s){return s&7;} static inline int R(int s){return s>>3;} static inline int SQ(int f,int r){return r*8+f;} static inline bool ON(int f,int r){return 0<=f&&f<8&&0<=r&&r<8;}
static inline bool W(char p){return p>='A'&&p<='Z';} static inline bool Bc(char p){return p>='a'&&p<='z';} static inline bool mine(char p,int s){return s?Bc(p):W(p);} static inline bool opp(char p,int s){return s?W(p):Bc(p);} static inline char U(char p){return toupper((unsigned char)p);} 
struct Move{int a=-1,b=-1;char pr=0;};
static string M(const Move&m){string z;z+=char('a'+F(m.a));z+=char('1'+R(m.a));z+=char('a'+F(m.b));z+=char('1'+R(m.b));if(m.pr)z+=(char)tolower(m.pr);return z;}
struct S{array<char,64>b{};int t=0;};
static int KS(const S&s,int side){char k=side?'k':'K';for(int i=0;i<64;i++)if(s.b[i]==k)return i;return -1;}
// Standalone target-centric oracle; no producer Engine-A code is present here.
static bool atk(const S&s,int t,int by){
 int f=F(t),r=R(t);char pawn=by?'p':'P',kn=by?'n':'N',kg=by?'k':'K';int pr=r-(by? -1:1);
 for(int df:{-1,1})if(ON(f+df,pr)&&s.b[SQ(f+df,pr)]==pawn)return true;
 static int N[8][2]={{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1},{-2,1},{-1,2}};for(auto&d:N)if(ON(f+d[0],r+d[1])&&s.b[SQ(f+d[0],r+d[1])]==kn)return true;
 for(int df=-1;df<=1;df++)for(int dr=-1;dr<=1;dr++)if((df||dr)&&ON(f+df,r+dr)&&s.b[SQ(f+df,r+dr)]==kg)return true;
 static int D[8][2]={{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
 for(int k=0;k<8;k++){int x=f+D[k][0],y=r+D[k][1];while(ON(x,y)){char p=s.b[SQ(x,y)];if(p){if(mine(p,by)){char q=U(p);bool o=k<4;if(q=='Q'||(o&&q=='R')||(!o&&q=='B'))return true;}break;}x+=D[k][0];y+=D[k][1];}}
 return false;
}
static S doMove(const S&s,const Move&m){S n=s;char p=n.b[m.a];n.b[m.a]=0;n.b[m.b]=m.pr?(s.t?(char)tolower(m.pr):(char)toupper(m.pr)):p;n.t^=1;return n;}
static vector<Move> legal(const S&s){
 vector<Move> c;int side=s.t;auto add=[&](int a,int b,char pr=0){if(!ON(F(b),R(b)))return;char q=s.b[b];if(q&&mine(q,side))return;if(q&&U(q)=='K')return;c.push_back({a,b,pr});};
 for(int a=0;a<64;a++){char p=s.b[a];if(!p||!mine(p,side))continue;char q=U(p);int f=F(a),r=R(a);
  if(q=='K'){for(int df=-1;df<=1;df++)for(int dr=-1;dr<=1;dr++)if((df||dr)&&ON(f+df,r+dr))add(a,SQ(f+df,r+dr));}
  else if(q=='P'){int d=side?-1:1,rr=r+d;if(ON(f,rr)){int one=SQ(f,rr);if(!s.b[one]){if(rr==0||rr==7)for(char pr:{'q','r','b','n'})add(a,one,pr);else{add(a,one);if((!side&&r==1)||(side&&r==6)){int two=SQ(f,r+2*d);if(!s.b[two])add(a,two);}}}for(int ff:{f-1,f+1})if(ON(ff,rr)){int b=SQ(ff,rr);if(s.b[b]&&opp(s.b[b],side)&&U(s.b[b])!='K'){if(rr==0||rr==7)for(char pr:{'q','r','b','n'})add(a,b,pr);else add(a,b);}}}}
  else{vector<pair<int,int>>ds;if(q=='B'||q=='Q')for(auto d:{pair<int,int>{1,1},{1,-1},{-1,1},{-1,-1}})ds.push_back(d);if(q=='R'||q=='Q')for(auto d:{pair<int,int>{1,0},{-1,0},{0,1},{0,-1}})ds.push_back(d);for(auto [df,dr]:ds)for(int k=1;;k++){int ff=f+k*df,rr=r+k*dr;if(!ON(ff,rr))break;int b=SQ(ff,rr);if(!s.b[b])add(a,b);else{if(opp(s.b[b],side)&&U(s.b[b])!='K')add(a,b);break;}}}
 }
 vector<Move>o;for(auto&m:c){S n=doMove(s,m);int k=KS(n,side);if(k>=0&&!atk(n,k,side^1))o.push_back(m);}sort(o.begin(),o.end(),[](auto&a,auto&b){return M(a)<M(b);});return o;
}
static bool valid(const S&s){int wk=0,bk=0;for(char p:s.b){wk+=p=='K';bk+=p=='k';}if(wk!=1||bk!=1)return false;int a=KS(s,0),b=KS(s,1);if(max(abs(F(a)-F(b)),abs(R(a)-R(b)))<=1)return false;int non=s.t^1;if(atk(s,KS(s,non),s.t))return false;for(int i=0;i<64;i++)if(U(s.b[i])=='P'&&(R(i)==0||R(i)==7))return false;return true;}
static uint64_t fnv(const string&x,uint64_t h=1469598103934665603ULL){for(unsigned char c:x){h^=c;h*=1099511628211ULL;}return h;}static string hx(uint64_t x){char b[17];snprintf(b,17,"%016llx",(unsigned long long)x);return b;}
struct C{string magic;vector<uint8_t>v,w;vector<uint16_t>r;};
static C load(const string&p){ifstream f(p,ios::binary);if(!f)throw runtime_error("open "+p);C c;char m[8];f.read(m,8);c.magic.assign(m,8);unsigned char b[4];f.read((char*)b,4);uint32_t n=(uint32_t(b[0])<<24)|(uint32_t(b[1])<<16)|(uint32_t(b[2])<<8)|b[3];c.v.resize(n);c.w.resize(n);c.r.resize(n);for(uint32_t i=0;i<n;i++){unsigned char x[4];f.read((char*)x,4);c.v[i]=x[0];c.w[i]=x[1];c.r[i]=(uint16_t(x[2])<<8)|x[3];}return c;}
static int I3(int x,int wk,int bk,int t){return (((x*64+wk)*64+bk)*2+t);}static void D3(int id,int&x,int&wk,int&bk,int&t){t=id&1;int z=id>>1;bk=z%64;z/=64;wk=z%64;x=z/64;}static S S3(char X,int x,int wk,int bk,int t){S s;s.b.fill(0);s.b[x]=X;s.b[wk]='K';s.b[bk]='k';s.t=t;return s;}
static int IP(int pr,int wk,int bk,int t){return (((pr*64+wk)*64+bk)*2+t);}static void DP(int id,int&pr,int&wk,int&bk,int&t){t=id&1;int z=id>>1;bk=z%64;z/=64;wk=z%64;pr=z/64;}static S SP(int pr,int wk,int bk,int t){S s;s.b.fill(0);s.b[SQ(0,pr+1)]='P';s.b[wk]='K';s.b[bk]='k';s.t=t;return s;}
struct V{long long states=0,edges=0,mismatch=0;uint64_t edgeh=0;int maxrank=0;};
static V verify3(const C&c,char X){V a;for(int id=0;id<(int)c.v.size();id++)if(c.v[id]){a.states++;int x,wk,bk,t;D3(id,x,wk,bk,t);S s=S3(X,x,wk,bk,t);if(!valid(s)){a.mismatch++;continue;}auto mv=legal(s);a.edges+=mv.size();for(auto&m:mv)a.edgeh=fnv(to_string(id)+":"+M(m)+";",a.edgeh?a.edgeh:1469598103934665603ULL);bool ew=false;int er=0;if(t==1&&mv.empty()&&atk(s,bk,0)){ew=true;er=0;}else if(t==0){int best=INT_MAX;for(auto&m:mv){S n=doMove(s,m);int nx=-1;for(int i=0;i<64;i++)if(n.b[i]==X){nx=i;break;}if(nx>=0){int ni=I3(nx,KS(n,0),KS(n,1),1);if(c.v[ni]&&c.w[ni])best=min(best,(int)c.r[ni]+1);}}if(best<INT_MAX){ew=true;er=best;}}else if(!mv.empty()){bool all=true;int worst=-1;for(auto&m:mv){S n=doMove(s,m);int nx=-1;for(int i=0;i<64;i++)if(n.b[i]==X){nx=i;break;}if(nx<0){all=false;break;}int ni=I3(nx,KS(n,0),KS(n,1),0);if(!c.v[ni]||!c.w[ni]){all=false;break;}worst=max(worst,(int)c.r[ni]+1);}if(all){ew=true;er=worst;}}if((bool)c.w[id]!=ew||(ew&&c.r[id]!=er))a.mismatch++;if(c.w[id])a.maxrank=max(a.maxrank,(int)c.r[id]);}return a;}
static V verifyP(const C&p,const C&q,const C&r){V a;auto promo=[&](const S&n)->pair<bool,int>{char pc=0;int x=-1;for(int i=0;i<64;i++)if(n.b[i]&&U(n.b[i])!='K'){pc=U(n.b[i]);x=i;}if(pc=='B'||pc=='N'||!pc)return {false,0};auto&c=pc=='Q'?q:r;int ni=I3(x,KS(n,0),KS(n,1),n.t);return {bool(c.v[ni]&&c.w[ni]),c.r[ni]};};for(int id=0;id<(int)p.v.size();id++)if(p.v[id]){a.states++;int pr,wk,bk,t;DP(id,pr,wk,bk,t);S s=SP(pr,wk,bk,t);if(!valid(s)){a.mismatch++;continue;}auto mv=legal(s);a.edges+=mv.size();for(auto&m:mv)a.edgeh=fnv(to_string(id)+":"+M(m)+";",a.edgeh?a.edgeh:1469598103934665603ULL);bool ew=false;int er=0;if(t==1&&mv.empty()&&atk(s,bk,0)){ew=true;er=0;}else if(t==0){int best=INT_MAX;for(auto&m:mv){S n=doMove(s,m);int ps=-1;for(int i=0;i<64;i++)if(n.b[i]=='P'){ps=i;break;}if(ps>=0){int ni=IP(R(ps)-1,KS(n,0),KS(n,1),1);if(p.v[ni]&&p.w[ni])best=min(best,(int)p.r[ni]+1);}else{auto [w,rr]=promo(n);if(w)best=min(best,rr+1);}}if(best<INT_MAX){ew=true;er=best;}}else if(!mv.empty()){bool all=true;int worst=-1;for(auto&m:mv){S n=doMove(s,m);int ps=-1;for(int i=0;i<64;i++)if(n.b[i]=='P'){ps=i;break;}if(ps<0){all=false;break;}int ni=IP(R(ps)-1,KS(n,0),KS(n,1),0);if(!p.v[ni]||!p.w[ni]){all=false;break;}worst=max(worst,(int)p.r[ni]+1);}if(all){ew=true;er=worst;}}if((bool)p.w[id]!=ew||(ew&&p.r[id]!=er))a.mismatch++;if(p.w[id])a.maxrank=max(a.maxrank,(int)p.r[id]);}return a;}
struct BB{long long validn=0,checks=0,evasion=0,caps=0,mates=0;uint64_t h=0;};
static BB verifyBB(){
    BB a; uint64_t h=1469598103934665603ULL;
    for(int b1=0;b1<64;b1++) for(int b2=b1+1;b2<64;b2++){
        if(((F(b1)+R(b1))&1)!=((F(b2)+R(b2))&1)) continue;
        for(int wk=0;wk<64;wk++){
            if(wk==b1||wk==b2) continue;
            for(int bk=0;bk<64;bk++){
                if(bk==b1||bk==b2||bk==wk) continue;
                for(int t=0;t<2;t++){
                    S c; c.b.fill(0); c.b[wk]='K'; c.b[bk]='k'; c.b[b1]='B'; c.b[b2]='B'; c.t=t;
                    if(valid(c)) a.validn++;
                }
                S s; s.b.fill(0); s.b[wk]='K'; s.b[bk]='k'; s.b[b1]='B'; s.b[b2]='B'; s.t=1;
                if(!valid(s)||!atk(s,bk,0)) continue;
                a.checks++; auto mv=legal(s); a.evasion+=mv.size();
                for(auto&m:mv) if(s.b[m.b]=='B') a.caps++;
                if(mv.empty()) a.mates++;
                h=fnv(to_string(b1)+","+to_string(b2)+","+to_string(wk)+","+to_string(bk)+":"+to_string(mv.size())+";",h);
            }
        }
    }
    a.h=h; return a;
}
int main(int ac,char**av){string d=ac>1?av[1]:".";auto q=load(d+"/G12_KQK_Certificate_v2.bin"),r=load(d+"/G12_KRK_Certificate_v2.bin"),p=load(d+"/G12_KPK_Certificate_v2.bin");if(q.magic!="G12TB2Q!"||r.magic!="G12TB2R!"||p.magic!="G12TB2P!")return 9;V vq=verify3(q,'Q'); V vr=verify3(r,'R'); V vp=verifyP(p,q,r); BB bb=verifyBB();ofstream o(d+"/G12_Verification_Ledger.json");o<<"{\n";auto e=[&](string n,V v,bool c){o<<"  \""<<n<<"\": {\"states\": "<<v.states<<", \"legal_edges\": "<<v.edges<<", \"max_rank\": "<<v.maxrank<<", \"bellman_rank_mismatches\": "<<v.mismatch<<", \"edge_fnv64_B\": \""<<hx(v.edgeh)<<"\"}"<<(c?",":"")<<"\n";};e("KQK",vq,true);e("KRK",vr,true);e("KPK",vp,true);o<<"  \"KBB_same_colour\": {\"valid\": "<<bb.validn<<", \"black_in_check_states\": "<<bb.checks<<", \"checked_state_evasion_edges\": "<<bb.evasion<<", \"bishop_capture_evasion_edges\": "<<bb.caps<<", \"checkmates\": "<<bb.mates<<", \"audit_fnv64_B\": \""<<hx(bb.h)<<"\"}\n}\n";long long bad=vq.mismatch+vr.mismatch+vp.mismatch+bb.mates;if(bad){cerr<<"VERIFY FAIL "<<bad<<"\n";return 8;}cerr<<"VERIFY PASS states="<<vq.states+vr.states+vp.states<<" BB="<<bb.validn<<"\n";}
