#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PLATFORM=ROOT/'g13_platform.py'
BASE=ROOT/'campaign'
PROBLEM=BASE/'problem.json'
CAS=BASE/'cas'

def sha(p):
    h=hashlib.sha256(); h.update(Path(p).read_bytes()); return h.hexdigest()
def canon(o): return (json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=True)+'\n').encode('ascii')
def cmd(args,check=False):
    p=subprocess.run([sys.executable,str(PLATFORM)]+args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if check and p.returncode!=0: raise RuntimeError(p.stderr)
    return p

def expect_fail(name,p,needle=None):
    ok=p.returncode!=0 and (needle is None or needle.lower() in (p.stderr+p.stdout).lower())
    return {"test":name,"returncode":p.returncode,"rejected":ok,"diagnostic":(p.stderr.strip() or p.stdout.strip())[:500]}

def main():
    tests=[]
    troot=ROOT/'failure_tests'
    if troot.exists(): shutil.rmtree(troot)
    troot.mkdir()
    # 1 problem/plan identity mismatch.
    plan=troot/'bad_problem_plan.json'
    obj=json.loads((BASE/'A_baseline_4'/'plan.json').read_text())
    obj['problem_sha256']='0'*64
    plan.write_bytes(canon(obj))
    cp=troot/'cp1'; cp.mkdir()
    p=cmd(['worker','--problem',str(PROBLEM),'--plan',str(plan),'--shard','0','--cas',str(CAS),'--checkpoints',str(cp)])
    tests.append(expect_fail('plan_problem_hash_mismatch',p,'plan/problem hash mismatch'))

    # 2 checkpoint from a different execution plan is rejected.
    good_plan=BASE/'A_baseline_4'/'plan.json'
    source_cp=BASE/'A_baseline_4'/'checkpoints'/'shard-00000.checkpoint.json'
    cp2=troot/'cp2'; cp2.mkdir(); shutil.copy2(source_cp,cp2/'shard-00000.checkpoint.json')
    other_plan=BASE/'B_kill_restart_4'/'plan.json'
    p=cmd(['worker','--problem',str(PROBLEM),'--plan',str(other_plan),'--shard','0','--cas',str(CAS),'--checkpoints',str(cp2)])
    tests.append(expect_fail('cross_plan_checkpoint_reuse',p,'checkpoint identity mismatch'))

    # 3 missing shard result blocks merge.
    cp3=troot/'cp3'; shutil.copytree(BASE/'A_baseline_4'/'checkpoints',cp3)
    (cp3/'shard-00002.result.json').unlink()
    p=cmd(['merge','--problem',str(PROBLEM),'--plan',str(good_plan),'--cas',str(CAS),'--checkpoints',str(cp3),'--out',str(troot/'m3')])
    tests.append(expect_fail('missing_shard_blocks_merge',p,'missing shard result'))

    # 4 deliberately overlapping execution plan: workers can compute it, merger must reject overlap.
    small_problem=troot/'small_problem.json'
    cmd(['make-problem','--out',str(small_problem),'--components','24','--nodes','16'],check=True)
    badplan=troot/'overlap_plan.json'
    pb=small_problem.read_bytes(); ph=hashlib.sha256(pb).hexdigest()
    pobj={"schema":"G13.EXECUTION.PLAN.v1","problem_sha256":ph,"partition_count":2,"execution_order":"forward","shards":[{"shard_id":0,"component_start":0,"component_end":16},{"shard_id":1,"component_start":12,"component_end":24}],"merge_rule":"hostile overlap test"}
    badplan.write_bytes(canon(pobj)); cpx=troot/'overlap_cp'; casx=troot/'overlap_cas'
    for sid in (0,1):
        p=cmd(['worker','--problem',str(small_problem),'--plan',str(badplan),'--shard',str(sid),'--cas',str(casx),'--checkpoints',str(cpx)],check=True)
    p=cmd(['merge','--problem',str(small_problem),'--plan',str(badplan),'--cas',str(casx),'--checkpoints',str(cpx),'--out',str(troot/'overlap_merge')])
    tests.append(expect_fail('overlap_blocks_merge',p,'gap/overlap'))

    # 5 CAS tampering is detected on read.
    # Make a tiny valid object through a worker; then mutate the underlying content addressed path.
    casroot=troot/'tamper_cas'; cp5=troot/'cp5'; plan5=troot/'plan5.json'
    cmd(['make-plan','--problem',str(small_problem),'--out',str(plan5),'--partitions','2'],check=True)
    cmd(['worker','--problem',str(small_problem),'--plan',str(plan5),'--shard','0','--cas',str(casroot),'--checkpoints',str(cp5)],check=True)
    r=json.loads((cp5/'shard-00000.result.json').read_text()); digest=r['truth_sha256']; op=casroot/'objects'/'sha256'/digest[:2]/digest[2:]
    original=op.read_bytes(); op.write_bytes(original+b'X')
    # merger reaches corrupt object after shard1 exists.
    cmd(['worker','--problem',str(small_problem),'--plan',str(plan5),'--shard','1','--cas',str(casroot),'--checkpoints',str(cp5)],check=True)
    p=cmd(['merge','--problem',str(small_problem),'--plan',str(plan5),'--cas',str(casroot),'--checkpoints',str(cp5),'--out',str(troot/'tamper_merge')])
    tests.append(expect_fail('cas_tamper_detected',p,'CAS corruption'))

    all_ok=all(t['rejected'] for t in tests)
    ledger={"schema":"G13.FAILURE.INJECTION.v1","claim_class":"engineering verifier/adversarial test","tests":tests,"all_hostile_cases_rejected":all_ok}
    (ROOT/'G13_Failure_Injection_Ledger.json').write_bytes(canon(ledger))
    print(json.dumps(ledger,indent=2))
    if not all_ok: return 1
    return 0
if __name__=='__main__': sys.exit(main())
