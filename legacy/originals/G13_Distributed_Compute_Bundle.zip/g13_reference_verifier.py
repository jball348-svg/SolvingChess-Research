#!/usr/bin/env python3
import argparse, hashlib, json, struct
from pathlib import Path

def digest(seed, comp, node):
    return hashlib.sha256(bytes.fromhex(seed)+struct.pack('<IH',comp,node)).digest()

def expected_node(seed, comp, node, earlier_out, earlier_rank):
    d=digest(seed,comp,node)
    white=((d[0]^node^comp)&1)==0
    terminal=(node==0 or d[1]%11==0)
    if terminal:
        t=d[2]%5
        return (1 if t==0 else (2 if t==1 else 0),0)
    fan=1+(d[3]%min(4,node)); start=d[4]%node
    children=[(start+t)%node for t in range(fan)]
    vals=[earlier_out[c] for c in children]
    if white:
        if 1 in vals: return 1,1+min(earlier_rank[c] for c in children if earlier_out[c]==1)
        if 0 in vals: return 0,0
        return 2,1+max(earlier_rank[c] for c in children)
    else:
        if 2 in vals: return 2,1+min(earlier_rank[c] for c in children if earlier_out[c]==2)
        if 0 in vals: return 0,0
        return 1,1+max(earlier_rank[c] for c in children)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--problem',required=True); ap.add_argument('--truth',required=True); ap.add_argument('--certificate',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    prob=json.loads(Path(a.problem).read_text()); comps=prob['parameters']['components']; nodes=prob['parameters']['nodes_per_component']; seed=prob['problem_seed_hex']
    tb=Path(a.truth).read_bytes(); cb=Path(a.certificate).read_bytes(); trsz=7; csz=9
    mism=[]; checked=0; truth_mism=0
    if len(tb)!=comps*nodes*trsz or len(cb)!=comps*nodes*csz: mism.append({'kind':'length','truth_bytes':len(tb),'certificate_bytes':len(cb)})
    for comp in range(comps):
        outs=[]; ranks=[]
        for node in range(nodes):
            off=(comp*nodes+node)*csz; ccomp,cnode,o,r=struct.unpack_from('<IHBH',cb,off)
            toff=(comp*nodes+node)*trsz; tcomp,tnode,to=struct.unpack_from('<IHB',tb,toff)
            if (ccomp,cnode)!=(comp,node) or (tcomp,tnode)!=(comp,node):
                if len(mism)<20: mism.append({'kind':'index','at':[comp,node],'cert':[ccomp,cnode],'truth':[tcomp,tnode]})
            if to!=o:
                truth_mism+=1
                if len(mism)<20: mism.append({'kind':'truth_certificate','at':[comp,node],'truth':to,'cert':o})
            eo,er=expected_node(seed,comp,node,outs,ranks)
            if (o,r)!=(eo,er):
                if len(mism)<20: mism.append({'kind':'bellman','at':[comp,node],'observed':[o,r],'expected':[eo,er]})
            outs.append(o); ranks.append(r); checked+=1
    ledger={'schema':'G13.REFERENCE.VERIFICATION.v1','claim_class':'independent structural verification of engineering reference; not chess truth','states_checked':checked,'truth_certificate_mismatches':truth_mism,'bellman_or_index_mismatches':sum(1 for x in mism if x['kind']!='truth_certificate'),'mismatch_examples':mism,'pass':len(mism)==0}
    Path(a.out).write_text(json.dumps(ledger,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps(ledger,indent=2)); return 0 if ledger['pass'] else 1
if __name__=='__main__': raise SystemExit(main())
