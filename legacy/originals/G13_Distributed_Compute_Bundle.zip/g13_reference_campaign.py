#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLATFORM = ROOT / "g13_platform.py"
WORK = ROOT / "campaign"
CAS = WORK / "cas"
PROBLEM = WORK / "problem.json"


def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()

def canon(obj):
    return (json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=True)+"\n").encode("ascii")

def run(cmd, check=True):
    p=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if check and p.returncode!=0:
        raise RuntimeError(f"command failed {p.returncode}: {' '.join(map(str,cmd))}\nOUT {p.stdout}\nERR {p.stderr}")
    return p

def worker_cmd(plan, shard, cp, kill=None):
    cmd=[sys.executable,str(PLATFORM),"worker","--problem",str(PROBLEM),"--plan",str(plan),"--shard",str(shard),"--cas",str(CAS),"--checkpoints",str(cp),"--checkpoint-every","43"]
    if kill is not None: cmd += ["--kill-after",str(kill)]
    return cmd

def scenario(name, partitions, order, kill_shard=None, kill_after=None, duplicate_retry=False):
    scen=WORK/name; cp=scen/"checkpoints"; out=scen/"merged"; scen.mkdir(parents=True,exist_ok=True)
    plan=scen/"plan.json"
    run([sys.executable,str(PLATFORM),"make-plan","--problem",str(PROBLEM),"--out",str(plan),"--partitions",str(partitions),"--order",order])
    shard_ids=list(range(partitions))
    if order=="reverse": shard_ids=list(reversed(shard_ids))
    elif order=="even-odd": shard_ids=shard_ids[::2]+shard_ids[1::2]
    kill_evidence=None
    if kill_shard is not None:
        p=run(worker_cmd(plan,kill_shard,cp,kill_after),check=False)
        if p.returncode!=99: raise RuntimeError(f"expected controlled kill 99, got {p.returncode}: {p.stderr}")
        cpath=cp/f"shard-{kill_shard:05d}.checkpoint.json"
        if not cpath.exists(): raise RuntimeError("kill produced no checkpoint")
        snap=scen/"controlled_kill_checkpoint.json"
        shutil.copy2(cpath,snap)
        kill_evidence={"returncode":p.returncode,"stderr":p.stderr.strip(),"checkpoint_sha256":sha(cpath),"snapshot_file":snap.name}
    todo=[s for s in shard_ids]
    # Run independent workers in fresh subprocesses concurrently.
    with ThreadPoolExecutor(max_workers=min(4,partitions)) as ex:
        fut={ex.submit(run,worker_cmd(plan,s,cp,None)):s for s in todo}
        for f in as_completed(fut): f.result()
    duplicate=None
    if duplicate_retry:
        s=partitions//2
        rp=cp/f"shard-{s:05d}.result.json"; before=sha(rp)
        # Remove only result, retain terminal checkpoint; rerun should resume from completed checkpoint and reproduce result bytes.
        rp.unlink()
        run(worker_cmd(plan,s,cp,None))
        after=sha(rp)
        duplicate={"shard":s,"result_sha256_before":before,"result_sha256_after":after,"byte_identical":before==after}
    m=run([sys.executable,str(PLATFORM),"merge","--problem",str(PROBLEM),"--plan",str(plan),"--cas",str(CAS),"--checkpoints",str(cp),"--out",str(out)])
    mm=json.loads(m.stdout)
    return {"name":name,"partitions":partitions,"order":order,"plan_sha256":sha(plan),"truth_sha256":mm["truth_sha256"],"certificate_sha256":mm["certificate_sha256"],"truth_bytes":mm["truth_bytes"],"certificate_bytes":mm["certificate_bytes"],"kill":kill_evidence,"duplicate_retry":duplicate}

def main():
    if WORK.exists(): shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    run([sys.executable,str(PLATFORM),"make-problem","--out",str(PROBLEM),"--components","2048","--nodes","32"])
    scenarios=[]
    scenarios.append(scenario("A_baseline_4",4,"forward"))
    scenarios.append(scenario("B_kill_restart_4",4,"even-odd",kill_shard=1,kill_after=120))
    scenarios.append(scenario("C_repartition_7",7,"reverse"))
    scenarios.append(scenario("D_repartition_retry_11",11,"even-odd",duplicate_retry=True))
    truth={s["truth_sha256"] for s in scenarios}; cert={s["certificate_sha256"] for s in scenarios}
    if len(truth)!=1 or len(cert)!=1: raise RuntimeError("nondeterministic merged hashes")
    if not scenarios[-1]["duplicate_retry"]["byte_identical"]: raise RuntimeError("duplicate retry changed shard result")
    ledger={
        "schema":"G13.REFERENCE.CAMPAIGN.v1",
        "claim_class":"exact deterministic engineering test; not chess truth",
        "problem_sha256":sha(PROBLEM),
        "state_count":2048*32,
        "component_count":2048,
        "nodes_per_component":32,
        "scenarios":scenarios,
        "invariants":{
            "all_truth_hashes_identical":True,
            "all_certificate_hashes_identical":True,
            "controlled_worker_kill_recovered":True,
            "repartitioning_preserved_result":True,
            "completion_order_preserved_result":True,
            "duplicate_retry_byte_identical":True,
            "fresh_subprocess_workers":True,
            "shared_mutable_solver_state":False,
        },
        "frozen_truth_sha256":next(iter(truth)),
        "frozen_certificate_sha256":next(iter(cert)),
    }
    (ROOT/"G13_Reference_Campaign_Ledger.json").write_bytes(canon(ledger))
    # Fresh full repeat in a separate campaign tree by recursively invoking this logic is expensive; instead copy nothing and rerun a fifth plan with 13 partitions against same immutable problem/CAS.
    fresh=scenario("E_fresh_13",13,"reverse")
    fresh_ok=(fresh["truth_sha256"]==ledger["frozen_truth_sha256"] and fresh["certificate_sha256"]==ledger["frozen_certificate_sha256"])
    frep={"schema":"G13.FRESH.REPRO.v1","scenario":fresh,"matches_frozen":fresh_ok}
    (ROOT/"G13_Fresh_Reproduction.json").write_bytes(canon(frep))
    if not fresh_ok: raise RuntimeError("fresh reproduction mismatch")
    print(json.dumps({"ledger":str(ROOT/"G13_Reference_Campaign_Ledger.json"),"truth":ledger["frozen_truth_sha256"],"certificate":ledger["frozen_certificate_sha256"],"fresh":fresh_ok},indent=2))
if __name__=="__main__": main()
