#!/usr/bin/env python3
import argparse, hashlib, json, os, struct, sys, tempfile
from pathlib import Path

SCHEMA_PROBLEM = "G13.PROBLEM.v1"
SCHEMA_PLAN = "G13.EXECUTION.PLAN.v1"
SCHEMA_CHECKPOINT = "G13.CHECKPOINT.v1"
SCHEMA_SHARD = "G13.SHARD.RESULT.v1"
SCHEMA_MERGE = "G13.MERGE.v1"


def canonical_json_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n"


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


class CAS:
    def __init__(self, root):
        self.root = Path(root)
        self.objects = self.root / "objects" / "sha256"
        self.objects.mkdir(parents=True, exist_ok=True)

    def path(self, digest):
        return self.objects / digest[:2] / digest[2:]

    def put_bytes(self, data):
        digest = sha256_bytes(data)
        p = self.path(digest)
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix="cas-", dir=str(p.parent))
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                try:
                    os.replace(tmp, p)
                except FileExistsError:
                    os.unlink(tmp)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
        return digest

    def put_file(self, path):
        return self.put_bytes(Path(path).read_bytes())

    def get_bytes(self, digest):
        p = self.path(digest)
        data = p.read_bytes()
        got = sha256_bytes(data)
        if got != digest:
            raise RuntimeError(f"CAS corruption: expected {digest}, got {got}")
        return data


def write_canonical_json(path, obj):
    Path(path).write_bytes(canonical_json_bytes(obj))
    return sha256_file(path)


def make_problem(path, components, nodes_per_component=32):
    problem = {
        "schema": SCHEMA_PROBLEM,
        "problem_name": "G13 deterministic exact-game engineering reference",
        "workload": "independent_component_minimax_v1",
        "semantic_profile": "G13.TEST.SEMANTICS.v1",
        "ruleset_ref": "engineering-reference-only-not-chess",
        "state_serialization_ref": "component:u32,node:u16,outcome:u8,rank:u16",
        "parameters": {
            "components": int(components),
            "nodes_per_component": int(nodes_per_component),
            "generator": "sha256(problem_seed||component||node)",
            "terminal_modulus": 11,
            "edge_fanout_max": 4,
        },
        "problem_seed_hex": hashlib.sha256(b"G13 deterministic reference seed v1").hexdigest(),
        "partition_semantics": "components are independent exact subgames; partitioning changes execution only, never problem identity",
    }
    write_canonical_json(path, problem)
    return problem


def partition_ranges(n, parts):
    if parts <= 0 or parts > n:
        raise ValueError("invalid partition count")
    out = []
    q, r = divmod(n, parts)
    s = 0
    for i in range(parts):
        e = s + q + (1 if i < r else 0)
        out.append((s, e))
        s = e
    assert out[0][0] == 0 and out[-1][1] == n
    return out


def make_plan(problem_path, plan_path, partitions, execution_order="forward"):
    pdata = Path(problem_path).read_bytes()
    problem = json.loads(pdata)
    ph = sha256_bytes(pdata)
    n = problem["parameters"]["components"]
    ranges = partition_ranges(n, partitions)
    shards = []
    for i, (s, e) in enumerate(ranges):
        shards.append({"shard_id": i, "component_start": s, "component_end": e})
    plan = {
        "schema": SCHEMA_PLAN,
        "problem_sha256": ph,
        "partition_count": partitions,
        "execution_order": execution_order,
        "shards": shards,
        "merge_rule": "strict ascending component range; reject gaps/overlap; result bytes independent of completion order",
    }
    write_canonical_json(plan_path, plan)
    return plan


def _digest_int(seed_hex, component, node):
    h = hashlib.sha256()
    h.update(bytes.fromhex(seed_hex))
    h.update(struct.pack("<IH", component, node))
    return h.digest()


def solve_component(seed_hex, component, nodes):
    # Outcome coding from White perspective: 0 draw, 1 white win, 2 white loss.
    # Graph is acyclic: every child index < node. Terminal facts are deterministic.
    outcome = [0] * nodes
    rank = [0] * nodes
    for node in range(nodes):
        d = _digest_int(seed_hex, component, node)
        side_white = ((d[0] ^ node ^ component) & 1) == 0
        terminal = node == 0 or (d[1] % 11 == 0)
        if terminal:
            t = d[2] % 5
            outcome[node] = 1 if t == 0 else (2 if t == 1 else 0)
            rank[node] = 0
            continue
        max_f = min(4, node)
        fanout = 1 + (d[3] % max_f)
        start_child = d[4] % node
        children = [((start_child + t) % node) for t in range(fanout)]
        ch_out = [outcome[c] for c in children]
        if side_white:
            if 1 in ch_out:
                outcome[node] = 1
                rank[node] = 1 + min(rank[c] for c in children if outcome[c] == 1)
            elif 0 in ch_out:
                outcome[node] = 0
                rank[node] = 0
            else:
                outcome[node] = 2
                rank[node] = 1 + max(rank[c] for c in children)
        else:
            if 2 in ch_out:
                outcome[node] = 2
                rank[node] = 1 + min(rank[c] for c in children if outcome[c] == 2)
            elif 0 in ch_out:
                outcome[node] = 0
                rank[node] = 0
            else:
                outcome[node] = 1
                rank[node] = 1 + max(rank[c] for c in children)
    return outcome, rank


def encode_component(component, outcome, rank):
    truth = bytearray()
    cert = bytearray()
    for node, (o, r) in enumerate(zip(outcome, rank)):
        truth += struct.pack("<IHB", component, node, o)
        cert += struct.pack("<IHBH", component, node, o, r)
    return bytes(truth), bytes(cert)


def load_json(path):
    return json.loads(Path(path).read_text("ascii"))


def worker(problem_path, plan_path, shard_id, cas_root, checkpoint_dir, checkpoint_every, kill_after=None):
    problem_bytes = Path(problem_path).read_bytes()
    plan_bytes = Path(plan_path).read_bytes()
    problem = json.loads(problem_bytes)
    plan = json.loads(plan_bytes)
    problem_hash = sha256_bytes(problem_bytes)
    plan_hash = sha256_bytes(plan_bytes)
    if plan["problem_sha256"] != problem_hash:
        raise RuntimeError("plan/problem hash mismatch")
    shard = next((s for s in plan["shards"] if s["shard_id"] == shard_id), None)
    if shard is None:
        raise RuntimeError("unknown shard")
    start, end = shard["component_start"], shard["component_end"]
    cp_dir = Path(checkpoint_dir)
    cp_dir.mkdir(parents=True, exist_ok=True)
    cp_path = cp_dir / f"shard-{shard_id:05d}.checkpoint.json"
    cas = CAS(cas_root)
    cursor = start
    truth = bytearray()
    cert = bytearray()
    checkpoint_seq = 0
    if cp_path.exists():
        cp = load_json(cp_path)
        expected = (cp["schema"] == SCHEMA_CHECKPOINT and cp["problem_sha256"] == problem_hash and cp["plan_sha256"] == plan_hash and cp["shard_id"] == shard_id and cp["component_start"] == start and cp["component_end"] == end)
        if not expected:
            raise RuntimeError("checkpoint identity mismatch")
        cursor = cp["next_component"]
        truth = bytearray(cas.get_bytes(cp["partial_truth_sha256"]))
        cert = bytearray(cas.get_bytes(cp["partial_certificate_sha256"]))
        checkpoint_seq = cp["checkpoint_seq"]
    nodes = problem["parameters"]["nodes_per_component"]
    seed = problem["problem_seed_hex"]
    since_launch = 0

    def persist(next_component):
        nonlocal checkpoint_seq
        th = cas.put_bytes(bytes(truth))
        ch = cas.put_bytes(bytes(cert))
        checkpoint_seq += 1
        cp = {
            "schema": SCHEMA_CHECKPOINT,
            "problem_sha256": problem_hash,
            "plan_sha256": plan_hash,
            "shard_id": shard_id,
            "component_start": start,
            "component_end": end,
            "next_component": next_component,
            "checkpoint_seq": checkpoint_seq,
            "partial_truth_sha256": th,
            "partial_certificate_sha256": ch,
            "partial_truth_bytes": len(truth),
            "partial_certificate_bytes": len(cert),
        }
        tmp = cp_path.with_suffix(".tmp")
        tmp.write_bytes(canonical_json_bytes(cp))
        os.replace(tmp, cp_path)
        return cp

    for c in range(cursor, end):
        out, ranks = solve_component(seed, c, nodes)
        tb, cb = encode_component(c, out, ranks)
        truth += tb
        cert += cb
        since_launch += 1
        next_c = c + 1
        if checkpoint_every and ((next_c - start) % checkpoint_every == 0):
            persist(next_c)
        if kill_after is not None and since_launch >= kill_after and next_c < end:
            # Persist only if we hit a checkpoint naturally; otherwise deliberately lose the tail to test rollback.
            sys.stderr.write(f"CONTROLLED_KILL shard={shard_id} at_component={next_c}\n")
            return 99
    if cursor < end or not cp_path.exists():
        persist(end)
    truth_hash = cas.put_bytes(bytes(truth))
    cert_hash = cas.put_bytes(bytes(cert))
    result = {
        "schema": SCHEMA_SHARD,
        "problem_sha256": problem_hash,
        "plan_sha256": plan_hash,
        "shard_id": shard_id,
        "component_start": start,
        "component_end": end,
        "truth_sha256": truth_hash,
        "certificate_sha256": cert_hash,
        "truth_bytes": len(truth),
        "certificate_bytes": len(cert),
        "checkpoint_sha256": sha256_file(cp_path),
    }
    result_path = cp_dir / f"shard-{shard_id:05d}.result.json"
    result_path.write_bytes(canonical_json_bytes(result))
    return 0


def merge(problem_path, plan_path, cas_root, checkpoint_dir, out_dir):
    pbytes = Path(problem_path).read_bytes(); ph = sha256_bytes(pbytes)
    plbytes = Path(plan_path).read_bytes(); plh = sha256_bytes(plbytes)
    problem = json.loads(pbytes); plan = json.loads(plbytes)
    cas = CAS(cas_root)
    results = []
    for shard in sorted(plan["shards"], key=lambda x: x["component_start"]):
        rp = Path(checkpoint_dir) / f"shard-{shard['shard_id']:05d}.result.json"
        if not rp.exists():
            raise RuntimeError(f"missing shard result {shard['shard_id']}")
        r = load_json(rp)
        if r["problem_sha256"] != ph or r["plan_sha256"] != plh:
            raise RuntimeError("shard result identity mismatch")
        if (r["component_start"], r["component_end"]) != (shard["component_start"], shard["component_end"]):
            raise RuntimeError("shard range mismatch")
        results.append(r)
    expected = 0
    truth_parts = []
    cert_parts = []
    for r in results:
        if r["component_start"] != expected:
            raise RuntimeError("gap/overlap in deterministic merge")
        expected = r["component_end"]
        truth_parts.append(cas.get_bytes(r["truth_sha256"]))
        cert_parts.append(cas.get_bytes(r["certificate_sha256"]))
    if expected != problem["parameters"]["components"]:
        raise RuntimeError("incomplete merge coverage")
    truth = b"".join(truth_parts)
    cert = b"".join(cert_parts)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    (out / "truth.bin").write_bytes(truth)
    (out / "certificate.bin").write_bytes(cert)
    truth_hash = sha256_bytes(truth); cert_hash = sha256_bytes(cert)
    merge_manifest = {
        "schema": SCHEMA_MERGE,
        "problem_sha256": ph,
        "execution_plan_sha256": plh,
        "truth_sha256": truth_hash,
        "certificate_sha256": cert_hash,
        "truth_bytes": len(truth),
        "certificate_bytes": len(cert),
        "shard_result_sha256": [sha256_file(Path(checkpoint_dir) / f"shard-{s['shard_id']:05d}.result.json") for s in sorted(plan["shards"], key=lambda x: x["component_start"])],
    }
    write_canonical_json(out / "merge_manifest.json", merge_manifest)
    return merge_manifest


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("make-problem"); p.add_argument("--out", required=True); p.add_argument("--components", type=int, required=True); p.add_argument("--nodes", type=int, default=32)
    p = sp.add_parser("make-plan"); p.add_argument("--problem", required=True); p.add_argument("--out", required=True); p.add_argument("--partitions", type=int, required=True); p.add_argument("--order", default="forward")
    p = sp.add_parser("worker"); p.add_argument("--problem", required=True); p.add_argument("--plan", required=True); p.add_argument("--shard", type=int, required=True); p.add_argument("--cas", required=True); p.add_argument("--checkpoints", required=True); p.add_argument("--checkpoint-every", type=int, default=128); p.add_argument("--kill-after", type=int)
    p = sp.add_parser("merge"); p.add_argument("--problem", required=True); p.add_argument("--plan", required=True); p.add_argument("--cas", required=True); p.add_argument("--checkpoints", required=True); p.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.cmd == "make-problem": make_problem(a.out, a.components, a.nodes); return 0
    if a.cmd == "make-plan": make_plan(a.problem, a.out, a.partitions, a.order); return 0
    if a.cmd == "worker": return worker(a.problem, a.plan, a.shard, a.cas, a.checkpoints, a.checkpoint_every, a.kill_after)
    if a.cmd == "merge":
        m = merge(a.problem, a.plan, a.cas, a.checkpoints, a.out); print(json.dumps(m, sort_keys=True)); return 0
    return 2

if __name__ == "__main__":
    sys.exit(main())
