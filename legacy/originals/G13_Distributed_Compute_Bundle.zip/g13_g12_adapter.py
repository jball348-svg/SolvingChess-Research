#!/usr/bin/env python3
import argparse, hashlib, json, zipfile
from pathlib import Path
EXPECTED="7641e0f8a4e621efb90b75cd3ce99b44e96c07a2f3541114611126a076d5695c"
INVENTORY={
"G12_Superseding_State_Contract_v2.json":"73ef6660d98c1aa072feb8a04764b26cf4c69b9d545abdb2f4d8f105965d06a8",
"G12_Conformance_Vectors_v2.json":"ed972a06e6d855ec47077a90dc81e8c49db6ba1a21562f44cd684a600b6534d8",
"g12_suite.cpp":"d759ccf161637a4b612a48f04f7ecab26b1fcab4204711030fe1c304ac40dfec",
"g12_verifier.cpp":"99cd9a3466169d558128df49a31416c54e380d10133740cb9c8f44fa00ed34ef",
"G12_Arena_Ledger.json":"6cd144db4dd8e5416f7dc41e2b29ddc5be76d15aa0350db10b70adf16cc7689d",
"G12_Verification_Ledger.json":"792ea0b9a427f9d77a97b50888f8eb7b6c47c9df0fc65b89945b72e5c83b78d4",
"G12_History_Rules_Ledger.json":"c8a374bd5237cab0372bd9ad0ddff0a166cebe6c23f82c14a452687f6b7432eb",
"G12_KQK_Certificate_v2.bin":"e01dd995e050542e63d2f7c3f6fe1a9ef05a1ce065d64704e743907f8a0c9127",
"G12_KRK_Certificate_v2.bin":"badc392dbdd13b96862c4e5859cf50468f65cd65a72f40747d9300ebcc110793",
"G12_KPK_Certificate_v2.bin":"b515ae01fa2c23669b00d967d9a86d921534874f90d3d53e8bef1f1155359eba",
}
def shab(data): return hashlib.sha256(data).hexdigest()
def canon(o): return (json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=True)+"\n").encode("ascii")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--bundle"); ap.add_argument("--out",required=True); a=ap.parse_args(); out=Path(a.out)
    status={"schema":"G13.G12.BASELINE.STATUS.v1","required_bundle":"G12_Final_Rules_Reference_Bundle.zip","required_sha256":EXPECTED,"semantic_authority":"G10.RULES.v1.0","state_profile":"G12.STATE.SERIAL.v2","mandatory_acceptance":"G12 reference suite through G13 checkpoint/distributed machinery must reproduce identical truth/certificate hashes and canonical artifacts"}
    if not a.bundle or not Path(a.bundle).exists():
        status.update({"status":"BLOCKED_INPUT_UNAVAILABLE","bundle_bytes_retrieved":False,"reason":"File Library search exposes the frozen G12 handoff and bundle checksum/inventory but not a retrievable bundle payload in the active runtime. G13 refuses to reconstruct the mandatory payload from prose."})
    else:
        data=Path(a.bundle).read_bytes(); got=shab(data); status["bundle_bytes_retrieved"]=True; status["observed_sha256"]=got
        if got!=EXPECTED:
            status.update({"status":"BLOCKED_HASH_MISMATCH"})
        else:
            mism=[]; present=[]
            with zipfile.ZipFile(a.bundle,"r") as z:
                for name, exp in INVENTORY.items():
                    if name not in z.namelist(): mism.append({"file":name,"error":"missing"}); continue
                    b=z.read(name); gh=shab(b); present.append(name)
                    if gh!=exp: mism.append({"file":name,"expected":exp,"observed":gh})
            status.update({"inventory_files_present":present,"inventory_mismatches":mism,"status":"READY" if not mism else "BLOCKED_COMPONENT_HASH_MISMATCH"})
    out.write_bytes(canon(status)); print(json.dumps(status,indent=2,sort_keys=True))
if __name__=="__main__": main()
