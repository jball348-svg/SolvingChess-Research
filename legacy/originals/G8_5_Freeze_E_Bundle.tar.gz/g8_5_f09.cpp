#include <bits/stdc++.h>
using namespace std; using u32=uint32_t; using u64=uint64_t;
static inline int ff(int s){return s&7;} static inline int rr(int s){return s>>3;} static inline int col(int s){return (ff(s)+rr(s))&1;} static inline int kd(int a,int b){return max(abs(ff(a)-ff(b)),abs(rr(a)-rr(b)));}
static vector<int> KM[64];
static vector<int> BSQL; static int BIDX[64]; struct BP{int a,b;}; static vector<BP> BPAIR; static int BPIDX[64][64];
static void initGeom(){
 for(int s=0;s<64;s++) for(int dx=-1;dx<=1;dx++) for(int dy=-1;dy<=1;dy++) if(dx||dy){int x=ff(s)+dx,y=rr(s)+dy;if(0<=x&&x<8&&0<=y&&y<8)KM[s].push_back(y*8+x);} 
 fill(begin(BIDX),end(BIDX),-1); for(auto &r:BPIDX) fill(begin(r),end(r),-1);
 for(int s=0;s<64;s++) if(col(s)==1){BIDX[s]=BSQL.size();BSQL.push_back(s);} 
 for(int i=0;i<(int)BSQL.size();i++)for(int j=i+1;j<(int)BSQL.size();j++){int id=BPAIR.size();BPAIR.push_back({BSQL[i],BSQL[j]});BPIDX[BSQL[i]][BSQL[j]]=BPIDX[BSQL[j]][BSQL[i]]=id;}
}
static bool pawnHits(int p,int q){return rr(q)==rr(p)+1 && abs(ff(q)-ff(p))==1;}
static bool knightHits(int p,int q){int a=abs(ff(p)-ff(q)),b=abs(rr(p)-rr(q));return (a==1&&b==2)||(a==2&&b==1);}
static bool rayHits(char pc,int from,int to,const vector<int>&occ){int dx=ff(to)-ff(from),dy=rr(to)-rr(from),sx=0,sy=0; if(pc=='B'){if(dx==0||abs(dx)!=abs(dy))return false;sx=dx>0?1:-1;sy=dy>0?1:-1;} else if(pc=='R'){if(dx&&dy)return false;sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0);} else {if(dx==0||dy==0){sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0);}else if(abs(dx)==abs(dy)){sx=dx>0?1:-1;sy=dy>0?1:-1;}else return false;} int x=ff(from)+sx,y=rr(from)+sy; while(x!=ff(to)||y!=rr(to)){int q=y*8+x;for(int z:occ)if(z==q)return false;x+=sx;y+=sy;}return true;}
static bool promoChoiceWin(int wk,int bk,const vector<int>&bs,char pc){const int h8=63;auto whiteHits=[&](int q,bool prom){if(kd(wk,q)<=1)return true;vector<int> blocks=bs;if(prom)blocks.push_back(h8);for(int b:bs)if(rayHits('B',b,q,blocks))return true;if(prom){if(pc=='N'){if(knightHits(h8,q))return true;}else if(rayHits(pc,h8,q,bs))return true;}return false;}; bool kingCanCapture=false;int legal=0;for(int nb:KM[bk]){if(nb==wk)continue;if(nb==h8){if(kd(nb,wk)<=1)continue;bool guarded=false;for(int b:bs)if(rayHits('B',b,nb,bs)){guarded=true;break;}if(guarded)continue;kingCanCapture=true;legal++;continue;}if(whiteHits(nb,true))continue;legal++;}bool inCheck=whiteHits(bk,true);if(legal==0)return inCheck;if(kingCanCapture)return false;return pc=='Q'||pc=='R'||(!bs.empty()&&(pc=='B'||pc=='N'));}
static bool promoWin(int wk,int bk,const vector<int>&bs){for(char pc: {'Q','R','B','N'})if(promoChoiceWin(wk,bk,bs,pc))return true;return false;}
struct TruthNode{u64 raw=0;vector<u64> w; uint8_t get(u64 c)const{return (w[c>>5]>>((c&31)*2))&3ULL;}};
static TruthNode readNode(ifstream&in,uint8_t want,u64 raw){uint8_t id;u64 got;in.read((char*)&id,1);in.read((char*)&got,8);if(!in||id!=want||got!=raw)throw runtime_error("truth node header mismatch");TruthNode n;n.raw=raw;n.w.resize((raw+31)/32);in.read((char*)n.w.data(),n.w.size()*8);if(!in)throw runtime_error("truth node truncated");return n;}
struct S4{int pri,wk,b,bk,t;}; struct S5{int pri,wk,pair,bk,t;};
static constexpr u64 RAW4=6ULL*64*32*64*2, RAW5=6ULL*64*496*64*2;
static inline int pawnSq(int pri){return (pri+1)*8+7;}
static u64 code4(S4 s){return ((((u64(s.pri)*64+s.wk)*32+BIDX[s.b])*64+s.bk)*2+s.t);} 
static u64 code5(S5 s){u64 x=s.pri;x=x*64+s.wk;x=x*496+s.pair;x=x*64+s.bk;x=x*2+s.t;return x;}
static S5 dec5(u64 c){S5 s;s.t=c&1;c>>=1;s.bk=c%64;c/=64;s.pair=c%496;c/=496;s.wk=c%64;c/=64;s.pri=c;return s;}
static pair<int,int> bishops(S5 s){auto p=BPAIR[s.pair];return {p.a,p.b};}
static bool bishopsHit(S5 s,int q){auto [a,b]=bishops(s);vector<int> occ={pawnSq(s.pri),s.wk,a,b};return rayHits('B',a,q,occ)||rayHits('B',b,q,occ);}
static bool valid5Geom(S5 s){auto[a,b]=bishops(s);int p=pawnSq(s.pri);int v[5]={s.wk,s.bk,a,b,p};for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)if(v[i]==v[j])return false;if(kd(s.wk,s.bk)<=1)return false;if(s.t==0&&(pawnHits(p,s.bk)||bishopsHit(s,s.bk)))return false;return true;}
static bool checked5(S5 s){return s.t==1&&(pawnHits(pawnSq(s.pri),s.bk)||bishopsHit(s,s.bk));}
struct Moves{vector<u32> in;bool whiteWinExit=false,drawExit=false;};
struct Board{
 const TruthNode &f4,&f5;
 bool valid5(S5 s)const{u64 c=code5(s);return c<RAW5&&f5.get(c)!=0;} 
 Moves succ(S5 s)const{Moves m;m.in.reserve(32);auto[a,b]=bishops(s);int p=pawnSq(s.pri);if(s.t==0){
   for(int nw:KM[s.wk]) if(nw!=a&&nw!=b&&nw!=p&&nw!=s.bk&&kd(nw,s.bk)>1){S5 z=s;z.wk=nw;z.t=1;if(valid5(z))m.in.push_back(code5(z));}
   int bb[2]={a,b};int d[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};for(int k=0;k<2;k++){int from=bb[k],other=bb[1-k];for(auto &di:d){int x=ff(from)+di[0],y=rr(from)+di[1];while(0<=x&&x<8&&0<=y&&y<8){int q=y*8+x;if(q==s.wk||q==s.bk||q==p||q==other)break;int pi=BPIDX[q][other];if(pi>=0){S5 z=s;z.pair=pi;z.t=1;if(valid5(z))m.in.push_back(code5(z));}x+=di[0];y+=di[1];}}}
   int q=p+8;if(q<64&&q!=s.wk&&q!=s.bk&&q!=a&&q!=b){if(s.pri==5){if(promoWin(s.wk,s.bk,{a,b}))m.whiteWinExit=true;else m.drawExit=true;}else{S5 z=s;z.pri++;z.t=1;if(valid5(z))m.in.push_back(code5(z));if(s.pri==0){int q2=p+16;if(q2!=s.wk&&q2!=s.bk&&q2!=a&&q2!=b){z=s;z.pri=2;z.t=1;if(valid5(z))m.in.push_back(code5(z));}}}}
 }else{
   for(int nb:KM[s.bk]){if(nb==s.wk)continue;if(nb==p){if(kd(nb,s.wk)>1&&!bishopsHit(s,nb))m.drawExit=true;continue;}int cap=(nb==a?0:(nb==b?1:-1));if(cap>=0){int other=cap==0?b:a;if(kd(nb,s.wk)<=1||pawnHits(p,nb))continue;vector<int> occ={p,s.wk};if(rayHits('B',other,nb,occ))continue;S4 z{s.pri,s.wk,other,nb,0};u64 lc=code4(z);if(lc<RAW4&&f4.get(lc)==1)m.whiteWinExit=true;else m.drawExit=true;continue;}if(kd(nb,s.wk)<=1||pawnHits(p,nb)||bishopsHit(s,nb))continue;S5 z=s;z.bk=nb;z.t=0;if(valid5(z))m.in.push_back(code5(z));}
 }
 sort(m.in.begin(),m.in.end());m.in.erase(unique(m.in.begin(),m.in.end()),m.in.end());return m;}
 template<class Fn> void predecessors(u64 cc,Fn fn)const{S5 s=dec5(cc);vector<u32> v;v.reserve(40);bool previousWhite=s.t==1;auto add=[&](S5 z){z.t=previousWhite?0:1;if(valid5(z))v.push_back(code5(z));};if(previousWhite){for(int o:KM[s.wk]){S5 z=s;z.wk=o;add(z);}auto[a,b]=bishops(s);int bb[2]={a,b};int d[4][2]={{1,1},{1,-1},{-1,1},{-1,-1}};for(int k=0;k<2;k++){int dest=bb[k],other=bb[1-k];for(auto&di:d){int x=ff(dest)+di[0],y=rr(dest)+di[1];while(0<=x&&x<8&&0<=y&&y<8){int o=y*8+x;if(o==s.wk||o==s.bk||o==pawnSq(s.pri)||o==other)break;int pi=BPIDX[o][other];if(pi>=0){S5 z=s;z.pair=pi;add(z);}x+=di[0];y+=di[1];}}}if(s.pri>0){S5 z=s;z.pri--;add(z);}if(s.pri==2){const int h3=23;if(s.wk!=h3&&s.bk!=h3&&a!=h3&&b!=h3){S5 z=s;z.pri=0;add(z);}}}else{for(int o:KM[s.bk]){S5 z=s;z.bk=o;add(z);}}
 sort(v.begin(),v.end());v.erase(unique(v.begin(),v.end()),v.end());for(u32 p:v)fn(p);
 }
};
struct Mask{vector<u64>w;Mask(){}Mask(u64 n):w((n+63)/64){}bool get(u64 i)const{return(w[i>>6]>>(i&63))&1;}bool setnew(u64 i){u64 b=1ULL<<(i&63),&x=w[i>>6];if(x&b)return false;x|=b;return true;}void set(u64 i){w[i>>6]|=1ULL<<(i&63);}u64 count()const{u64 z=0;for(u64 x:w)z+=__builtin_popcountll(x);return z;}};
static bool isTarget(S5 s){return s.pri>=4&&kd(s.wk,63)<=4&&kd(s.bk,63)>=5;}

enum FK{ORD,CHECK,CAPTURE,FORCING,KING_ONLY,PAWN_ONLY,MOBILE_ONLY};
static const char* fnm(FK f){switch(f){case ORD:return "ORDINARY";case CHECK:return "CHECK";case CAPTURE:return "CAPTURE";case FORCING:return "FORCING";case KING_ONLY:return "KING_ONLY";case PAWN_ONLY:return "PAWN_ONLY";case MOBILE_ONLY:return "MOBILE_PIECE_ONLY";}return "?";}
static int moverType(S5 p,S5 z){if(p.wk!=z.wk)return 1;if(p.pri!=z.pri)return 2;if(p.pair!=z.pair)return 3;return 0;}
static bool admiss(FK f,S5 p,S5 z){if(f==ORD)return true;bool ch=checked5(z);int m=moverType(p,z);bool cap=false;if(f==CHECK)return ch;if(f==CAPTURE)return cap;if(f==FORCING)return ch||cap;if(f==KING_ONLY)return m==1;if(f==PAWN_ONLY)return m==2;if(f==MOBILE_ONLY)return m==3;return false;}
static Mask attractorF(const Board&b,FK f){Mask A(RAW5);vector<uint8_t> rem(RAW5),elig(RAW5);deque<u32>q;for(u64 c=0;c<RAW5;c++)if(b.f5.get(c)){S5 s=dec5(c);if(isTarget(s)){A.set(c);q.push_back(c);continue;}if(s.t==1){auto m=b.succ(s);if(!m.whiteWinExit&&!m.drawExit&&!m.in.empty()){elig[c]=1;rem[c]=min<size_t>(255,m.in.size());}}}
 while(!q.empty()){u32 z=q.front();q.pop_front();S5 zs=dec5(z);b.predecessors(z,[&](u64 p){if(A.get(p))return;S5 ps=dec5(p);if(isTarget(ps))return;if(ps.t==0){if(isTarget(zs)||admiss(f,ps,zs)){A.set(p);q.push_back(p);}}else if(elig[p]&&rem[p]&&--rem[p]==0){A.set(p);q.push_back(p);}});}return A;}
struct Aud{u64 fixedBad=0,q=0,piv=0,recon=0,miss=0,extra=0;double amp=0;};
static Aud auditF(const Board&b,FK f,const Mask&A,const Mask&C){Aud a;Mask Q(RAW5),K(RAW5);for(u64 c=0;c<RAW5;c++)if(b.f5.get(c)){S5 s=dec5(c);if(A.get(c)&&!C.get(c)){Q.set(c);a.q++;}bool qual=isTarget(s);auto m=b.succ(s);if(!qual){if(s.t==0){for(u32 z:m.in)if(C.get(z)){S5 zs=dec5(z);if(isTarget(zs)||admiss(f,s,zs)){qual=true;break;}}}else{qual=!m.whiteWinExit&&!m.drawExit&&!m.in.empty();if(qual)for(u32 z:m.in)if(!C.get(z)){qual=false;break;}}}if(C.get(c)!=qual)a.fixedBad++;if(Q.get(c)&&s.t==0){for(u32 z:m.in)if(C.get(z)){S5 zs=dec5(z);if(!isTarget(zs)&&!admiss(f,s,zs)){K.set(c);a.piv++;break;}}}}
 Mask R(RAW5);vector<uint8_t>rem(RAW5),elig(RAW5);deque<u32>q;for(u64 c=0;c<RAW5;c++)if(K.get(c)){R.set(c);q.push_back(c);}for(u64 c=0;c<RAW5;c++)if(b.f5.get(c)&&Q.get(c)&&!R.get(c)){S5 s=dec5(c);if(s.t==1){auto m=b.succ(s);bool ok=!m.whiteWinExit&&!m.drawExit;int need=0;for(u32 z:m.in){if(C.get(z))continue;if(Q.get(z))need++;else ok=false;}if(ok){elig[c]=1;rem[c]=min(255,need);if(need==0){R.set(c);q.push_back(c);}}}}
 while(!q.empty()){u32 z=q.front();q.pop_front();b.predecessors(z,[&](u64 p){if(!Q.get(p)||R.get(p))return;S5 ps=dec5(p);if(ps.t==0){R.set(p);q.push_back(p);}else if(elig[p]&&rem[p]&&--rem[p]==0){R.set(p);q.push_back(p);}});}a.recon=R.count();for(size_t i=0;i<Q.w.size();i++){a.miss+=__builtin_popcountll(Q.w[i]&~R.w[i]);a.extra+=__builtin_popcountll(R.w[i]&~Q.w[i]);}a.amp=a.piv?double(a.q)/a.piv:0;return a;}
int main(int argc,char**argv){ios::sync_with_stdio(false);cin.tie(nullptr);string truth=argc>1?argv[1]:"/mnt/data/G8_1_F09_canonical_truth.bin";initGeom();ifstream in(truth,ios::binary);char magic[8];in.read(magic,8);if(!in||string(magic,7)!="G8FORT1")throw runtime_error("truth magic");auto kpk=readNode(in,1,6ULL*64*64*2);auto f4=readNode(in,2,RAW4);auto f5=readNode(in,3,RAW5);Board b{f4,f5};Mask T(RAW5);for(u64 c=0;c<RAW5;c++)if(f5.get(c)&&isTarget(dec5(c)))T.set(c);auto A=attractorF(b,ORD);cout<<"ARENA F09 target="<<T.count()<<" ordinary="<<A.count()<<"\n";vector<FK> fs={CHECK,CAPTURE,FORCING,KING_ONLY,PAWN_ONLY,MOBILE_ONLY};if(argc>2){string q=argv[2];vector<FK>x;for(auto k:fs)if(q==fnm(k))x.push_back(k);fs=x;}for(auto f:fs){auto t0=chrono::steady_clock::now();auto C=attractorF(b,f);auto a=auditF(b,f,A,C);cout<<"ROW "<<fnm(f)<<" attr="<<C.count()<<" retention="<<setprecision(10)<<100.0*C.count()/A.count()<<" q="<<a.q<<" piv="<<a.piv<<" amp="<<a.amp<<" fixedBad="<<a.fixedBad<<" recon="<<a.recon<<" miss="<<a.miss<<" extra="<<a.extra<<" sec="<<fixed<<setprecision(3)<<chrono::duration<double>(chrono::steady_clock::now()-t0).count()<<"\n";}}
