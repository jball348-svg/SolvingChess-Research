# G8.2 Certificate Freeze B — Replay

This bundle freezes the G8.CERT.v0.1 certificate schema, sparse payloads, producer/compiler sources, and standalone verifier sources.

## Required exact truth dependencies

The following G8.1 files are intentionally not duplicated in this bundle. Place them in `G8_TRUTH_ROOT` (defaults to `/mnt/data`):

- `G8_1_BB_opp_d7_e2_canonical_truth.bin` — SHA-256 `e328e0f68c32863945cfbdbbab10fb78cf20f08141af2f53070ccd32a6e11d99`
- `G8_1_BB_same_c7_f2_canonical_truth.bin` — SHA-256 `e9604c7489592a84869ba41c64af5abf244e546f5bdeb81eb45a3c4cd7d8d68e`
- `G8_1_F09_canonical_truth.bin` — SHA-256 `0d550158522726e253a8dc9a271cb1a6f4a8e1c50854f24f79e295f0fdfecbf4`

## Replay

The current script is stored under `src/`. Copy the contents of `src/` beside the `cert/` directory (or preserve the original G8.2 working layout), then run:

```bash
G8_TRUTH_ROOT=/mnt/data ./replay_g8_2.sh
```

The replay recompiles the two standalone verifiers, verifies manifest/dependency/payload hashes, independently reconstructs F01/F02/F09 objects, and checks 14 canonical derived-membership SHA-256 fingerprints.

The certificate payloads do not contain producer queue history or the producer audit masks.
