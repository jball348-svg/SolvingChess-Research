#!/usr/bin/env python3
import hashlib, json, os, subprocess, sys, time, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CERT=ROOT/'cert'
MAN=CERT/'G8_Certificate_Manifest_v0_1.json'
TRUTH_ROOT=Path(os.environ.get('G8_TRUTH_ROOT','/mnt/data'))

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def die(msg): raise SystemExit('VERIFY_FAIL: '+msg)

m=json.loads(MAN.read_text())
side=(CERT/'G8_Certificate_Manifest_v0_1.sha256').read_text().split()[0]
if sha(MAN)!=side: die('manifest sidecar mismatch')
for ar,d in m['dependencies'].items():
    p=TRUTH_ROOT/d['file']
    if not p.exists() or sha(p)!=d['sha256']: die(f'{ar} truth dependency hash')
for oid,o in m['objects'].items():
    if 'payload' in o:
        p=CERT/o['payload']
        if not p.exists() or sha(p)!=o['payload_meta']['sha256'] or p.stat().st_size!=o['payload_meta']['bytes']:
            die(f'{oid} payload integrity')
# Source separation hashes declared in manifest.
for key,fn in [('brink_source_sha256','g8_cert_brink_verifier.cpp'),('f09_source_sha256','g8_cert_f09_verifier.cpp')]:
    if sha(ROOT/fn)!=m['verifier'][key]: die('verifier source hash '+fn)

out=ROOT/'verify_replay';out.mkdir(exist_ok=True)
for p in out.glob('*'): p.unlink()
results={}
def run(cmd,key):
    t=time.perf_counter(); r=subprocess.run(cmd,text=True,capture_output=True,check=True); dt=time.perf_counter()-t
    line=[x for x in r.stdout.splitlines() if x.strip()][-1]
    obj=json.loads(line); obj['replay_wall_seconds']=round(dt,6); results[key]=obj
    (out/(key+'.stdout')).write_text(r.stdout);(out/(key+'.stderr')).write_text(r.stderr)

run([str(ROOT/'g8_cert_brink_verifier'),'F01',str(TRUTH_ROOT/m['dependencies']['F01']['file']),str(CERT),str(out)],'F01')
run([str(ROOT/'g8_cert_brink_verifier'),'F02',str(TRUTH_ROOT/m['dependencies']['F02']['file']),str(CERT),str(out)],'F02')
run([str(ROOT/'g8_cert_f09_verifier'),str(out),str(CERT/'F09_filter_pivots.g8dv'),str(TRUTH_ROOT/m['dependencies']['F09']['file'])],'F09')

# Semantic/count obligations.
f1=results['F01']; exp={'A7':355,'A11':12831,'union':13842,'proper':13186,'bridge':656,'kernel':152,'closure':656,'nonwins':0}
for k,v in exp.items():
    if f1.get(k)!=v: die(f'F01 {k}: {f1.get(k)} != {v}')
for k in ['payload_kernel_exact','closure_exact']:
    if not f1.get(k): die('F01 '+k)
f2=results['F02']; exp={'full':612427,'proper':605232,'irreducible':7195,'hyperkernel':1641,'hyper_closure':7195,'derived':23327,'check':23026,'quiet':301,'pivots':239,'pivot_closure':301,'fixed_ordinary_bad':0,'fixed_check_bad':0,'parent_nonwins':0}
for k,v in exp.items():
    if f2.get(k)!=v: die(f'F02 {k}: {f2.get(k)} != {v}')
if f2.get('singles')!=[41,72757,493591] or f2.get('pairs')!=[81249,534327,564193]: die('F02 endpoint attrs')
for k in ['payload_hyper_exact','hyper_closure_exact','payload_pivot_exact','pivot_closure_exact']:
    if not f2.get(k): die('F02 '+k)
f9=results['F09']; exp={'target':1448464,'attr':8295062,'check':2461867,'quiet':5833195,'pivots':517120,'pivot_closure':5833195,'sanctuary_direct':330264,'sanctuary_conservative':3133058,'sanctuary_safe':4437719,'attr_nonwins':0,'check_nonwins':0,'sanctuary_nondraws':0}
for k,v in exp.items():
    if f9.get(k)!=v: die(f'F09 {k}: {f9.get(k)} != {v}')
for k in ['payload_pivot_exact','pivot_closure_exact']:
    if not f9.get(k): die('F09 '+k)

# Canonical derived-membership replay hashes.
mask_map={
 'F01_bridge.bits':m['objects']['F01.BRANCH.7_11']['irreducible_membership']['sha256'],
 'F01_union_attr.bits':m['objects']['F01.BRANCH.7_11']['union_membership']['sha256'],
 'F02_three_attr.bits':m['objects']['F02.HYPER.7_11_14']['full_membership']['sha256'],
 'F02_irreducible.bits':m['objects']['F02.HYPER.7_11_14']['irreducible_membership']['sha256'],
 'F02_derived_attr.bits':m['objects']['F02.DERIVED.ATTR']['membership']['sha256'],
 'F02_derived_check.bits':m['objects']['F02.DERIVED.CHECK']['membership']['sha256'],
 'F02_quiet.bits':m['objects']['F02.DERIVED.FILTER_PIVOT']['quiet_membership']['sha256'],
 'F09_target.bits':m['objects']['F09.TARGET']['membership']['sha256'],
 'F09_attr.bits':m['objects']['F09.ATTR']['membership']['sha256'],
 'F09_check.bits':m['objects']['F09.CHECK']['membership']['sha256'],
 'F09_quiet.bits':m['objects']['F09.FILTER_PIVOT']['quiet_membership']['sha256'],
 'F09_sanctuary_direct.bits':m['objects']['F09.SANCTUARY.DIRECT']['membership']['sha256'],
 'F09_sanctuary_conservative.bits':m['objects']['F09.SANCTUARY.CONSERVATIVE']['membership']['sha256'],
 'F09_sanctuary_safe.bits':m['objects']['F09.SANCTUARY.SAFE']['membership']['sha256'],
}
hashes={}
for fn,expected in mask_map.items():
    p=out/fn
    got=sha(p) if p.exists() else None
    hashes[fn]=got
    if got!=expected: die(f'membership replay {fn}')

report={'status':'PASS','schema':m['certificate_schema'],'manifest_sha256':side,'results':results,'membership_replay_hashes':hashes,'all_payloads_exact':True,'all_membership_hashes_exact':True}
report_path=ROOT/'G8_2_Verification_Result.json';report_path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','manifest_sha256':side,'wall_seconds':{k:v['replay_wall_seconds'] for k,v in results.items()},'membership_hashes_checked':len(hashes)},sort_keys=True))
