#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${G8_TRUTH_ROOT:=/mnt/data}"
g++ -O3 -march=native -std=c++20 -DNDEBUG "$ROOT/g8_cert_brink_verifier.cpp" -o "$ROOT/g8_cert_brink_verifier"
g++ -O3 -march=native -std=c++20 -DNDEBUG "$ROOT/g8_cert_f09_verifier.cpp" -o "$ROOT/g8_cert_f09_verifier"
G8_TRUTH_ROOT="$G8_TRUTH_ROOT" python3 "$ROOT/g8_certificate_verify.py"
