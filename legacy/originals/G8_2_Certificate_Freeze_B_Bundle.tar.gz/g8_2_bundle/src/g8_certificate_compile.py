#!/usr/bin/env python3
import hashlib, json, os, struct, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TRUTH_ROOT=Path(os.environ.get('G8_TRUTH_ROOT','/mnt/data'))
PROD=ROOT/'producer'; CERT=ROOT/'cert'
CERT.mkdir(parents=True,exist_ok=True)

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def read_u32(path):
    b=Path(path).read_bytes()
    if len(b)%4: raise ValueError(path)
    a=list(struct.unpack('<%dI'%(len(b)//4),b))
    if a!=sorted(a) or len(a)!=len(set(a)): raise ValueError('not sorted unique '+str(path))
    return a

def uleb(x):
    out=bytearray()
    while True:
        b=x&0x7f;x>>=7
        if x: out.append(b|0x80)
        else: out.append(b);return bytes(out)

def pack_delta(src,dst):
    a=read_u32(src);out=bytearray(b'G8DV1\0\0\0');out+=struct.pack('<Q',len(a));prev=0
    for i,x in enumerate(a):
        d=x if i==0 else x-prev
        out+=uleb(d);prev=x
    Path(dst).write_bytes(out)
    return {'count':len(a),'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'encoding':'G8DV1 sorted raw-code delta ULEB128'}

payloads={}
for stem in ['F01_branch_kernel','F02_hyperkernel','F02_filter_pivots','F09_filter_pivots']:
    payloads[stem]=pack_delta(PROD/(stem+'.rawu32'),CERT/(stem+'.g8dv'))

mask_meta={p.stem:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(PROD.glob('*.bits'))}
truths={
 'F01':{'file':'G8_1_BB_opp_d7_e2_canonical_truth.bin','sha256':sha(TRUTH_ROOT/'G8_1_BB_opp_d7_e2_canonical_truth.bin')},
 'F02':{'file':'G8_1_BB_same_c7_f2_canonical_truth.bin','sha256':sha(TRUTH_ROOT/'G8_1_BB_same_c7_f2_canonical_truth.bin')},
 'F09':{'file':'G8_1_F09_canonical_truth.bin','sha256':sha(TRUTH_ROOT/'G8_1_F09_canonical_truth.bin')},
}
manifest={
 'certificate_schema':'G8.CERT.v0.1',
 'proof_language':'G7 Proof Language v0.3 (frozen)',
 'date':'2026-08-11',
 'state_identity':'(arena_signature, canonical raw code); raw code conventions are arena-declared and verifier-regenerated',
 'payload_encoding':'G8DV1: sorted uint32 raw codes, delta encoded, unsigned LEB128; 8-byte magic + uint64 count',
 'dependencies':truths,
 'producer':{
   'brink_source_sha256':sha(ROOT/'g8_cert_brink_producer.cpp'),
   'f09_source_sha256':sha(ROOT/'g8_cert_f09_producer.cpp'),
   'build':'g++ -O3 -march=native -std=c++20'
 },
 'compiler':{'source_sha256':sha(ROOT/'g8_certificate_compile.py')},
 'verifier':{
   'brink_source_sha256':sha(ROOT/'g8_cert_brink_verifier.cpp'),
   'f09_source_sha256':sha(ROOT/'g8_cert_f09_verifier.cpp'),
   'replay_harness_sha256':sha(ROOT/'g8_certificate_verify.py'),
   'implementation_separation':'standalone verifier sources; no producer source inclusion; verifier regenerates arena move relations/fixed points and consumes only declared truth dependencies + sparse payloads'
 },
 'objects':{
  'F01.BRANCH.7_11':{
    'type':'BRANCH_KERNEL','arena':'BB_opp_d7_e2','target_signatures':[7,11],
    'constituent_attr_counts':{'SIG7':355,'SIG11':12831},'union_attr_count':13842,'proper_union_count':13186,
    'irreducible_count':656,'kernel_count':152,'payload':'F01_branch_kernel.g8dv','payload_meta':payloads['F01_branch_kernel'],
    'union_membership':mask_meta['F01_union_attr'],'irreducible_membership':mask_meta['F01_bridge'],
    'verification':'kernel local obligations + residual closure outside proper constituent union'
  },
  'F02.HYPER.7_11_14':{
    'type':'FINITE_N_HYPERKERNEL','arena':'BB_same_c7_f2','target_signatures':[7,11,14],
    'single_attr_counts':{'SIG7':41,'SIG11':72757,'SIG14':493591},
    'proper_pair_attr_counts':{'7+11':81249,'7+14':534327,'11+14':564193},
    'full_attr_count':612427,'proper_subunion_count':605232,'irreducible_count':7195,'kernel_count':1641,
    'payload':'F02_hyperkernel.g8dv','payload_meta':payloads['F02_hyperkernel'],
    'full_membership':mask_meta['F02_three_attr'],'irreducible_membership':mask_meta['F02_irreducible'],
    'verification':'kernel local obligations + residual closure outside all proper subunions'
  },
  'F02.DERIVED.ATTR':{
    'type':'STRICT_ATTRACTOR','arena':'BB_same_c7_f2','target_object':'F02.HYPER.7_11_14.irreducible',
    'domain_object':'F02.HYPER.7_11_14.full_attr','count':23327,'membership':mask_meta['F02_derived_attr']
  },
  'F02.DERIVED.CHECK':{
    'type':'FILTERED_ATTRACTOR','filter':'CHECK','target_entry_exemption':True,'arena':'BB_same_c7_f2',
    'target_object':'F02.HYPER.7_11_14.irreducible','domain_object':'F02.HYPER.7_11_14.full_attr',
    'count':23026,'membership':mask_meta['F02_derived_check']
  },
  'F02.DERIVED.FILTER_PIVOT':{
    'type':'FILTER_PIVOT_FACTORIZATION','filter':'CHECK','arena':'BB_same_c7_f2',
    'ordinary_object':'F02.DERIVED.ATTR','filtered_object':'F02.DERIVED.CHECK','quiet_required_count':301,'pivot_count':239,
    'payload':'F02_filter_pivots.g8dv','payload_meta':payloads['F02_filter_pivots'],'quiet_membership':mask_meta['F02_quiet'],
    'verification':'pivot local quiet-edge-to-filtered obligation + ordinary residual closure outside filtered object'
  },
  'F09.TARGET':{
    'type':'RESOURCE_SAFE_TARGET','arena':'F09_faithful_fortress','semantic_predicate':'pawn rank >= h6 equivalent pri>=4; Chebyshev(WK,h8)<=4; Chebyshev(BK,h8)>=5',
    'count':1448464,'membership':mask_meta['F09_target']
  },
  'F09.ATTR':{
    'type':'STRICT_ATTRACTOR','arena':'F09_faithful_fortress','target_object':'F09.TARGET','external_non-target_transitions':'block','count':8295062,'membership':mask_meta['F09_attr']
  },
  'F09.CHECK':{
    'type':'FILTERED_ATTRACTOR','filter':'CHECK','target_entry_exemption':True,'arena':'F09_faithful_fortress','target_object':'F09.TARGET','count':2461867,'membership':mask_meta['F09_check']
  },
  'F09.FILTER_PIVOT':{
    'type':'FILTER_PIVOT_FACTORIZATION','filter':'CHECK','arena':'F09_faithful_fortress','ordinary_object':'F09.ATTR','filtered_object':'F09.CHECK',
    'quiet_required_count':5833195,'pivot_count':517120,'payload':'F09_filter_pivots.g8dv','payload_meta':payloads['F09_filter_pivots'],'quiet_membership':mask_meta['F09_quiet'],
    'verification':'pivot local quiet-edge-to-filtered obligation + ordinary residual closure outside filtered object'
  },
  'F09.SANCTUARY.DIRECT':{
    'type':'TARGET','role':'defender','arena':'F09_faithful_fortress','semantic_predicate':'BK=h8','count':330264,'membership':mask_meta['F09_sanctuary_direct']
  },
  'F09.SANCTUARY.CONSERVATIVE':{
    'type':'ROLE_DUAL_SANCTUARY_ATTRACTOR','arena':'F09_faithful_fortress','target_object':'F09.SANCTUARY.DIRECT','safe_external_exits':False,
    'count':3133058,'membership':mask_meta['F09_sanctuary_conservative']
  },
  'F09.SANCTUARY.SAFE':{
    'type':'ROLE_DUAL_SANCTUARY_ATTRACTOR','arena':'F09_faithful_fortress','target_object':'F09.SANCTUARY.DIRECT',
    'safe_external_exits':'exact lower-material draws + faithful draw promotion continuations + stalemate terminals',
    'count':4437719,'membership':mask_meta['F09_sanctuary_safe']
  }
 },
 'compiler_note':'Derived membership masks are producer-side audit artifacts and are not certificate payloads. Only semantic declarations, dependency hashes, and the four sparse G8DV payloads are needed by the independent verifier.'
}
manifest_path=CERT/'G8_Certificate_Manifest_v0_1.json'
manifest_path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
manifest['manifest_sha256']=sha(manifest_path)
# don't self-hash recursively; separate sidecar
(CERT/'G8_Certificate_Manifest_v0_1.sha256').write_text(manifest['manifest_sha256']+'  G8_Certificate_Manifest_v0_1.json\n')
print(json.dumps({'payloads':payloads,'manifest_sha256':manifest['manifest_sha256']},indent=2))
