import random, json, hashlib

def attr(n, owner, succ, target):
    A=set(target)
    changed=True
    while changed:
        changed=False
        for v in range(n):
            if v in A: continue
            if owner[v]==0:
                if any(w in A for w in succ[v]):
                    A.add(v); changed=True
            else:
                if succ[v] and all(w in A for w in succ[v]):
                    A.add(v); changed=True
    return A

def branch_factor(n, owner, succ, T1,T2):
    A1=attr(n,owner,succ,T1); A2=attr(n,owner,succ,T2)
    base=A1|A2
    U=attr(n,owner,succ,set(T1)|set(T2))
    pure=U-base
    kernel=set()
    for v in range(n):
        if v in base or owner[v]!=1: continue
        S=succ[v]
        if S and all(w in base for w in S) and any(w in A1-A2 for w in S) and any(w in A2-A1 for w in S):
            kernel.add(v)
    C=set(kernel)
    changed=True
    while changed:
        changed=False
        for v in range(n):
            if v in base or v in C: continue
            if owner[v]==0:
                if any(w in C for w in succ[v]): C.add(v); changed=True
            else:
                if succ[v] and all(w in base|C for w in succ[v]): C.add(v); changed=True
    return pure,kernel,C,A1,A2,U

def hyper3_factor(n, owner, succ, T1,T2,T3):
    T=[set(T1),set(T2),set(T3)]
    A12=attr(n,owner,succ,T[0]|T[1]); A13=attr(n,owner,succ,T[0]|T[2]); A23=attr(n,owner,succ,T[1]|T[2])
    proper=[A12,A13,A23]
    base=A12|A13|A23
    U=attr(n,owner,succ,T[0]|T[1]|T[2])
    H=U-base
    K=set()
    for v in range(n):
        if v in base or owner[v]!=1: continue
        S=succ[v]
        if not S or not all(w in base for w in S): continue
        if all(any(w not in A for w in S) for A in proper): K.add(v)
    C=set(K)
    changed=True
    while changed:
        changed=False
        for v in range(n):
            if v in base or v in C: continue
            if owner[v]==0:
                if any(w in C for w in succ[v]): C.add(v); changed=True
            else:
                if succ[v] and all(w in base|C for w in succ[v]): C.add(v); changed=True
    return H,K,C,U,proper

def rand_graph(rng):
    n=rng.randint(2,14)
    owner=[rng.randrange(2) for _ in range(n)]
    succ=[]
    for v in range(n):
        k=rng.randint(1,min(4,n))
        succ.append(tuple(rng.sample(range(n),k)))
    # independent target subsets; allow overlaps and empties
    Ts=[]
    for _ in range(3):
        p=rng.random()*0.45
        Ts.append({v for v in range(n) if rng.random()<p})
    return n,owner,succ,Ts

def main():
    seed=608112026
    rng=random.Random(seed)
    trials=100000
    nonzero2=nonzero3=0
    maxpure=maxhyper=0
    for i in range(trials):
        n,owner,succ,T=rand_graph(rng)
        P,K,C,*_=branch_factor(n,owner,succ,T[0],T[1])
        if P!=C:
            raise AssertionError(('branch factor mismatch',i,n,owner,succ,T,P,K,C))
        if bool(P)!=bool(K):
            raise AssertionError(('branch iff kernel mismatch',i,P,K))
        if P: nonzero2+=1; maxpure=max(maxpure,len(P))
        H,K3,C3,*_=hyper3_factor(n,owner,succ,T[0],T[1],T[2])
        if H!=C3:
            raise AssertionError(('hyper factor mismatch',i,n,owner,succ,T,H,K3,C3))
        if bool(H)!=bool(K3):
            raise AssertionError(('hyper iff kernel mismatch',i,H,K3))
        if H: nonzero3+=1; maxhyper=max(maxhyper,len(H))
    result={
      'seed':seed,'trials':trials,
      'two_target_factorization_mismatches':0,
      'two_target_nonzero_cases':nonzero2,
      'two_target_max_pure_size':maxpure,
      'three_target_factorization_mismatches':0,
      'three_target_nonzero_cases':nonzero3,
      'three_target_max_irreducible_size':maxhyper,
      'note':'Independent randomized regression over arbitrary finite turn-based total game graphs; supports implementation/general theorem but is not a substitute for the mathematical proof.'
    }
    out='/mnt/data/G6_Generic_Reachability_Theorem_Regression.json'
    with open(out,'w') as f: json.dump(result,f,indent=2)
    h=hashlib.sha256(open(out,'rb').read()).hexdigest()
    print(json.dumps(result,indent=2)); print('sha256',h)
if __name__=='__main__': main()
